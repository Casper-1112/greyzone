'use strict';
/* ================= 10 × 10 公里大世界 =================
   - 烽火撤離、全面戰場：世界邊界 ±5000 m。原本的地圖是「核心區」，外圍是連綿的丘陵與山脈，
     散布 20 多個小據點（村莊、哨站、倉儲站、通訊站、農場、墜機點），每個據點有物資箱與守軍。
   - 其他模式只用核心區（四周有圍牆）。
   - 地形分兩層：核心區 2.5 m 精度（terrain.js 的 TR），外圍 20 m 精度（這裡的 FAR）。
     畫面上只渲染玩家周圍 3.2 km 的外圍地形，跟著玩家移動重建，遠處被霧遮住。
   - 據點周圍自動整平到海拔 0，建築直接放在地上。 */
const WORLD_HALF=5000;
function isBigWorld(mode){return mode==='extract'||mode==='conquest'}
let FAR=null;// {res,n,o,h,max}
const FAR_RES=20;

function farRaw(x,z,s,dune){const big=fbm(x/95,z/95,s,3);let r=dune?(1-Math.abs(fbm(x/70,z/45,s,3)*2-1))**2.2*.9:sstep(.3,.72,big)*.85;
  r+=Math.max(0,fbm(x/800,z/800,s+9,4)-.42)*4.2;// 大山脈
  return r}
function farBuild(){FAR=null;if(W.world<=W.half)return;const amp=Math.max(8,TERR_AMP[W.id]||0),E=WORLD_HALF+200,res=FAR_RES,n=Math.ceil(E*2/res)+1,o=-E;
  const s=(W.seed||1)%100000,dune=W.id==='desert',H=new Float32Array(n*n);
  for(let z=0;z<n;z++)for(let x=0;x<n;x++){const wx=o+x*res,wz=o+z*res;let v=farRaw(wx,wz,s,dune)*amp;const out=Math.max(Math.abs(wx),Math.abs(wz))-WORLD_HALF;if(out>0)v+=out*.3;H[z*n+x]=v}
  // 據點、機場整平
  for(const f of W.flatCircles||[]){const R=f.r+95;const x0=clamp(Math.floor((f.x-R-o)/res),0,n-1),x1=clamp(Math.ceil((f.x+R-o)/res),0,n-1),z0=clamp(Math.floor((f.z-R-o)/res),0,n-1),z1=clamp(Math.ceil((f.z+R-o)/res),0,n-1);
    for(let z=z0;z<=z1;z++)for(let x=x0;x<=x1;x++){const d=Math.hypot(o+x*res-f.x,o+z*res-f.z);H[z*n+x]*=sstep(f.r,f.r+90,d)}}
  let mx=0;for(let i=0;i<n*n;i++)if(H[i]>mx)mx=H[i];FAR={res,n,o,h:H,max:mx,amp}}
function farH(x,z){const F=FAR,n=F.n;let fx=(x-F.o)/F.res,fz=(z-F.o)/F.res;fx=clamp(fx,0,n-1.001);fz=clamp(fz,0,n-1.001);const ix=fx|0,iz=fz|0,u=fx-ix,v=fz-iz,H=F.h,i=iz*n+ix;
  return H[i]*(1-u)*(1-v)+H[i+1]*u*(1-v)+H[i+n]*(1-u)*v+H[i+n+1]*u*v}
function inNear(x,z,pad){if(!TR)return false;const e=TR.o+(TR.n-1)*TR.res;return x>TR.o+pad&&x<e-pad&&z>TR.o+pad&&z<e-pad}

/* ---------- 外圍據點 ---------- */
const SAT_TYPES=['village','outpost','depot','radio','farm','crash','village','outpost'];
const SAT_NAME={village:'村莊',outpost:'哨站',depot:'倉儲站',radio:'通訊站',farm:'農場',crash:'墜機點'};
function dirName(x,z){const a=(Math.atan2(x,-z)*180/Math.PI+360)%360;return['北','東北','東','東南','南','西南','西','西北'][Math.round(a/45)%8]}
function planSatellites(){W.sats=[];W.flatCircles=[];if(W.world<=W.half)return;const R=mulberry((W.seed||1)+911);
  for(let i=0;i<400&&W.sats.length<24;i++){const x=(R()*2-1)*(WORLD_HALF-250),z=(R()*2-1)*(WORLD_HALF-250);
    if(Math.max(Math.abs(x),Math.abs(z))<W.half+420)continue;if(W.sats.some(s=>Math.hypot(s.x-x,s.z-z)<650))continue;
    const type=SAT_TYPES[W.sats.length%SAT_TYPES.length];const r=type==='village'?55:type==='depot'?45:35;
    const km=(Math.hypot(x,z)/1000).toFixed(1);W.sats.push({x,z,r,type,name:`${dirName(x,z)}${SAT_NAME[type]}（${km} km）`})}
  for(const s of W.sats)W.flatCircles.push({x:s.x,z:s.z,r:s.r});
  if(W.mode==='conquest')for(const sx of [-1,1])W.flatCircles.push({x:sx*(W.half+260),z:0,r:110});// 雙方機場
}
function buildSatellites(){if(!W.sats||!W.sats.length)return;
  for(const s of W.sats){const {x,z}=s;landmark(s.name,x,z,s.r*.8);
    switch(s.type){
      case 'village':for(let i=0;i<5;i++){const a=i/5*TAU+srnd(-.3,.3),d=srnd(14,30);house(x+Math.cos(a)*d,z+Math.sin(a)*d,spick([8,10,12]),spick([8,10]),{})}lootBox(x+2,z,'crate');lootBox(x-3,z+2,'med');for(let i=0;i<4;i++)barrel(x+srnd(-20,20),z+srnd(-20,20));break;
      case 'outpost':for(let i=0;i<8;i++){const a=i/8*TAU;sandbag(x+Math.cos(a)*14,z+Math.sin(a)*14,4,Math.abs(Math.cos(a))>.7)}tower(x+8,z+8);tent(x-6,z+3);tent(x+4,z-7);lootBox(x,z,'weapon');lootBox(x-3,z-3,'crate');lootBox(x+3,z+2,'safe');break;
      case 'depot':for(let i=0;i<6;i++)container(x+(i%3-1)*9,z+(i<3?-8:8),false);building(x,z+24,14,10,{});lootBox(x,z,'crate');lootBox(x+5,z+1,'crate');lootBox(x-5,z-1,'weapon');break;
      case 'radio':lattice(x,z,3,34,0x8a2a20);building(x+10,z,10,8,{});lootBox(x+10,z,'pc');lootBox(x+12,z+2,'crate');sandbag(x-6,z,5,true);break;
      case 'farm':house(x,z,12,9,{});silo(x+14,z+6,3,10);silo(x+14,z-4,3,12);field(x-18,z+12,11);lootBox(x-2,z+1,'crate');lootBox(x+3,z-1,'med');break;
      case 'crash':for(let i=0;i<4;i++)wreckCar(x+srnd(-14,14),z+srnd(-14,14),SR()<.5);{const hm=heliModel();hm.position.set(x,1.2,z);hm.rotation.set(.35,srnd(0,TAU),.5);scene.remove(hm);addObj(hm);sbox(x,z,3,6,2.4,null,0)}lootBox(x+4,z+3,'safe');lootBox(x-4,z+2,'vault');break}
    // 據點周圍的樹
    for(let i=0;i<26;i++){const a=SR()*TAU,d=s.r+srnd(8,60);tree(x+Math.cos(a)*d,z+Math.sin(a)*d,srnd(.9,1.3))}}
  // 野外樹林
  const nT=W.id==='desert'?0:W.id==='forest'?70:40;const R=mulberry((W.seed||1)+313);
  for(let c=0;c<nT;c++){const cx=(R()*2-1)*(WORLD_HALF-150),cz=(R()*2-1)*(WORLD_HALF-150);if(Math.max(Math.abs(cx),Math.abs(cz))<W.half+150)continue;if(W.sats.some(s=>Math.hypot(s.x-cx,s.z-cz)<s.r+90))continue;
    const n=W.id==='forest'?55:35;for(let i=0;i<n;i++)tree(cx+srnd(-70,70),cz+srnd(-70,70),srnd(.9,1.5))}
  if(W.id==='desert')for(let c=0;c<60;c++){const cx=(R()*2-1)*(WORLD_HALF-150),cz=(R()*2-1)*(WORLD_HALF-150);if(Math.max(Math.abs(cx),Math.abs(cz))<W.half+150)continue;for(let i=0;i<5;i++)palm(cx+srnd(-12,12),cz+srnd(-12,12))}
  // 撤離模式：最遠的 3 個據點各有一個撤離點；4 個據點有車庫
  if(W.mode==='extract'){const far=W.sats.slice().sort((a,b)=>Math.hypot(b.x,b.z)-Math.hypot(a.x,a.z));
    far.slice(0,3).forEach(s=>extractPoint('std',s.x+s.r*.5,s.z-s.r*.5,s.name.replace(/（.*/,'')+'撤離'));
    far.slice(3,7).forEach(s=>garage(s.x-s.r*.6,s.z+s.r*.4,SR()<.5))}
  if(W.mode==='conquest')for(const sx of [-1,1]){const ax=sx*(W.half+260);road(ax,0,26,180);landmark(sx<0?'藍方機場':'紅方機場',ax,0,60);
    for(const dz of [-40,40])sbox(ax+sx*40,dz,22,16,7,'metal',0,{uv:3})}}

/* 守軍：每個據點 2–3 人（撤離模式） */
function spawnSatGuards(){if(!W.sats||M.mode!=='extract'||(M.net&&!M.isHost))return;const D=DIFFS[M.diff];
  for(const s of W.sats){const n=2+(Math.random()<.5?1:0);for(let i=0;i<n;i++){const p=freePointNear(s.x+rnd(-s.r*.5,s.r*.5),s.z+rnd(-s.r*.5,s.r*.5),8);makeBot(Math.random()<D.heavy?'heavy':'grunt',2,p.x,0,p.z)}}}

/* ---------- 外圍地形網格（跟著玩家） ---------- */
let farMesh=null,farC={x:1e9,z:1e9};
const FAR_SPAN=3200;
function farMeshInit(){farMesh=null;farC={x:1e9,z:1e9};if(!FAR)return;const n=FAR_SPAN/FAR_RES+1;const P_=new Float32Array(n*n*3),C=new Float32Array(n*n*3),U=new Float32Array(n*n*2);
  const I=new Uint32Array((n-1)*(n-1)*6);let k=0;for(let z=0;z<n-1;z++)for(let x=0;x<n-1;x++){const a=z*n+x,b=a+1,c=a+n,d=c+1;I[k++]=a;I[k++]=c;I[k++]=b;I[k++]=b;I[k++]=c;I[k++]=d}
  const g=new T.BufferGeometry();g.setAttribute('position',new T.BufferAttribute(P_,3));g.setAttribute('color',new T.BufferAttribute(C,3));g.setAttribute('uv',new T.BufferAttribute(U,2));g.setIndex(new T.BufferAttribute(I,1));
  const mat=MAT.ground.clone();if(mat.map){mat.map=mat.map.clone();mat.map.repeat.set(1,1);mat.map.needsUpdate=true}mat.vertexColors=true;mat.color=new T.Color(0xffffff);mat.polygonOffset=true;mat.polygonOffsetFactor=3;mat.polygonOffsetUnits=3;
  farMesh=new T.Mesh(g,mat);farMesh.receiveShadow=true;farMesh.frustumCulled=false;scene.add(farMesh);W.meshes.push(farMesh);farMesh.userData.n=n}
function farMeshUpdate(px,pz,force){if(!farMesh)return;const cx=Math.round(px/400)*400,cz=Math.round(pz/400)*400;if(!force&&cx===farC.x&&cz===farC.z)return;farC={x:cx,z:cz};
  const g=farMesh.geometry,n=farMesh.userData.n,pos=g.attributes.position.array,col=g.attributes.color.array,uv=g.attributes.uv.array,o0x=cx-FAR_SPAN/2,o0z=cz-FAR_SPAN/2;
  const base=new T.Color(THEME.ground||'#6a6a5a'),rock=new T.Color(THEME.mtn||0x6a6a60);const rr=[rock.r/Math.max(.05,base.r),rock.g/Math.max(.05,base.g),rock.b/Math.max(.05,base.b)].map(v=>clamp(v,.55,1.5));
  for(let z=0;z<n;z++)for(let x=0;x<n;x++){const i=z*n+x,wx=o0x+x*FAR_RES,wz=o0z+z*FAR_RES;let y;if(inNear(wx,wz,45))y=terrH(wx,wz)-4;else y=terrH(wx,wz);pos[i*3]=wx;pos[i*3+1]=y;pos[i*3+2]=wz;uv[i*2]=wx/7;uv[i*2+1]=wz/7}
  g.attributes.position.needsUpdate=true;g.attributes.uv.needsUpdate=true;g.computeVertexNormals();const nr=g.attributes.normal.array;
  for(let i=0;i<n*n;i++){const sl=1-nr[i*3+1];const kk=clamp(sl*3.2,0,.75);const hgt=pos[i*3+1];const lit=(1+clamp(hgt/(FAR.amp*2.5),0,1)*.14)*(1-kk*.18);for(let c=0;c<3;c++)col[i*3+c]=(1+(rr[c]-1)*kk)*lit}
  g.attributes.color.needsUpdate=true;g.computeBoundingSphere()}
function updateFarTerrain(){if(farMesh&&P)farMeshUpdate(P.car?P.car.pos.x:P.pos.x,P.car?P.car.pos.z:P.pos.z)}

/* ---------- 地圖底圖（全世界） ---------- */
let worldBase=null;
function buildWorldBase(){worldBase=null;if(!FAR)return;const N=256,c=document.createElement('canvas');c.width=c.height=N;const g=c.getContext('2d'),im=g.createImageData(N,N),st=WORLD_HALF*2/N,b0=THEME.snowy?[42,47,51]:[27,29,25];
  for(let j=0;j<N;j++)for(let i=0;i<N;i++){const x=-WORLD_HALF+(i+.5)*st,z=-WORLD_HALF+(j+.5)*st,y=farH(x,z);const sh=clamp((farH(x-st,z-st)-farH(x+st,z+st))*.05,-.5,.5),el=clamp(y/(FAR.amp*2.5),0,1.4)*18;
    const k=(j*N+i)*4,v=sh*45+el;im.data[k]=clamp(b0[0]+v,0,255);im.data[k+1]=clamp(b0[1]+v,0,255);im.data[k+2]=clamp(b0[2]+v*.85,0,255);im.data[k+3]=255}
  g.putImageData(im,0,0);worldBase=c}
