'use strict';
/* ================= 定期活動（依現實日期輪替，每 2 天換一次） =================
   1. 特殊頭目「鋼鐵巨獸」：烽火撤離會在某個地標出現 3 倍血量的頭目，帶著保底大紅。
   2. 特殊地圖「血月之夜」：烽火撤離固定從晚上 22:00 開始，紅色月光與霧，所有容器爆率 +30%。
   3. 特殊探員：輪到的探員技能冷卻 -30%、爆率 +20%，而且紫／金／紅皮全部免費試用。
   4. 特殊任務：委託欄多一個活動委託（駭入 3 名敵人並成功撤離），獎勵 $2,500,000。
   出擊頁最上方會顯示目前活動與剩餘時間。 */
const LIVE_EVENTS=[
  {id:'boss',name:'特殊頭目 · 鋼鐵巨獸',desc:'烽火撤離中，某個地標會出現 3 倍血量的頭目「鋼鐵巨獸」，擊殺後保底掉落大紅。'},
  {id:'blood',name:'特殊地圖 · 血月之夜',desc:'烽火撤離固定從 22:00 夜晚開始，紅色月光籠罩全圖，所有容器爆率 +30%。'},
  {id:'op',name:'特殊探員',desc:''},
  {id:'mission',name:'特殊任務 · 幽靈駭客',desc:'委託欄多一個活動委託：在烽火撤離駭入 3 名敵人並成功撤離，獎勵 $2,500,000。'}];
const LIVE_EPOCH=Date.UTC(2026,0,1),LIVE_LEN=2*864e5;
function liveEvent(now){now=now||Date.now();const k=Math.floor((now-LIVE_EPOCH)/LIVE_LEN);const e=Object.assign({},LIVE_EVENTS[((k%4)+4)%4]);e.ends=LIVE_EPOCH+(k+1)*LIVE_LEN;e.key=k;
  if(e.id==='op'){const id=OP_IDS[((k%OP_IDS.length)+OP_IDS.length)%OP_IDS.length];e.op=id;e.name='特殊探員 · '+OPERATORS[id].name;e.desc=`使用「${OPERATORS[id].name}」時技能冷卻 -30%、烽火爆率 +20%，紫／金／紅皮免費試用。`}return e}
function liveLeft(e){const ms=e.ends-Date.now();const h=Math.floor(ms/36e5),m=Math.floor(ms%36e5/6e4);return h>=24?`${Math.floor(h/24)} 天 ${h%24} 小時`:`${h} 小時 ${m} 分`}
function liveIs(id){const e=liveEvent();return e.id===id?e:null}
// 掛勾
function liveLootK(){let k=1;if(M.mode==='extract'&&M.live&&M.live.id==='blood')k*=1.3;if(M.mode==='extract'&&M.live&&M.live.id==='op'&&P&&P.op===M.live.op)k*=1.2;return k}
function liveCdK(){return M.live&&M.live.id==='op'&&P&&P.op===M.live.op?.7:1}
function liveSkinFree(op){const e=liveEvent();return e.id==='op'&&e.op===op}
function liveStart(){M.live=liveEvent();const e=M.live;if(M.mode!=='extract')return;
  if(e.id==='blood'){M.clock=22;M.blood=true;banner('活動：血月之夜','所有容器爆率 +30%',3)}
  if(e.id==='boss'&&(!M.net||M.isHost)){const L=(W.landmarks||[]).filter(l=>!['車庫','坦克','直升機','戰鬥機'].includes(l.name)&&Math.max(Math.abs(l.x),Math.abs(l.z))<W.half);const l=L.length?pick(L):{x:0,z:0};
    const p=freePointNear(l.x,l.z,14);const b=makeBot('boss',2,p.x,0,p.z);b.hp*=3;b.maxHp*=3;b.extraRed=true;b.eventBoss=true;b.scale=(b.scale||1)*1.15;if(b.R&&b.R.root)b.R.root.scale.multiplyScalar(1.15);
    for(let i=0;i<3;i++){const q=freePointNear(l.x,l.z,12);makeBot('heavy',2,q.x,0,q.z)}
    banner('活動：鋼鐵巨獸出沒',`出現在「${l.name||'地圖中央'}」附近 · 擊殺保底大紅`,3.2)}
  if(e.id==='op'&&P.op===e.op)note(`活動探員 ${OPERATORS[e.op].name}：技能冷卻 -30%、爆率 +20%`)}
function liveTint(){if(!M.blood)return;scene.fog.color.lerp(_c2.setHex(0x4a0c0c),.55);scene.background.copy(scene.fog.color)}
// 活動委託
function liveQuest(){const e=liveEvent();if(e.id!=='mission')return null;return{type:'hack',n:3,prog:0,reward:2500000,live:e.key,desc:'【活動】在烽火撤離駭入 3 名敵人並成功撤離'}}
