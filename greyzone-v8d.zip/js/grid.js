'use strict';
/* ================= grid inventory (Delta-Force style) =================
   item object: {uid, t:'item'|'weapon'|'gear'|'ammo', id, n?, mag?, dur?, x, y, rot}
*/
let INV=null,itemSeq=1;
const GEAR_KIND={};for(const k in GEAR)for(const id in GEAR[k])GEAR_KIND[id]=k;
const GEAR_DIM={helmet:[2,2],armor:[3,3],rig:[3,2],bag:[3,3],pouch:[2,2],safe:[2,2]};
function mkItem(t,id,o){return Object.assign({uid:itemSeq++,t,id,x:0,y:0,rot:0},o||{})}
function baseDims(it){switch(it.t){case 'item':return[ITEMS[it.id].w,ITEMS[it.id].h];case 'ammo':return[1,1];
  case 'weapon':{const d=WEAPONS[it.id];return d.slot==='pistol'?[2,1]:d.model==='smg'?[3,2]:(d.model==='sniper'||d.model==='lmg'||d.model==='dmr')?[5,2]:[4,2]}
  case 'gear':return GEAR_DIM[GEAR_KIND[it.id]]||[2,2]}return[1,1]}
function itemDims(it){const [w,h]=baseDims(it);return it.rot?[h,w]:[w,h]}
function dimsOf(it,rot){const [w,h]=baseDims(it);return rot?[h,w]:[w,h]}
function itemName(it){switch(it.t){case 'item':return ITEMS[it.id].name;case 'ammo':return AMMO[it.id].name+' ×'+it.n;case 'weapon':return WEAPONS[it.id].name;case 'gear':return GEAR[GEAR_KIND[it.id]][it.id].name+(it.inner&&it.inner.length?`（內含 ${it.inner.length} 件）`:'')}return'?'}
function itemValue(it){switch(it.t){case 'item':return ITEMS[it.id].v;case 'ammo':return Math.round(AMMO[it.id].price*it.n*.5);case 'weapon':return Math.round(WEAPONS[it.id].price*.5);case 'gear':{const g=GEAR[GEAR_KIND[it.id]][it.id];return Math.round(g.price*.5*(g.dur&&it.dur!=null?Math.max(.3,it.dur/g.dur):1))+(it.inner||[]).reduce((s,o)=>s+itemValue(o),0)}}return 0}
function itemRarity(it){if(it.t==='item')return ITEMS[it.id].r;if(it.t==='weapon'){const d=WEAPONS[it.id];return d.crate?2+d.crate:d.price>=500000?3:d.price>=250000?2:1}if(it.t==='gear'){const g=GEAR[GEAR_KIND[it.id]][it.id];return g.tier?Math.min(6,g.tier):g.price>=500000?4:g.price>=150000?3:g.price?2:0}return 0}
function isRed(it){return itemRarity(it)>=5&&it.t==='item'}

/* ---------- grid ops ---------- */
function mkGrid(name,w,h){return{name,w,h,cap:w*h,items:[]}}
function giFits(c,x,y,w,h,ignore){if(x<0||y<0||x+w>c.w||y+h>c.h)return false;for(const o of c.items){if(o===ignore)continue;const [ow,oh]=itemDims(o);if(x<o.x+ow&&x+w>o.x&&y<o.y+oh&&y+h>o.y)return false}return true}
function giFind(c,it){if(!c||!c.w)return null;for(const rot of (baseDims(it)[0]===baseDims(it)[1]?[0]:[it.rot||0,it.rot?0:1])){const [bw,bh]=baseDims(it);const w=rot?bh:bw,h=rot?bw:bh;for(let y=0;y<=c.h-h;y++)for(let x=0;x<=c.w-w;x++)if(giFits(c,x,y,w,h))return{x,y,rot}}return null}
function giPut(c,it){const p=giFind(c,it);if(!p)return false;it.x=p.x;it.y=p.y;it.rot=p.rot;c.items.push(it);return true}
function giRemove(c,it){const i=c.items.indexOf(it);if(i>=0)c.items.splice(i,1);return i>=0}
function giUsed(c){let s=0;for(const o of c.items){const [w,h]=itemDims(o);s+=w*h}return s}

/* ---------- player inventory API ---------- */
function makeInv(lo){const g=GEAR;const r=g.rig[lo.rig||'rig0'],b=g.bag[lo.bag||'bag0'],s=g.safe[PF.safe||'safe0'];
  const inv={pockets:mkGrid('口袋',4,1),rig:mkGrid('胸掛',r.grid[0],r.grid[1]),bag:mkGrid('背包',b.grid[0],b.grid[1]),safe:mkGrid('保險箱',s.grid[0],s.grid[1])};
  Object.defineProperty(inv,'ids',{value:{rig:lo.rig||'rig0',bag:lo.bag||'bag0',pouch:lo.pouch||'pouch0'},enumerable:false,writable:true});return inv}
const INV_ORDER={use:['rig','pockets','bag'],val:['bag','pockets','rig']};
function invAddObj(it,order){order=order||(it.t==='item'&&(ITEMS[it.id].use||ITEMS[it.id].key)?INV_ORDER.use:INV_ORDER.val);for(const k of order){if(INV[k]&&giPut(INV[k],it))return k}return null}
function invAdd(id,only){return invAddObj(mkItem('item',id),only?[only]:null)}
function invUsed(c){return giUsed(c)}
function invFree(c){return c.cap-giUsed(c)}
function invAll(){const out=[];for(const k in INV)for(const it of INV[k].items)out.push([k,it]);return out}
function invCount(id){let n=0;for(const k in INV)for(const it of INV[k].items)if(it.t==='item'&&it.id===id)n++;return n}
function invTake(id){for(const k of ['rig','pockets','bag','safe']){const c=INV[k];const it=c.items.find(o=>o.t==='item'&&o.id===id);if(it){giRemove(c,it);if(UI.invOpen)renderInventory();return true}}return false}
function invValue(includeSafe=true){let v=0;for(const k in INV){if(k==='safe'&&!includeSafe)continue;for(const it of INV[k].items)if(!(it.t==='item'&&ITEMS[it.id].use))v+=itemValue(it)}return v}
function hasKey(col){for(const k in INV)for(const it of INV[k].items)if(it.t==='item'&&ITEMS[it.id].key===col)return true;return false}
function applyPouch(id){const mul=GEAR.pouch[id].mul;for(const k in AMMO){P.ammoCap[k]=Math.round(AMMO[k].base*mul);P.ammo[k]=Math.min(P.ammo[k]||0,P.ammoCap[k])}}

/* ---------- containers (world loot) ---------- */
const CONT_DIM={crate:[5,3],weapon:[6,3],med:[4,2],safe:[4,3],pc:[3,2],vault:[6,4],airdrop:[7,4],body:[6,4],drop:[8,6],bagdrop:[10,10]};
function ensureGrid(c){if(c.grid)return c.grid;const [w,h]=CONT_DIM[c.type]||[6,4];const g=mkGrid({crate:'物資箱',weapon:'武器箱',med:'醫療箱',safe:'保險櫃',vault:'金庫寶箱',pc:'電腦主機',airdrop:'空投箱',body:'遺體',drop:'地面',bagdrop:'掉落的背包'}[c.type]||'容器',w,h);c.grid=g;
  const src=c.items||[];c.items=[];for(const e of src){const it=e.uid?e:e.ammo?mkItem('ammo',e.ammo,{n:e.n}):e.wid?mkItem('weapon',e.wid,{mag:e.mag}):e.gear?mkItem('gear',e.gear,{dur:e.dur}):mkItem('item',e.id);if(!giPut(g,it)){g.h++;g.cap=g.w*g.h;giPut(g,it)}}
  return g}

/* ---------- inventory overlay ---------- */
UI.lootC=null;
function toggleInventory(force){if(!M.running)return;const open=force!==undefined?force:!UI.invOpen;if(open===UI.invOpen&&force!==undefined){if(open)renderInventory();return}
  UI.invOpen=open;$('inv').hidden=!open;if(open){unlockPointer();if(!UI.lootC){const g=nearGround();if(g)UI.lootC=g}renderInventory()}else{UI.lootC=null;dragEnd(true);lockPointer()}}
$('invClose').onclick=()=>toggleInventory(false);
function openLoot(c){ensureGrid(c);if(!c.rolled&&c.sid!=null){c.rolled=true;shareContainer(c)}if(c.type==='airdrop'&&typeof airdrop!=='undefined'&&airdrop)airdrop.looted=true;if(!c.rolled){c.rolled=true}UI.lootC=c;toggleInventory(true)}
function nearGround(){let best=null,bd=2.6;for(const c of W.containers){if(c.type!=='drop'&&c.type!=='bagdrop'&&!(c.grid&&c.searched===false&&c.opened))continue;if(c.grid&&!c.grid.items.length)continue;const d=Math.hypot(c.x-P.pos.x,c.z-P.pos.z);if(d<bd&&Math.abs(c.y-P.pos.y)<2){bd=d;best=c}}return best}
const CELL=()=>innerHeight<520||innerWidth<700?34:52;
// 價值分級：名字的顏色代表值多少錢（白 < 綠 < 藍 < 紫 < 金 < 紅）
const VAL_TIERS=[[0,'#d8d0bf','一般'],[8000,'#8fd17a','普通'],[30000,'#6db5ff','精良'],[100000,'#c08cff','稀有'],[400000,'#ffc94d','史詩'],[1500000,'#ff5a48','傳說（大紅）']];
function valTier(v){let t=VAL_TIERS[0];for(const x of VAL_TIERS)if(v>=x[0])t=x;return t}
function itemEl(it,gkey){const [w,h]=itemDims(it);const cs=CELL();const v=itemValue(it);const vt=valTier(v);const d=document.createElement('div');d.className='it'+(vt===VAL_TIERS[5]?' red':'')+(it.t==='weapon'?' wpn':'')+(w===1?' w1':'');
  d.style.cssText=`left:${it.x*cs}px;top:${it.y*cs}px;width:${w*cs-2}px;height:${h*cs-2}px;--rc:${vt[1]}`;d.dataset.uid=it.uid;d.dataset.g=gkey;
  d.innerHTML=`<b style="color:${vt[1]}">${esc(itemName(it))}</b>${it.t==='gear'&&it.dur!=null&&GEAR[GEAR_KIND[it.id]][it.id].dur?`<i>${Math.ceil(it.dur)}/${GEAR[GEAR_KIND[it.id]][it.id].dur}</i>`:''}${v?`<s>${fmt(v)}</s>`:''}`;
  d.title=itemName(it)+(v?' · '+fmt(v)+' · '+vt[2]:'')+` · ${w}×${h} 格`;return d}
const ICON_SHAPE={
  rifle:'<path d="M2 11h30l3-2h7v4h-6l-1 2h-6l-2 6h-5l1-6H10l-2 4H3l1-4H2z"/><rect x="18" y="6" width="9" height="3"/>',
  smg:'<path d="M4 10h24l2-2h6v4h-6l-2 2h-5l-2 7h-5l1-7H9l-2 3H3z"/>',
  pistol:'<path d="M6 8h28v5H18l-2 9h-7l2-9H6z"/>',
  sniper:'<path d="M1 12h34l2-1h8v3h-7l-2 2h-9l-2 5h-5l1-5H9l-3 3H2z"/><rect x="14" y="7" width="12" height="3" rx="1.5"/>',
  shotgun:'<path d="M2 11h36v3H26v2h-8l-2 5h-5l1-5H8l-3 3H2z"/><rect x="20" y="15" width="10" height="2"/>',
  lmg:'<path d="M2 11h32l3-2h6v4h-6l-1 2h-8v5h-9v-5H10l-2 4H3l1-4H2z"/><rect x="16" y="6" width="8" height="3"/>',
  helmet:'<path d="M6 22c0-9 6-15 14-15s14 6 14 15H6z"/><rect x="4" y="21" width="32" height="3" rx="1.5"/>',
  armor:'<path d="M12 4h5l3 4 3-4h5l6 6-3 4v16H9V14l-3-4z"/>',
  rig:'<path d="M12 4h5l3 4 3-4h5l6 6-3 4v16H9V14l-3-4z"/><rect x="11" y="18" width="5" height="6" fill="#0008"/><rect x="18" y="18" width="5" height="6" fill="#0008"/><rect x="25" y="18" width="5" height="6" fill="#0008"/>',
  bag:'<path d="M12 8c0-4 4-6 8-6s8 2 8 6h2c2 0 3 2 3 4v16c0 2-2 3-3 3H10c-2 0-3-1-3-3V12c0-2 1-4 3-4z"/><rect x="13" y="17" width="14" height="7" rx="2" fill="#0006"/>',
  pouch:'<rect x="3" y="12" width="34" height="5" rx="2"/><rect x="6" y="8" width="7" height="11" rx="1"/><rect x="16" y="8" width="7" height="11" rx="1"/><rect x="26" y="8" width="7" height="11" rx="1"/>',
  med:'<rect x="6" y="6" width="28" height="22" rx="3"/><path d="M17 10h6v5h5v6h-5v5h-6v-5h-5v-6h5z" fill="#c33"/>',
  repair:'<path d="M27 4a7 7 0 0 0-6 10L7 28l4 4 14-14a7 7 0 0 0 10-6l-4 4-4-1-1-4z"/>',
  flare:'<rect x="17" y="10" width="7" height="20" rx="2"/><path d="M20 2c3 3 4 6 0 8-4-2-3-5 0-8z" fill="#f63"/>',
  key:'<rect x="5" y="9" width="30" height="18" rx="2"/><rect x="8" y="12" width="8" height="6" fill="#0007"/><rect x="8" y="21" width="20" height="2" fill="#0007"/>',
  gem:'<path d="M10 8h20l6 7-16 17L4 15z"/><path d="M4 15h32M14 8l6 7 6-7M20 15v17" stroke="#fff6" fill="none"/>',
  bar:'<path d="M6 26l5-12h18l5 12z"/><path d="M11 14l3-6h12l3 6" fill="#fff3"/>',
  chip:'<rect x="9" y="9" width="22" height="22" rx="2"/><rect x="14" y="14" width="12" height="12" fill="#0006"/><path d="M12 5v4M18 5v4M24 5v4M28 5v4M12 31v4M18 31v4M24 31v4M28 31v4M5 12h4M5 18h4M5 24h4M31 12h4M31 18h4M31 24h4" stroke="currentColor" stroke-width="2"/>',
  disk:'<rect x="6" y="6" width="28" height="26" rx="3"/><circle cx="20" cy="18" r="7" fill="#0006"/><circle cx="20" cy="18" r="2"/>',
  device:'<rect x="8" y="4" width="24" height="30" rx="3"/><rect x="11" y="8" width="18" height="18" fill="#0006"/>',
  box:'<path d="M4 12l16-7 16 7v16l-16 7-16-7z"/><path d="M4 12l16 7 16-7M20 19v16" stroke="#0006" fill="none" stroke-width="2"/>',
  bullet:'<path d="M9 30V14c0-5 3-9 3-9s3 4 3 9v16z"/><path d="M18 30V14c0-5 3-9 3-9s3 4 3 9v16z"/><path d="M27 30V14c0-5 3-9 3-9s3 4 3 9v16z"/>',
};
const ITEM_ICON={med:'med',surg:'med',repair:'repair',flare:'flare',keyR:'key',keyB:'key',gem:'gem',core:'gem',gold:'bar',statue:'bar',hdd:'disk',usb:'chip',gpu:'chip',parts:'chip',server:'chip',qcpu:'chip',radarc:'chip',phone:'device',tablet:'device',ctrl:'device',radio:'device',watch:'gem'};
function iconKey(it){if(it.t==='weapon'){const m=WEAPONS[it.id].model;return m==='ak'?'rifle':m==='dmr'?'sniper':m}if(it.t==='gear')return GEAR_KIND[it.id]==='safe'?'box':GEAR_KIND[it.id];if(it.t==='ammo')return'bullet';return ITEM_ICON[it.id]||'box'}
function iconSVG(it,w,h){const k=iconKey(it);const wide=it.t==='weapon';const vb=wide?'0 0 46 34':'0 0 40 36';const rot=it.rot&&wide?'transform="rotate(90 23 17)"':'';return`<svg class="ic" viewBox="${vb}" preserveAspectRatio="xMidYMid meet" aria-hidden="true"><g fill="currentColor" ${rot}>${ICON_SHAPE[k]||ICON_SHAPE.box}</g></svg>`}
const fmtK=v=>v>=1e6?(v/1e6).toFixed(v>=1e7?0:1)+'M':v>=1e3?Math.round(v/1e3)+'K':String(v);
function gridEl(c,gkey,title,extra){const cs=CELL();const box=document.createElement('div');box.className='gbox';const used=giUsed(c);
  box.innerHTML=`<h3>${title}<span>${used}/${c.cap}</span></h3>`;if(!c.w){box.innerHTML+=`<p class="hint" style="margin:0">${extra||'未攜帶'}</p>`;return box}
  const g=document.createElement('div');g.className='g';g.dataset.g=gkey;g.style.cssText=`width:${c.w*cs}px;height:${c.h*cs}px;--cs:${cs}px`;for(const it of c.items)g.appendChild(itemEl(it,gkey));box.appendChild(g);return box}
function gridByKey(k){return k==='loot'?(UI.lootC&&UI.lootC.grid):INV[k]}
function slotEl(key,label,txt,col){const d=document.createElement('div');d.className='eslot';d.dataset.slot=key;d.innerHTML=`<small>${label}</small><b style="color:${col||'var(--text)'}">${esc(txt)}</b>`;return d}
function renderInventory(){if(!UI.invOpen)return;const root=$('invGrid');root.innerHTML='';$('invVal').textContent=fmt(invValue());
  const L=document.createElement('div');L.className='icol';
  if(UI.lootC){const c=UI.lootC;ensureGrid(c);L.appendChild(gridEl(c.grid,'loot',c.grid.name));const b=document.createElement('div');b.className='btns';const all=document.createElement('button');all.type='button';all.className='mini';all.textContent='全部拿取';all.onclick=()=>{lootAll();renderInventory()};b.appendChild(all);L.appendChild(b);
    if(M.mode==='extract'){const z=document.createElement('div');z.className='gbox eslot discard';z.dataset.slot='discard';z.innerHTML='<h3>丟棄區<span>拖到這裡</span></h3><p class="hint" style="margin:0">丟在你腳下的地上。這場所有玩家都看得到、也撿得到。</p>';L.appendChild(z)}}
  else{const p=document.createElement('div');p.className='gbox';p.innerHTML='<h3>地面<span></span></h3><p class="hint" style="margin:0">把物品拖到任何空白處（不是格子的地方）就會丟在地上，其他玩家也撿得到。搜索容器時，內容會出現在這裡。</p>';L.appendChild(p);
    if(M.mode==='extract'){const b=document.createElement('div');b.className='gbox bury';b.dataset.slot='bury';b.innerHTML=`<h3>埋藏<span>${(PF.buried||[]).length}/5</span></h3><p class="hint" style="margin:0">把物品拖到這裡，會埋在你現在的位置；下次來 ${MAPS[W.id].name} 可以挖出來（陣亡也不會遺失）。</p>`;b.classList.add('eslot');L.appendChild(b)}}
  const E=document.createElement('div');E.className='icol eq';
  const tierC=t=>RARITY[Math.min(6,t)]||'var(--text)';
  E.appendChild(slotEl('helmet','頭盔',P.helmet.tier?`${GEAR.helmet[P.helmet.id]?GEAR.helmet[P.helmet.id].name:'頭盔'} ${Math.ceil(P.helmet.dur)}/${P.helmet.max}`:'無',tierC(P.helmet.tier)));
  E.appendChild(slotEl('armor','護甲',P.armor.tier?`${GEAR.armor[P.armor.id]?GEAR.armor[P.armor.id].name:'護甲'} ${Math.ceil(P.armor.dur)}/${P.armor.max}`:'無',tierC(P.armor.tier)));
  E.appendChild(slotEl('rig','胸掛',GEAR.rig[INV.ids.rig].name));E.appendChild(slotEl('bag','背包',GEAR.bag[INV.ids.bag].name));E.appendChild(slotEl('pouch','彈掛',`${GEAR.pouch[INV.ids.pouch].name}（${GEAR.pouch[INV.ids.pouch].mags} 個）`));
  ['主武器','副武器','手槍'].forEach((l,i)=>{const s=P.slots[i];E.appendChild(slotEl('w'+i,l,s&&s.def?`${s.def.name} ${s.mag}/${s.st.mag}`:'空'))});
  const am=document.createElement('div');am.className='gbox';am.innerHTML='<h3>彈藥<span>備彈</span></h3>'+Object.keys(AMMO).filter(k=>P.ammo[k]>0||P.slots.some(s=>s&&s.def&&s.def.ammo===k)).map(k=>`<div class="irow eslot amrow" data-slot="ammo:${k}" title="拖曳可拿出一個彈匣的彈藥"><span>${AMMO[k].name}</span><span style="font-family:var(--f-num)">${P.ammo[k]} / ${P.ammoCap[k]}</span></div>`).join('');E.appendChild(am);
  const R=document.createElement('div');R.className='icol';
  R.appendChild(gridEl(INV.pockets,'pockets','口袋'));R.appendChild(gridEl(INV.rig,'rig','胸掛'));R.appendChild(gridEl(INV.bag,'bag','背包','沒有背包，可以使用「無背包撤離」點。'));R.appendChild(gridEl(INV.safe,'safe','保險箱（陣亡保留）'));
  root.append(L,E,R)}

/* ---------- drag & drop ---------- */
let DR=null;
function findItem(gkey,uid){const c=gridByKey(gkey);return c?c.items.find(o=>o.uid===uid):null}
$('invGrid').addEventListener('pointerdown',e=>{const el=e.target.closest('.it,.eslot');if(!el||e.button===2||el.dataset.slot==='bury'||el.dataset.slot==='discard')return;e.preventDefault();
  if(el.classList.contains('eslot')){const k=el.dataset.slot;DR={slot:k,sx:e.clientX,sy:e.clientY,moved:false,el};return}
  const it=findItem(el.dataset.g,+el.dataset.uid);if(!it)return;DR={it,from:el.dataset.g,sx:e.clientX,sy:e.clientY,moved:false,el,rot:it.rot,ox:e.offsetX,oy:e.offsetY,lx:e.clientX,ly:e.clientY}});
$('invGrid').addEventListener('dragstart',e=>e.preventDefault());
// 觸控或瀏覽器中斷拖曳時（pointercancel），用最後的位置當作放開
addEventListener('pointercancel',e=>{if(!DR)return;const d=DR;if(!d.moved){dragEnd(true);return}const t=dropTarget(d.lx,d.ly);dragEnd(false);if(t)doDrop(d,t);renderInventory()});
addEventListener('pointermove',e=>{if(!DR)return;if(!DR.moved&&Math.hypot(e.clientX-DR.sx,e.clientY-DR.sy)<6)return;
  if(!DR.moved){DR.moved=true;const g=document.createElement('div');g.id='dragGhost';document.body.appendChild(g);DR.ghost=g;if(DR.el)DR.el.style.opacity=.35;if(DR.slot&&!slotItem(DR.slot)){dragEnd(true);return}}
  ghostUpdate(e)});
function slotItem(k){if(k.startsWith('ammo:')){const c=k.slice(5);const n=Math.min(P.ammo[c],Math.max(10,...P.slots.filter(s=>s&&s.def&&s.def.ammo===c).map(s=>s.st.mag)));return n>0?mkItem('ammo',c,{n}):null}if(k==='helmet')return P.helmet.tier?mkItem('gear',P.helmet.id,{dur:P.helmet.dur}):null;if(k==='armor')return P.armor.tier?mkItem('gear',P.armor.id,{dur:P.armor.dur}):null;
  if(k[0]==='w'){const s=P.slots[+k[1]];return s&&s.def?mkItem('weapon',s.wid,{mag:s.mag}):null}
  if(k==='bag')return INV.ids.bag!=='bag0'?mkItem('gear',INV.ids.bag):null;if(k==='rig')return INV.ids.rig!=='rig0'?mkItem('gear',INV.ids.rig):null;if(k==='pouch')return INV.ids.pouch!=='pouch0'?mkItem('gear',INV.ids.pouch):null;return null}
function dragItem(d){d=d||DR;if(!d)return null;if(d.it)return d.it;if(!d.sit)d.sit=slotItem(d.slot);return d.sit}
function ghostUpdate(e){const it=dragItem();if(!it)return;DR.lx=e.clientX;DR.ly=e.clientY;const t=dropTarget(e.clientX,e.clientY);const [w,h]=dimsOf(it,t&&t.kind==='grid'?t.rot:(DR.rot||0));const cs=CELL();const g=DR.ghost;g.style.cssText=`left:${e.clientX-cs/2}px;top:${e.clientY-cs/2}px;width:${w*cs}px;height:${h*cs}px`;
  g.textContent=itemName(it)+(t&&t.kind==='ground'?' → 丟在地上':t&&t.kind==='slot'&&t.key==='discard'?' → 丟棄':'');g.classList.toggle('bad',!!t&&t.kind==='grid'&&!t.ok);g.classList.toggle('ok',!!t&&(t.kind!=='grid'||t.ok))}
function dropTarget(cx,cy){const it=dragItem();if(!it)return null;const g=DR.ghost;if(g)g.style.display='none';const el=document.elementFromPoint(cx,cy);if(g)g.style.display='';if(!el)return{kind:'ground'};
  const slot=el.closest('.eslot');if(slot)return{kind:'slot',key:slot.dataset.slot};
  const gr=el.closest('.g');const gb=!gr&&el.closest('.gbox');if(gb){const gg=gb.querySelector('.g');if(gg)return{kind:'box',g:gg.dataset.g,c:gridByKey(gg.dataset.g)}}if(!gr&&el.closest('.eq'))return{kind:'eq'};
  if(gr){const c=gridByKey(gr.dataset.g);const r=gr.getBoundingClientRect();const cs=CELL();const x=Math.floor((cx-r.left)/cs),y=Math.floor((cy-r.top)/cs);
    // 先試目前方向，放不下就自動試旋轉 90°
    for(const rot of [DR.rot||0,DR.rot?0:1]){const [w,h]=dimsOf(it,rot);if(w>c.w||h>c.h)continue;const tx=clamp(x,0,c.w-w),ty=clamp(y,0,c.h-h);if(giFits(c,tx,ty,w,h,DR.it||null))return{kind:'grid',g:gr.dataset.g,c,x:tx,y:ty,ok:true,rot}}
    const [w,h]=dimsOf(it,DR.rot||0);return{kind:'grid',g:gr.dataset.g,c,x:clamp(x,0,Math.max(0,c.w-w)),y:clamp(y,0,Math.max(0,c.h-h)),ok:false,rot:DR.rot||0}}
  return{kind:'ground'}}// 其他空白處（含面板空白）= 丟到地上
addEventListener('pointerup',e=>{if(!DR)return;const d=DR;if(d.moved){d.lx=e.clientX;d.ly=e.clientY}if(!d.moved){dragEnd(true);quickMove(d);renderInventory();return}const t=dropTarget(e.clientX,e.clientY);dragEnd(false);if(t)doDrop(d,t);renderInventory()});
function dragEnd(cancel){if(!DR)return;if(DR.ghost)DR.ghost.remove();if(DR.el)DR.el.style.opacity='';DR=null}
addEventListener('keydown',e=>{if(!UI.invOpen)return;if(e.code==='KeyR'&&DR&&DR.moved){DR.rot=DR.rot?0:1;ghostUpdate({clientX:DR.lx,clientY:DR.ly});e.preventDefault()}
  if(e.code==='KeyP'){const el=document.querySelector('.it:hover');if(el){const c=gridByKey(el.dataset.g);const it=findItem(el.dataset.g,+el.dataset.uid);if(it&&el.dataset.g!=='loot'){giRemove(c,it);toGround(it);renderInventory()}}else{const sl=document.querySelector('.eq .eslot:hover');if(sl)discardSlot(sl.dataset.slot)}}});
function discardSlot(k){if(!k||!slotItem(k))return;if(k==='bag'||k==='rig'){dropContainerGear(k)}else{const x=unequip(k);if(x)toGround(x)}renderInventory()}
addEventListener('contextmenu',e=>{if(DR&&DR.moved){e.preventDefault();DR.rot=DR.rot?0:1;ghostUpdate(e)}});
// remove from source; returns item
function takeFromSource(d){if(d.it){giRemove(gridByKey(d.from),d.it);if(d.from==='loot')lootChanged();return d.it}return unequip(d.slot)}
function doDrop(d,t){const it=dragItem(d);if(!it)return;
  if(t.kind==='none')return;
  if(d.slot&&(t.kind==='grid'||t.kind==='box')&&t.g===d.slot){note('不能把容器放進它自己裡面');return}
  if(t.kind==='slot'&&t.key==='discard')t={kind:'ground'};
  if(t.kind==='box'){if(d.it&&d.from===t.g)return;if(d.slot&&!canUnequip(d.slot))return;const x=takeFromSource(d);if(!x)return;if(!giPut(t.c,x)){if(d.it){gridByKey(d.from).items.push(x)}else if(!invAddObj(x))toGround(x);note('放不下');return}if(t.g==='loot')lootChanged();else maybeInspect(x,d.from);return}
  if(t.kind==='eq'){if(it.t==='weapon'){const k='w'+(WEAPONS[it.id].slot==='pistol'?2:(!P.slots[0]?0:!P.slots[1]?1:P.cur<2?P.cur:0));equipFrom(d,k)}else if(it.t==='gear')equipFrom(d,GEAR_KIND[it.id]);else if(it.t==='ammo'&&d.it){quickMove({it:d.it,from:d.from})}return}
  if(t.kind==='ground'){if(d.it&&d.from==='loot'&&UI.lootC&&UI.lootC.type==='drop')return;if(d.slot==='bag'||d.slot==='rig'){dropContainerGear(d.slot);return}const x=takeFromSource(d);if(x)toGround(x);return}
  if(t.kind==='slot'){if(t.key==='bury'){if(d.it&&d.from!=='loot'){if(buryItem(d.it))giRemove(gridByKey(d.from),d.it)}return}if(d.slot===t.key)return;equipFrom(d,t.key);return}
  if(t.kind==='grid'){const c=t.c;const rr=t.rot!=null?t.rot:(d.rot||0);d.rot=rr;const [w,h]=dimsOf(it,rr);
    if(d.it&&d.from===t.g&&t.ok){it.x=t.x;it.y=t.y;it.rot=rr;if(t.g==='loot')lootChanged();return}
    if(t.ok){if(d.slot&&!canUnequip(d.slot))return;const x=takeFromSource(d);if(!x)return;x.rot=rr;x.x=t.x;x.y=t.y;c.items.push(x);if(t.g==='loot')lootChanged();else maybeInspect(x,d.from);return}
    // swap with a single overlapped item
    if(d.it){const over=c.items.filter(o=>o!==d.it&&(()=>{const [ow,oh]=itemDims(o);return t.x<o.x+ow&&t.x+w>o.x&&t.y<o.y+oh&&t.y+h>o.y})());
      if(over.length===1){const o=over[0];const src=gridByKey(d.from);const ox=o.x,oy=o.y;const px=d.it.x,py=d.it.y,pr=d.it.rot;
        giRemove(src,d.it);giRemove(c,o);const [ow,oh]=itemDims(o);
        if(giFits(c,t.x,t.y,w,h)&&(c.items.push(d.it),d.it.x=t.x,d.it.y=t.y,d.it.rot=d.rot||0,giFits(src,px,py,ow,oh))){o.x=px;o.y=py;src.items.push(o);if(t.g==='loot'||d.from==='loot')lootChanged();return}
        giRemove(c,d.it);d.it.x=px;d.it.y=py;d.it.rot=pr;src.items.push(d.it);o.x=ox;o.y=oy;c.items.push(o)}}
    note('放不下')}}
function quickMove(d){if(d.slot){const it=slotItem(d.slot);if(!it)return;if(!canUnequip(d.slot)){note('先清空內容物才能卸下');return}const x=unequip(d.slot);if(x&&!invAddObj(x))toGround(x);return}
  const it=d.it;if(d.from==='loot'){if(it.t==='ammo'){const cap=P.ammoCap[it.id]-P.ammo[it.id];const take=Math.min(cap,it.n);if(take<=0){note('彈掛已滿');return}P.ammo[it.id]+=take;it.n-=take;if(it.n<=0)giRemove(UI.lootC.grid,it);lootChanged();blip(700,.05,'square',.04);return}
    if(it.t==='gear'&&autoEquipBetter(it)){giRemove(UI.lootC.grid,it);lootChanged();return}
    if(it.t==='weapon'){const pist=WEAPONS[it.id].slot==='pistol';const empty=pist?(!P.slots[2]||P.slots[2].def.free):(!P.slots[0]||!P.slots[1]);if(empty){giRemove(UI.lootC.grid,it);lootChanged();equipWeaponItem(it,null);return}}
    giRemove(UI.lootC.grid,it);if(!invAddObj(it)){UI.lootC.grid.items.push(it);note('空間不足')}else{maybeInspect(it,'loot');blip(880,.04,'square',.035)}lootChanged();return}
  if(UI.lootC){const c=UI.lootC.grid;const src=gridByKey(d.from);giRemove(src,it);if(!giPut(c,it)){src.items.push(it);note('容器空間不足')}else lootChanged();return}
  if(it.t==='ammo'){const room=P.ammoCap[it.id]-P.ammo[it.id];const tk=Math.min(room,it.n);if(tk<=0){note('彈掛已滿');return}P.ammo[it.id]+=tk;it.n-=tk;if(it.n<=0)giRemove(gridByKey(d.from),it);return}
  if(it.t==='item'){const u=ITEMS[it.id].use;if(u==='med'){toggleInventory(false);startHealWith(it.id);return}if(u==='repair'){startRepair();return}if(u==='flare'){toggleInventory(false);useFlare();return}if(u==='tmap'){if(M.mode!=='extract'){note('藏寶圖只能在烽火撤離使用');return}giRemove(gridByKey(d.from),it);readTreasureMap();return}}
  if(it.t==='weapon'){giRemove(gridByKey(d.from),it);equipWeaponItem(it,d.from);return}
  if(it.t==='gear'){equipFrom(d,GEAR_KIND[it.id]);return}}
function lootAll(){const c=UI.lootC;if(!c)return;for(const it of c.grid.items.slice()){quickMove({it,from:'loot'})}}
function lootChanged(){const c=UI.lootC;if(!c)return;if(!c.grid.items.length){c.searched=true;if(c.strip>=0)setStrip(c,0x3a3a34)}else{c.searched=false;if(c.strip>=0)setStrip(c,0xffb547)}if(c.gid)syncDrop(c);else shareContainer(c)}
// 連線時同步容器內容：一個人搜過，其他人打開只剩下他沒拿的東西
function shareContainer(c){if(!M.net||c.sid==null||!c.grid)return;netSend({t:'cg',i:c.sid,w:c.grid.w,h:c.grid.h,it:c.grid.items.map(serItem)})}
function onContainerMsg(m){if(!M.running)return;const c=W.containers.find(o=>o.sid===m.i);if(!c)return;if(!c.grid){c.items=[];ensureGrid(c)}c.grid.w=m.w;c.grid.h=m.h;c.grid.cap=m.w*m.h;c.grid.items=m.it.map(deItem);c.rolled=true;c.opened=true;
  c.searched=!c.grid.items.length;if(c.strip>=0)setStrip(c,c.searched?0x3a3a34:0xffb547);if(UI.invOpen&&UI.lootC===c)renderInventory()}

/* ---------- equip ---------- */
function canUnequip(k){return true}// 背包、胸掛連同內容物一起移動
function unequip(k){const it=slotItem(k);if(!it)return null;if(k.startsWith('ammo:')){P.ammo[it.id]-=it.n;return it}
  if(k==='helmet')P.helmet={id:'h0',tier:0,dur:0,max:0};else if(k==='armor')P.armor={id:'a0',tier:0,dur:0,max:0};
  else if(k[0]==='w'){const i=+k[1];const s=P.slots[i];if(s.vm)vmScene.remove(s.vm.g);P.slots[i]=null;if(P.cur===i){P.cur=P.slots.findIndex(x=>x);if(P.cur<0)P.cur=3}buildSlotButtons()}
  else if(k==='bag'){if(INV.bag.items.length)it.inner=INV.bag.items.slice();INV.ids.bag='bag0';INV.bag=mkGrid('背包',0,0)}
  else if(k==='rig'){if(INV.rig.items.length)it.inner=INV.rig.items.slice();INV.ids.rig='rig0';const r=GEAR.rig.rig0;INV.rig=mkGrid('胸掛',r.grid[0],r.grid[1])}
  else if(k==='pouch'){INV.ids.pouch='pouch0';applyPouch('pouch0')}
  return it}
function equipGear(it){const k=GEAR_KIND[it.id],g=GEAR[k][it.id];let old=null;
  if(k==='helmet'||k==='armor'){const cur=k==='helmet'?P.helmet:P.armor;if(cur.tier)old=mkItem('gear',cur.id,{dur:cur.dur});const o={id:it.id,tier:g.tier,dur:it.dur!=null?it.dur:g.dur,max:g.dur};if(k==='helmet')P.helmet=o;else P.armor=o;return{ok:true,old}}
  if(k==='rig'||k==='bag'){const ng=mkGrid(k==='rig'?'胸掛':'背包',g.grid[0],g.grid[1]);const cur=INV[k];const base=k==='rig'?'rig0':'bag0';
    // 新容器自己有東西：直接沿用；沒有：試著把目前的東西搬過去，搬不下就留在舊容器裡
    let carry=[];if(it.inner&&it.inner.length){for(const o of it.inner){if(!(giFits(ng,o.x,o.y,...itemDims(o))&&(ng.items.push(o),1))&&!giPut(ng,o))carry.push(o)}carry=carry.concat(cur.items)}
    else{const tmp=[];for(const o of cur.items){const sx=o.x,sy=o.y,sr=o.rot;if(giPut(ng,o))tmp.push(o);else{o.x=sx;o.y=sy;o.rot=sr;carry.push(o)}}}
    delete it.inner;
    if(INV.ids[k]!==base){old=mkItem('gear',INV.ids[k]);if(carry.length)old.inner=carry}else if(carry.length){for(const o of carry)if(!invAddObj(o))toGround(o)}
    INV[k]=ng;INV.ids[k]=it.id;return{ok:true,old}}
  if(k==='pouch'){if(INV.ids.pouch!=='pouch0')old=mkItem('gear',INV.ids.pouch);INV.ids.pouch=it.id;applyPouch(it.id);return{ok:true,old}}
  return{ok:false}}
function autoEquipBetter(it){const k=GEAR_KIND[it.id];if(k!=='helmet'&&k!=='armor')return false;const cur=k==='helmet'?P.helmet:P.armor;const g=GEAR[k][it.id];if(g.tier<=cur.tier)return false;const r=equipGear(it);if(r.old&&!invAddObj(r.old))toGround(r.old);note('已裝備 '+g.name);return true}
function equipFrom(d,key){const it=dragItem(d);if(!it)return;
  if(it.t==='weapon'&&key[0]==='w'){const i=+key[1];const pist=WEAPONS[it.id].slot==='pistol';if(pist!==(i===2)){note(pist?'手槍只能放手槍欄':'長槍不能放手槍欄');return}
    if(d.slot){const a=+d.slot[1];[P.slots[a],P.slots[i]]=[P.slots[i],P.slots[a]];buildSlotButtons();return}
    giRemove(gridByKey(d.from),it);if(d.from==='loot')lootChanged();equipWeaponItem(it,d.from,i);return}
  if(it.t==='gear'&&GEAR_KIND[it.id]===key){if(d.slot)return;const src=gridByKey(d.from);giRemove(src,it);const r=equipGear(it);if(!r.ok){src.items.push(it);return}if(d.from==='loot')lootChanged();
    if(r.old&&!giPut(src,r.old)&&!invAddObj(r.old))toGround(r.old);if(d.from==='loot'&&UI.lootC)lootChanged();note('已裝備 '+GEAR[key][it.id].name);return}
  note('不能放在這裡')}
function equipWeaponItem(it,from,slot){const w=WEAPONS[it.id];let i=slot!==undefined?slot:w.slot==='pistol'?2:(!P.slots[0]?0:!P.slots[1]?1:(P.cur<2?P.cur:0));
  const old=P.slots[i];if(old&&old.def&&!(old.def.free&&M.mode==='extract'&&false)){const oi=mkItem('weapon',old.wid,{mag:old.mag});const src=from?gridByKey(from):null;if(!(src&&giPut(src,oi))&&!invAddObj(oi))toGround(oi);if(from==='loot')lootChanged()}
  if(old&&old.vm)vmScene.remove(old.vm.g);const ns=makeSlot(it.id);ns.mag=it.mag!=null?Math.min(it.mag,ns.st.mag):ns.st.mag;P.slots[i]=ns;P.cur=i;P.switchT=.42;P.ads=false;buildSlotButtons();note('裝備 '+w.name);blip(700,.06,'square',.04)}

/* ---------- ground drops (synced) ---------- */
let dropSeq=1;
function makeDropC(x,y,z,type,gid){const c={type:type||'drop',pos:new T.Vector3(x,y+.3,z),x,z,y:y+.3,time:.2,searched:false,items:[],strip:-1,gid};ensureGrid(c);c.opened=true;
  const g=new T.Group();const m=new T.Mesh(new T.BoxGeometry(.5,.18,.35),new T.MeshStandardMaterial({color:type==='bagdrop'?0x4f5a3a:0x3a372e,roughness:.8}));m.position.y=.09;m.castShadow=true;g.add(m);
  const glow=new T.Sprite(new T.SpriteMaterial({map:softTex,color:0xffd28a,transparent:true,blending:T.AdditiveBlending,depthWrite:false,opacity:.5}));glow.scale.set(1,1,1);glow.position.y=.35;g.add(glow);g.position.set(x,y,z);scene.add(g);c.mesh=g;(W.dynObjs||(W.dynObjs=[])).push(g);
  W.containers.push(c);return c}
function toGround(it){let c=null,bd=1.6;for(const o of W.containers)if(o.type==='drop'&&o.gid){const d=Math.hypot(o.x-P.pos.x,o.z-P.pos.z);if(d<bd){bd=d;c=o}}
  if(!c||!giFind(c.grid,it))c=makeDropC(P.pos.x+rnd(-.4,.4),P.pos.y,P.pos.z+rnd(-.4,.4),'drop',(NET.myId||'me')+':'+(dropSeq++));
  giPut(c.grid,it)||(c.grid.h+=2,c.grid.cap=c.grid.w*c.grid.h,giPut(c.grid,it));c.searched=false;syncDrop(c);note('已丟在地上：'+itemName(it));blip(300,.05,'triangle',.04)}
function dropContainerGear(k){const id=INV.ids[k];if(id===(k==='rig'?'rig0':'bag0'))return;const c=makeDropC(P.pos.x,P.pos.y,P.pos.z,'bagdrop',(NET.myId||'me')+':'+(dropSeq++));
  const items=INV[k].items.slice();giPut(c.grid,mkItem('gear',id));for(const it of items){it.x=0;it.y=0;if(!giPut(c.grid,it)){c.grid.h+=3;c.grid.cap=c.grid.w*c.grid.h;giPut(c.grid,it)}}
  INV[k]=k==='rig'?mkGrid('胸掛',...GEAR.rig.rig0.grid):mkGrid('背包',0,0);INV.ids[k]=k==='rig'?'rig0':'bag0';syncDrop(c);note('已丟下'+(k==='rig'?'胸掛':'背包')+'（含內容物）')}
function serItem(it){const o={t:it.t,id:it.id,x:it.x,y:it.y,r:it.rot};if(it.n!=null)o.n=it.n;if(it.mag!=null)o.m=it.mag;if(it.dur!=null)o.d=Math.round(it.dur);if(it.inner&&it.inner.length)o.in=it.inner.map(serItem);return o}
function deItem(o){const it=mkItem(o.t,o.id,{x:o.x,y:o.y,rot:o.r,n:o.n,mag:o.m,dur:o.d});if(o.in)it.inner=o.in.map(deItem);return it}
function syncDrop(c){if(!M.net||!c.gid)return;netSend({t:'gd',gid:c.gid,x:+c.x.toFixed(2),y:+(c.y-.3).toFixed(2),z:+c.z.toFixed(2),ty:c.type,w:c.grid.w,h:c.grid.h,it:c.grid.items.map(serItem)})}
function onDropMsg(m){if(!M.running)return;let c=W.containers.find(o=>o.gid===m.gid);if(!c)c=makeDropC(m.x,m.y,m.z,m.ty,m.gid);c.grid.w=m.w;c.grid.h=m.h;c.grid.cap=m.w*m.h;
  c.grid.items=m.it.map(deItem);c.searched=!c.grid.items.length;if(c.mesh)c.mesh.visible=!c.searched;if(UI.invOpen&&UI.lootC===c)renderInventory()}
function updateDropsVis(){for(const c of W.containers)if(c.mesh)c.mesh.visible=!!(c.grid&&c.grid.items.length)}

/* ---------- misc helpers kept from the old inventory ---------- */
function startHealWith(id){if(P.healT>0||P.hp>=100)return;invTake(id);P.healItem=id;P.healT=ITEMS[id].time;P.healAmt=ITEMS[id].heal;P.reloadT=0;P.ads=false}
function dropItem(id){toGround(mkItem('item',id))}
function dropCurrentWeapon(){const s=curW();if(!s||s.knife||!s.def)return;if(s.def.free&&M.mode==='extract'){note('這把槍不能丟棄');return}const i=P.cur;dropWeapon(s.wid,P.pos,s.mag);if(s.vm)vmScene.remove(s.vm.g);P.slots[i]=null;P.cur=P.slots.findIndex(x=>x);if(P.cur<0)P.cur=3;buildSlotButtons();note('已丟下 '+s.def.name)}

/* ---------- 大紅 inspect ---------- */
let insR=null,insScene=null,insCam=null,insMesh=null,insRAF=0,insT=0;const inspected=new Set();
function maybeInspect(it,from){}// 已取消自動檢視（會擋住背包操作）
function showInspect(it){const ov=$('inspect');ov.hidden=false;$('insName').textContent=itemName(it);$('insVal').textContent=fmt(itemValue(it));blip(520,.2,'sine',.08);blip(780,.25,'sine',.08,0,.12);blip(1040,.4,'sine',.08,0,.26);
  const c=$('insC');if(!insR){insR=new T.WebGLRenderer({canvas:c,antialias:true,alpha:true});insR.outputEncoding=T.sRGBEncoding;insScene=new T.Scene();insScene.add(new T.HemisphereLight(0xffffff,0x402020,1.1));const l=new T.PointLight(0xff5040,2.5,10);l.position.set(1.5,1,2);insScene.add(l);const l2=new T.DirectionalLight(0xffe0c0,1);l2.position.set(-1,2,1);insScene.add(l2);insCam=new T.PerspectiveCamera(32,1,.1,20);insCam.position.set(0,.4,3.2);insCam.lookAt(0,0,0)}
  insR.setSize(c.clientWidth,c.clientHeight,false);insCam.aspect=c.clientWidth/c.clientHeight;insCam.updateProjectionMatrix();
  if(insMesh)insScene.remove(insMesh);const [w,h]=baseDims(it);insMesh=new T.Group();const body=new T.Mesh(new T.BoxGeometry(.5*w,.5*h,.35),new T.MeshStandardMaterial({color:0x8a1010,metalness:.7,roughness:.25,emissive:0x3a0505}));insMesh.add(body);
  const edge=new T.LineSegments(new T.EdgesGeometry(body.geometry),new T.LineBasicMaterial({color:0xffb0a0}));insMesh.add(edge);const gem=new T.Mesh(new T.OctahedronGeometry(.18),new T.MeshStandardMaterial({color:0xff5a48,emissive:0xff2010,emissiveIntensity:.8,metalness:.5,roughness:.1}));gem.position.z=.26;insMesh.add(gem);insScene.add(insMesh);
  insT=0;cancelAnimationFrame(insRAF);let last=performance.now();const tick=t=>{const dt=(t-last)/1000;last=t;insT+=dt;insMesh.rotation.y+=dt*1.6;insMesh.rotation.x=Math.sin(insT*1.2)*.25;insR.render(insScene,insCam);if(insT>3.2||$('inspect').hidden){$('inspect').hidden=true;return}insRAF=requestAnimationFrame(tick)};insRAF=requestAnimationFrame(tick)}
$('inspect').addEventListener('pointerdown',()=>{$('inspect').hidden=true});

function invTick(){if(UI.invOpen&&UI.lootC&&Math.hypot(UI.lootC.x-P.pos.x,UI.lootC.z-P.pos.z)>3.2){UI.lootC=null;renderInventory()}if(M.frame%20===0)updateDropsVis()}
