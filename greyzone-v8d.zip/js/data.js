'use strict';
/* ================= static game data ================= */
const AMMO={
  '556':{name:'5.56 步槍彈',base:150,price:120},
  '762':{name:'7.62 步槍彈',base:120,price:160},
  '57':{name:'5.7 小口徑彈',base:150,price:110},
  '9mm':{name:'9mm 手槍彈',base:150,price:60},
  '357':{name:'.357 左輪彈',base:36,price:220},
  '12g':{name:'12 號霰彈',base:40,price:300},
  '338':{name:'.338 狙擊彈',base:30,price:800},
  '50bmg':{name:'.50 BMG 重狙彈',base:20,price:1800},
};
// model: viewmodel family; slot: long | pistol; crate: only from weapon crates (tier 1-4)
const W_=(name,cls,slot,model,o)=>Object.assign({name,cls,slot,model,auto:false,head:2.2,hip:.03,ads:.003,recoil:.018,range:150,noise:48,adsT:.2},o);
const WEAPONS={
  // pistols
  g19:  W_('Glock 19','手槍','pistol','pistol',{rpm:480,dmg:38,head:2.5,mag:15,reload:1.3,hip:.018,ads:.004,recoil:.028,range:90,ammo:'9mm',noise:38,adsT:.12,price:0,free:true}),
  f92:  W_('92FS','手槍','pistol','pistol',{rpm:420,dmg:42,head:2.5,mag:15,reload:1.4,hip:.017,ads:.0038,recoil:.03,range:95,ammo:'9mm',noise:38,adsT:.12,price:80000}),
  m9:   W_('M9','手槍','pistol','pistol',{rpm:440,dmg:41,head:2.5,mag:17,reload:1.45,hip:.018,ads:.0038,recoil:.029,range:95,ammo:'9mm',noise:38,adsT:.12,price:90000}),
  m686: W_('M686 左輪','手槍','pistol','pistol',{rpm:170,dmg:80,head:2.4,mag:6,reload:2.4,hip:.022,ads:.004,recoil:.065,range:110,ammo:'357',noise:50,adsT:.14,price:180000}),
  // assault rifles
  ar57: W_('AR-57','突擊步槍','long','rifle',{auto:true,rpm:750,dmg:27,mag:50,reload:2.3,hip:.028,ads:.0026,recoil:.013,ammo:'57',noise:44,price:380000}),
  m16:  W_('M16','突擊步槍','long','rifle',{rpm:520,dmg:35,head:2.3,mag:30,reload:2.1,hip:.03,ads:.0022,recoil:.016,range:180,ammo:'556',price:300000}),
  m4a1: W_('M4A1','突擊步槍','long','rifle',{auto:true,rpm:800,dmg:29,head:2.3,mag:30,reload:2.0,ads:.0028,recoil:.016,ammo:'556',price:320000}),
  hk416:W_('HK416','突擊步槍','long','rifle',{auto:true,rpm:780,dmg:31,head:2.3,mag:30,reload:2.1,ads:.0025,recoil:.0135,ammo:'556',price:520000}),
  ak47: W_('AK-47','突擊步槍','long','ak',{auto:true,rpm:600,dmg:38,head:2.2,mag:30,reload:2.4,hip:.034,ads:.0034,recoil:.022,ammo:'762',noise:50,adsT:.22,price:340000}),
  t91:  W_('T91','突擊步槍','long','rifle',{auto:true,rpm:750,dmg:30,head:2.3,mag:30,reload:2.1,ads:.0029,recoil:.016,ammo:'556',price:280000}),
  t112: W_('T112','突擊步槍','long','rifle',{auto:true,rpm:760,dmg:33,head:2.3,mag:30,reload:2.0,ads:.0024,recoil:.013,ammo:'556',crate:1,price:600000}),
  t65k2:W_('T65K2','突擊步槍','long','rifle',{auto:true,rpm:700,dmg:30,head:2.2,mag:30,reload:2.2,hip:.032,ads:.003,recoil:.018,ammo:'556',price:240000}),
  // smg
  mp5:  W_('MP5','衝鋒槍','long','smg',{auto:true,rpm:850,dmg:24,head:2.0,mag:30,reload:1.8,hip:.021,ads:.0038,recoil:.009,range:85,ammo:'9mm',noise:40,adsT:.15,move:1.06,price:200000}),
  p90:  W_('P90','衝鋒槍','long','smg',{auto:true,rpm:900,dmg:23,head:2.0,mag:50,reload:2.3,hip:.02,ads:.0036,recoil:.0085,range:90,ammo:'57',noise:40,adsT:.15,move:1.05,price:360000}),
  mpx:  W_('MPX','衝鋒槍','long','smg',{auto:true,rpm:880,dmg:25,head:2.0,mag:30,reload:1.7,hip:.02,ads:.0035,recoil:.0085,range:90,ammo:'9mm',noise:40,adsT:.14,move:1.07,crate:1,price:420000}),
  t77:  W_('T77','衝鋒槍','long','smg',{auto:true,rpm:900,dmg:22,head:2.0,mag:30,reload:1.8,hip:.022,ads:.004,recoil:.0095,range:80,ammo:'9mm',noise:40,adsT:.15,move:1.06,price:180000}),
  uzi:  W_('Uzi','衝鋒槍','long','smg',{auto:true,rpm:950,dmg:21,head:1.9,mag:32,reload:1.8,hip:.024,ads:.0045,recoil:.011,range:70,ammo:'9mm',noise:40,adsT:.13,move:1.08,price:140000}),
  // marksman / sniper
  svd:  W_('SVD','射手步槍','long','dmr',{rpm:300,dmg:72,head:2.4,mag:10,reload:2.6,hip:.05,ads:.0011,recoil:.032,range:240,ammo:'762',noise:60,adsT:.26,price:550000}),
  mk14: W_('DMR 射手步槍','射手步槍','long','dmr',{rpm:330,dmg:63,head:2.4,mag:20,reload:2.5,hip:.048,ads:.0012,recoil:.03,range:220,ammo:'762',noise:58,adsT:.26,price:450000}),
  awm:  W_('AWM','狙擊步槍','long','sniper',{rpm:46,dmg:140,head:3,mag:5,reload:3,hip:.08,ads:.0003,recoil:.06,range:340,ammo:'338',noise:70,adsT:.32,bolt:true,baseZoom:1.4,crate:3,price:1500000}),
  m200: W_('M200','狙擊步槍','long','sniper',{rpm:44,dmg:155,head:3,mag:7,reload:3.2,hip:.08,ads:.00025,recoil:.065,range:360,ammo:'338',noise:72,adsT:.34,bolt:true,baseZoom:1.4,crate:4,price:2600000}),
  m95:  W_('M95','狙擊步槍','long','sniper',{rpm:40,dmg:190,head:3,mag:5,reload:3.6,hip:.09,ads:.0003,recoil:.08,range:380,ammo:'50bmg',noise:80,adsT:.38,bolt:true,baseZoom:1.4,move:.9,crate:4,price:3200000}),
  // lmg
  m249: W_('M249','輕機槍','long','lmg',{auto:true,rpm:800,dmg:30,head:2.1,mag:100,reload:4.2,hip:.045,ads:.005,recoil:.016,ammo:'556',noise:55,adsT:.32,move:.9,price:700000}),
  m27:  W_('M27 IAR','輕機槍','long','rifle',{auto:true,rpm:750,dmg:31,head:2.2,mag:30,reload:2.2,hip:.032,ads:.0026,recoil:.0135,range:170,ammo:'556',noise:52,adsT:.24,price:500000}),
  t75:  W_('T75','輕機槍','long','lmg',{auto:true,rpm:850,dmg:29,head:2.1,mag:100,reload:4.3,hip:.046,ads:.0052,recoil:.017,ammo:'556',noise:55,adsT:.32,move:.9,price:600000}),
  t74:  W_('T74','輕機槍','long','lmg',{auto:true,rpm:750,dmg:37,head:2.1,mag:100,reload:4.6,hip:.05,ads:.0055,recoil:.02,ammo:'762',noise:58,adsT:.34,move:.88,price:650000}),
  t112l:W_('T112 班用機槍','輕機槍','long','lmg',{auto:true,rpm:820,dmg:32,head:2.1,mag:100,reload:4,hip:.042,ads:.0045,recoil:.015,ammo:'556',noise:55,adsT:.3,move:.92,crate:2,price:900000}),
  mg34: W_('MG34','輕機槍','long','lmg',{auto:true,rpm:900,dmg:38,head:2.1,mag:75,reload:4.4,hip:.05,ads:.0055,recoil:.02,ammo:'762',noise:60,adsT:.34,move:.88,crate:3,price:1400000}),
  mg42: W_('MG42','輕機槍','long','lmg',{auto:true,rpm:1200,dmg:36,head:2.1,mag:75,reload:4.4,hip:.055,ads:.006,recoil:.021,ammo:'762',noise:62,adsT:.34,move:.88,crate:4,price:2400000}),
  // shotguns
  m870: W_('M870','霰彈槍','long','shotgun',{rpm:70,dmg:15,pel:9,head:1.6,mag:6,reload:2.6,hip:.075,ads:.05,recoil:.05,range:45,ammo:'12g',noise:45,adsT:.22,price:150000}),
  m500: W_('M500','霰彈槍','long','shotgun',{rpm:75,dmg:16,pel:8,head:1.6,mag:6,reload:2.6,hip:.072,ads:.048,recoil:.05,range:45,ammo:'12g',noise:45,adsT:.22,price:140000}),
  m1897:W_('M1897','霰彈槍','long','shotgun',{rpm:95,dmg:16,pel:7,head:1.6,mag:5,reload:2.8,hip:.07,ads:.05,recoil:.055,range:42,ammo:'12g',noise:46,adsT:.2,crate:1,price:300000}),
  aa12: W_('AA-12','霰彈槍','long','shotgun',{auto:true,rpm:300,dmg:12,pel:7,head:1.5,mag:20,reload:3.2,hip:.08,ads:.055,recoil:.03,range:38,ammo:'12g',noise:48,adsT:.24,crate:3,price:1600000}),
  m4s:  W_('M4 Super 90','霰彈槍','long','shotgun',{rpm:200,dmg:14,pel:8,head:1.6,mag:7,reload:2.8,hip:.07,ads:.048,recoil:.045,range:45,ammo:'12g',noise:46,adsT:.22,price:420000}),
};
const botGun=()=>pick(Object.keys(WEAPONS).filter(w=>WEAPONS[w].slot==='long'&&!WEAPONS[w].crate&&WEAPONS[w].model!=='sniper'));
const OLD_WID={m7:'m4a1',kv47:'ak47',v9:'mp5',k12:'m870',d14:'mk14',r90:'awm',l60:'m249',p9:'g19',d50:'m686'};
const CRATES=[
  {id:'c0',name:'一般槍械箱',rate:.2,price:120000,col:'#d8d0bf'},
  {id:'c1',name:'特別槍械箱',rate:.4,price:300000,col:'#8fd17a'},
  {id:'c2',name:'稀有槍械箱',rate:.6,price:700000,col:'#6db5ff'},
  {id:'c3',name:'史詩槍械箱',rate:.8,price:1600000,col:'#c08cff'},
  {id:'c4',name:'傳奇槍械箱',rate:.95,price:3500000,col:'#ffc94d'},
];
const SKIN_CRATES=[
  {id:'k0',name:'一般外觀箱',rate:.2,price:100000,col:'#d8d0bf'},
  {id:'k1',name:'特別外觀箱',rate:.4,price:250000,col:'#8fd17a'},
  {id:'k2',name:'稀有外觀箱',rate:.6,price:600000,col:'#6db5ff'},
  {id:'k3',name:'史詩外觀箱',rate:.8,price:1300000,col:'#c08cff'},
  {id:'k4',name:'傳奇外觀箱',rate:.95,price:2800000,col:'#ffc94d'},
];
const KNIFE={name:'戰術刀',dmg:55,back:3,range:2.2,rate:.55};
const ATT_SLOTS=['optic','side','stock','grip','mag','muzzle'];
const ATT_SLOT_NAME={optic:'倍鏡',side:'側鏡',stock:'槍托',grip:'握把',mag:'彈匣',muzzle:'槍口'};
const ATTS={
  rd:   {slot:'optic',name:'紅點瞄具',zoom:1.25,price:25000,desc:'開鏡更清楚'},
  holo: {slot:'optic',name:'全息瞄具',zoom:1.4,price:40000,desc:'較大視野的反射式瞄具'},
  x2:   {slot:'optic',name:'2 倍鏡',zoom:2,price:60000,desc:'中距離'},
  x4:   {slot:'optic',name:'4 倍鏡',zoom:4,scope:true,price:90000,desc:'中遠距離，全鏡視野'},
  x8:   {slot:'optic',name:'8 倍狙擊鏡',zoom:8,scope:true,price:150000,desc:'遠距離狙擊'},
  canted:{slot:'side',name:'45° 側置紅點',sideZoom:1.25,price:35000,desc:'搭配高倍鏡：開鏡時按 Alt 切換到側鏡打近距離'},
  stLight:{slot:'stock',name:'輕量槍托',adsT:-.06,move:.05,recoil:.08,price:30000,desc:'開鏡快、移動快，後座稍大'},
  stHeavy:{slot:'stock',name:'重型槍托',recoil:-.18,adsT:.05,price:45000,desc:'大幅降低後座，開鏡較慢'},
  stTac:{slot:'stock',name:'戰術槍托',recoil:-.1,spread:-.1,price:65000,desc:'均衡提升穩定'},
  gripV:{slot:'grip',name:'垂直握把',recoil:-.13,price:35000,desc:'降低垂直後座'},
  gripA:{slot:'grip',name:'斜角握把',adsT:-.05,recoil:-.05,price:35000,desc:'開鏡更快'},
  gripS:{slot:'grip',name:'穩定握把',spread:-.25,price:45000,desc:'腰射更準'},
  magExt:{slot:'mag',name:'擴容彈匣',magMul:1.5,reload:.3,price:50000,desc:'彈容 ×1.5，換彈稍慢'},
  magDrum:{slot:'mag',name:'彈鼓',magMul:2.2,reload:.8,adsT:.05,move:-.04,price:90000,desc:'彈容 ×2.2，笨重'},
  magFast:{slot:'mag',name:'快拔彈匣',reload:-.4,price:55000,desc:'換彈更快'},
  supp:{slot:'muzzle',name:'消音器',noise:-.65,dmg:-.05,price:70000,desc:'槍聲傳得很近，敵人難以察覺'},
  comp:{slot:'muzzle',name:'補償器',recoil:-.15,price:40000,desc:'降低後座'},
};
function attAllowed(wid,aid){const w=WEAPONS[wid],a=ATTS[aid];if(!w||!a)return false;
  if(w.slot==='pistol')return ['rd','holo','magExt','magFast','supp','comp'].includes(aid);
  if(a.slot==='side'&&w.model==='shotgun')return false;
  if(w.model==='shotgun'&&(aid==='x4'||aid==='x8'||aid==='magDrum'))return false;
  if(w.model==='lmg'&&a.slot==='mag')return aid==='magFast';
  return true}
function weaponStats(wid,build){
  const w=WEAPONS[wid];const s={dmg:w.dmg,rpm:w.rpm,mag:w.mag,reload:w.reload,hip:w.hip,ads:w.ads,recoil:w.recoil,adsT:w.adsT,zoom:w.baseZoom||1.15,scope:false,noise:w.noise,move:w.move||1,optic:null};
  for(const sl of ATT_SLOTS){const id=build&&build[sl];if(!id||!attAllowed(wid,id))continue;const a=ATTS[id];
    if(a.zoom){s.zoom=a.zoom;s.scope=!!a.scope;s.optic=id}if(a.sideZoom)s.side=a.sideZoom;
    if(a.recoil)s.recoil*=1+a.recoil;if(a.adsT)s.adsT=Math.max(.06,s.adsT+a.adsT);if(a.spread)s.hip*=1+a.spread;
    if(a.magMul)s.mag=Math.round(w.mag*a.magMul);if(a.reload)s.reload=Math.max(.6,s.reload+a.reload);
    if(a.noise)s.noise*=1+a.noise;if(a.dmg)s.dmg*=1+a.dmg;if(a.move)s.move+=a.move}
  return s}

const GEAR={
  helmet:{h0:{name:'無頭盔',tier:0,dur:0,price:0},h1:{name:'一級頭盔',tier:1,dur:20,price:10000},h2:{name:'二級戰術頭盔',tier:2,dur:60,price:30000},h3:{name:'三級防彈頭盔',tier:3,dur:100,price:50000},h4:{name:'四級重型頭盔',tier:4,dur:150,price:80000},h5:{name:'五級防爆頭盔',tier:5,dur:200,price:1500000},h6:{name:'六級指揮官頭盔',tier:6,dur:280,price:4800000}},
  armor:{a0:{name:'無護甲',tier:0,dur:0,price:0},a1:{name:'一級防彈衣',tier:1,dur:30,price:10000},a2:{name:'二級防彈背心',tier:2,dur:80,price:30000},a3:{name:'三級戰術護甲',tier:3,dur:120,price:60000},a4:{name:'四級重型護甲',tier:4,dur:180,price:100000},a5:{name:'五級全身甲',tier:5,dur:240,price:220000},a6:{name:'六級重裝甲',tier:6,dur:320,price:600000}},
  rig:{rig0:{name:'簡易胸掛',cap:3,grid:[3,1],price:0},rig1:{name:'輕型胸掛',cap:5,grid:[5,1],price:50000},rig2:{name:'戰術胸掛',cap:10,grid:[5,2],price:100000},rig3:{name:'突擊胸掛',cap:20,grid:[5,4],price:200000},rig4:{name:'重型胸掛',cap:30,grid:[6,5],price:400000},rig5:{name:'特戰胸掛',cap:50,grid:[10,5],price:800000}},
  bag:{bag0:{name:'無背包',cap:0,grid:[0,0],price:0},bag1:{name:'小型背包',cap:10,grid:[5,2],price:20000},bag2:{name:'中型背包',cap:20,grid:[5,4],price:40000},bag3:{name:'大型背包',cap:30,grid:[6,5],price:100000},bag4:{name:'登山背包',cap:40,grid:[8,5],price:250000},bag5:{name:'重型行軍包',cap:60,grid:[10,6],price:500000},bag6:{name:'特戰物資包',cap:100,grid:[10,10],price:1000000}},
  pouch:{pouch0:{name:'基本彈掛',mags:5,mul:.5,price:0},pouch1:{name:'輕型彈掛',mags:10,mul:1,price:100000},pouch2:{name:'戰術彈掛',mags:15,mul:1.5,price:150000},pouch3:{name:'突擊彈掛',mags:30,mul:3,price:300000},pouch4:{name:'重型彈掛',mags:50,mul:5,price:600000}},
  safe:{safe0:{name:'簡易保險盒',cap:1,grid:[1,1],price:0},safe1:{name:'基礎保險箱',cap:2,grid:[2,1],price:200000},safe2:{name:'進階保險箱',cap:4,grid:[2,2],price:400000},safe3:{name:'精英保險箱',cap:6,grid:[3,2],price:600000},safe4:{name:'頂級保險箱',cap:9,grid:[3,3],price:900000}},
};
const TIER_PROT=[0,.2,.3,.4,.5,.6,.68];
const RARITY=['#d8d0bf','#8fd17a','#6db5ff','#c08cff','#ffc94d','#ff5a48','#ff3d5a'];
// w,h = grid size; r = rarity (5+ = 大紅)
const I_=(name,v,w,h,r,o)=>Object.assign({name,v,w,h,s:w*h,r},o||{});
const ITEMS={
  // valuables
  tape:I_('電工膠帶',9000,1,1,0),phone:I_('舊型手機',18000,1,1,0),parts:I_('電子零件',26000,1,1,0),cig:I_('整條香菸',15000,2,1,0),
  battery:I_('軍用電池',48000,1,2,1),radio:I_('軍用電台',72000,2,2,1),whisky:I_('陳年威士忌',60000,1,2,1),
  usb:I_('加密隨身碟',95000,1,1,2),gpu:I_('顯示卡',140000,2,1,2),camera:I_('專業相機',125000,2,2,2),
  tablet:I_('戰術平板',168000,2,2,3),watch:I_('金色懷錶',220000,1,1,3),drone:I_('偵察無人機',280000,3,2,3),
  gold:I_('金條',340000,2,1,4),server:I_('伺服器主機板',450000,3,2,4),statue:I_('青銅雕像',520000,2,3,4),
  hdd:I_('機密硬碟',900000,1,1,5),reactor:I_('微型反應爐',1600000,2,2,5),
  core:I_('藍晶核心',2600000,1,1,6),
  gem:I_('深海藍鑽',8800000,1,1,6),qcpu:I_('量子運算單元',5200000,2,2,6),tank:I_('主戰坦克模型',3600000,3,2,6),
  ecmo:I_('體外循環機',4200000,3,3,6),radarc:I_('雷達核心',2900000,2,2,5),ctrl:I_('軍用無人機控制器',1900000,2,1,5),
  // consumables & tools
  med:I_('急救包',8000,1,1,0,{use:'med',heal:45,time:2.4}),
  surg:I_('手術包',35000,2,1,2,{use:'med',heal:100,time:4.5}),
  nade:I_('破片手榴彈',12000,1,1,0),
  repair:I_('護甲維修包',25000,1,2,1,{use:'repair',time:3}),
  flare:I_('信號彈',60000,1,1,3,{use:'flare'}),
  tmap:I_('藏寶圖',15000,1,1,2,{use:'tmap'}),
  keyR:I_('紅色鑰匙卡',250000,1,1,4,{key:'R'}),
  keyB:I_('藍色鑰匙卡',150000,1,1,3,{key:'B'}),
};
const VALUABLES=Object.keys(ITEMS).filter(k=>!ITEMS[k].use&&!ITEMS[k].key&&k!=='nade');

/* OPERATORS live in ops.js */

/* ================= maps meta ================= */
const MAPS={
  town:{name:'灰區鎮',half:165,desc:'街區、指揮所、銀行金庫、滑索與屋頂狙擊。',size:'10 × 10 km · 核心區 330 m'},
  harbor:{hidden:true,name:'鐵鏽港',half:190,desc:'貨櫃迷宮、吊臂電梯、貨輪甲板、伺服器機房。',size:'10 × 10 km · 核心區 380 m'},
  frost:{name:'寒脊研究站',half:175,desc:'雪林、岩脊、毒氣實驗室、地堡與探照燈。',size:'10 × 10 km · 核心區 350 m'},
  dam:{name:'斷河水壩',half:180,desc:'峽谷河道、三座大橋、水壩頂、發電廠與森林。',size:'10 × 10 km · 核心區 360 m'},
  valley:{name:'長風谷',half:185,desc:'海景飯店、莊園、墜機點黑匣子、雷達站、瀑布後軍火庫、定時發車的列車撤離。',size:'10 × 10 km · 核心區 370 m'},
  space:{name:'星港發射場',half:190,desc:'火箭發射台與斷橋、離心機室、中控密室、藍室與黑室；堅守電腦開大橋、拉雙閘從噴泉廣場撤離。',size:'10 × 10 km · 核心區 380 m'},
  prison:{name:'怒濤監獄',half:180,desc:'孤島監獄：中央放風場大金、醫務翼權限卡房、海溝水下 31 個容器（要閉氣）、解密綠色電腦才能拉閘。',size:'10 × 10 km · 核心區 360 m'},
  nuclear:{name:'餘燼核電廠',half:185,desc:'反應爐主控室、冷卻塔底隱藏箱、行政樓地下機房、卸料碼頭；輻射區持續扣血但物資更好。',size:'10 × 10 km · 核心區 370 m'},
  forest:{name:'叢林',half:175,desc:'濕熱雨林、伐木營地、獵人小屋、護林塔滑索、岩洞寶藏，常下雨起霧。',size:'10 × 10 km · 核心區 350 m'},
  desert:{name:'赤沙綠洲',half:185,desc:'綠洲、土磚村與市集、沙海神殿、輸油管線、殘骸車隊與峽谷。',size:'10 × 10 km · 核心區 370 m'},
  tower:{name:'台北101',half:160,desc:'信義區的地標大樓：購物中心、搭電梯上觀景台、兩條滑索、捷運站、高架快速道路。',size:'10 × 10 km · 核心區 320 m'},
  warehouse:{hidden:true,name:'沙暴倉庫',half:62,desc:'近距離巷戰：大倉庫、天橋、跳板。適合對決與團戰。',size:'10 × 10 km · 核心區 124 m'},
};
const MODES={
  extract:{name:'烽火撤離',tag:'搜刮 · 撤離',desc:'搜物資、打守軍，活著撤離才能帶走。裝備會遺失。',solo:true},
  conquest:{name:'全面戰場',tag:'據點 · 兵力',desc:'兩軍搶 5 個據點，扣光敵方兵力獲勝。',team:true,respawn:true},
  tdm:{name:'團隊死鬥',tag:'團隊 · 對戰',desc:'藍紅兩隊對打，先拿到 50 殺的隊伍獲勝。可以和朋友互打。',team:true,respawn:true,pvp:true},
  relic:{name:'奪取聖物',tag:'團隊 · 搶奪',desc:'搶中央的聖物帶回自家基地，先得 5 分獲勝。',team:true,respawn:true,pvp:true},
  zombie:{name:'殭屍圍城',tag:'特殊 · 合作',desc:'守住據點撐過 10 波屍潮。手槍爆頭傷害 ×3，子彈無限。',special:true,pistolFriendly:true},
  oitc:{name:'一發入魂',tag:'特殊 · 手槍',desc:'所有人只有一顆子彈，一發必死。擊殺補一發，先 15 殺獲勝。',special:true,ffa:true,respawn:true,pistolFriendly:true},
  gungame:{name:'槍王之王',tag:'特殊 · 個人',desc:'每殺一人換下一把槍，最後用刀擊殺就贏。被刀殺會降級。',special:true,ffa:true,respawn:true},
  duel:{name:'西部對決',tag:'特殊 · 手槍',desc:'手槍一對一回合制，倒數後拔槍，先贏 5 回合。',special:true,pistolFriendly:true},
};
const MUTATORS={lowgrav:'低重力',bighead:'巨頭',headonly:'只限爆頭',infammo:'無限彈藥',pistolonly:'只用手槍',hardcore:'一擊必殺'};
const GUNGAME=['m249','ak47','m4a1','p90','m870','svd','awm','m686','g19','knife'];
const BOT_NAMES=['獵鷹','灰狼','夜梟','鐵砧','山貓','禿鷲','黑蛇','雷鳥','野狗','銀狐','赤蠍','冰熊','鬣狗','青隼','石虎','獨角','孤鷹','蒼狼','暗鴉','火蟻'];
const botName=id=>BOT_NAMES[id%BOT_NAMES.length]+(10+(id*7)%90);
const DEFAULT_PRESETS=[{name:'A 突擊',p1:'m4a1',p2:null,pistol:'g19'},{name:'B 狙擊',p1:'awm',p2:'mp5',pistol:'g19'},{name:'C 近戰',p1:'m870',p2:null,pistol:'m686'}];
const DIFFS={easy:{name:'普通',acc:.55,dmg:.6,react:.35,squad:1.6,heavy:.08,tier:1,loot:1},normal:{name:'機密',acc:.85,dmg:.9,react:0,squad:1,heavy:.15,tier:2,loot:1.15},hard:{name:'絕密',acc:1.05,dmg:1.15,react:-.12,squad:.8,heavy:.25,tier:3,loot:1.35},hell:{name:'地獄',acc:1.3,dmg:1.45,react:-.22,squad:.6,heavy:.35,tier:4,loot:1.6}};

/* ================= profile (stash / money) ================= */
const PF_KEY='gz2Profile';
function defaultProfile(){return{
  v:2,money:1000000,lootK:1,
  weapons:{m4a1:1,mp5:1},
  atts:{rd:1},
  gear:{h1:2,a1:2,a2:1,rig1:1,bag1:2,rig0:1,pouch1:1},
  stash:{med:5,repair:1},
  ammo:{'556':400,'9mm':400,'762':60,'12g':24,'338':10,'57':0,'357':0,'50bmg':0},
  builds:{m4a1:{optic:'rd'}},
  safe:'safe0',
  loadout:{p1:'m4a1',p2:null,pistol:'g19',helmet:'h1',armor:'a1',rig:'rig1',bag:'bag1',pouch:'pouch1',meds:3},
  operator:'ironclaw',skin:{},ownSkins:{},
  nick:'',
  settings:{sens:1.2,adsSens:1,vol:.75,fov:78,quality:'auto',adsMode:'toggle',hitSnd:true,killVoice:true,fps:false,killcam:true,tod:'day',diff:'normal',count:'mid',time:'20',map:'town',mode:'extract',mut:[],ff:false,pickup:true,pub:true},
  presets:JSON.parse(JSON.stringify(DEFAULT_PRESETS)),preset:0,
  stats:{raids:0,extracts:0,kills:0,best:0},
}}
function migratePF(s){if(!s)return null;if(s.v===2)return s;if(s.v!==1)return null;const W=id=>OLD_WID[id]||id;
  const mapObj=o=>{const r={};for(const k in o||{})r[W(k)]=(r[W(k)]||0)+o[k];return r};
  s.weapons=mapObj(s.weapons);const b={};for(const k in s.builds||{})b[W(k)]=s.builds[k];s.builds=b;
  if(s.loadout){for(const k of ['p1','p2','pistol'])if(s.loadout[k])s.loadout[k]=W(s.loadout[k]);delete s.loadout.nades}
  for(const pr of s.presets||[])for(const k of ['p1','p2','pistol'])if(pr[k])pr[k]=W(pr[k]);
  s.money=Math.round((s.money||0)*10);if(s.gear&&s.gear.rig1){s.gear.rig2=(s.gear.rig2||0)+s.gear.rig1;delete s.gear.rig1;if(s.loadout&&s.loadout.rig==='rig1')s.loadout.rig='rig2'}
  if(s.stash&&s.stash.nade){s.money+=s.stash.nade*12000;delete s.stash.nade}
  s.v=2;s.lootK=1;return s}
let PF=defaultProfile();
try{const s=migratePF(JSON.parse(localStorage.getItem(PF_KEY)||'null'));if(s)PF=Object.assign(defaultProfile(),s,{settings:Object.assign(defaultProfile().settings,s.settings||{}),loadout:Object.assign(defaultProfile().loadout,s.loadout||{}),ammo:Object.assign(defaultProfile().ammo,s.ammo||{})})}catch(e){}
for(const k of ['p1','p2','pistol'])if(PF.loadout[k]&&!WEAPONS[PF.loadout[k]])PF.loadout[k]=k==='pistol'?'g19':null;for(const pr of PF.presets)for(const k of ['p1','p2','pistol'])if(pr[k]&&!WEAPONS[pr[k]])pr[k]=k==='pistol'?'g19':null;
for(const k of Object.keys(PF.weapons))if(!WEAPONS[k])delete PF.weapons[k];if(!GEAR.safe[PF.safe])PF.safe='safe0';
if(typeof OPERATORS!=='undefined'&&!OPERATORS[PF.operator])PF.operator='ironclaw';PF.skin=PF.skin||{};PF.ownSkins=PF.ownSkins||{};if(!PF.p3){PF.p3=1;PF.settings.time='inf';PF.settings.tod='cycle'}
function savePF(){try{localStorage.setItem(PF_KEY,JSON.stringify(PF))}catch(e){}}
const fmt=v=>'$'+Math.round(v).toLocaleString();
function gearDef(kind,id){return GEAR[kind][id]}
function ownCount(cat,id){return (PF[cat]&&PF[cat][id])||0}
function addOwn(cat,id,n=1){PF[cat][id]=(PF[cat][id]||0)+n;if(PF[cat][id]<=0)delete PF[cat][id]}
