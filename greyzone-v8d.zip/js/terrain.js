'use strict';
/* ================= terrain：起伏地形高度場 =================
   - 每張地圖依 TERR_AMP 產生丘陵（值雜訊 fbm），建築、道路、水域、撤離點等周圍自動整平，
     所以原本放在 y=0 的建築不用改。
   - 樹木不會整平地形，而是被「抬」到地面高度。
   - 地圖生成後才放的方塊（旗桿、床、砲塔、空投箱…）若底部在 y=0 而該處有坡，會局部整平並重建地形網格。
   - groundAt / isFree / rayWorld / 粒子 / 投擲物 / 導航 都會讀 terrH()。 */
const TERR_AMP={town:6,harbor:5,frost:15,dam:12,valley:17,space:6,prison:6,nuclear:8,forest:13,desert:11,tower:5,warehouse:0};
let TR=null;// {res,n,o,h,max,built,mesh}

function _thash(a,b,s){let t=(Math.imul(a,374761393)+Math.imul(b,668265263)+Math.imul(s,1442695041))|0;t=Math.imul(t^(t>>>13),1274126177);return((t^(t>>>16))>>>0)/4294967295}
function vnoise(x,z,s){const xi=Math.floor(x),zi=Math.floor(z),xf=x-xi,zf=z-zi;const u=xf*xf*(3-2*xf),v=zf*zf*(3-2*zf);
  const a=_thash(xi,zi,s),b=_thash(xi+1,zi,s),c=_thash(xi,zi+1,s),d=_thash(xi+1,zi+1,s);return a+(b-a)*u+(c-a)*v+(a-b-c+d)*u*v}
function fbm(x,z,s,oct=4){let a=0,f=1,w=.5,t=0;for(let i=0;i<oct;i++){a+=vnoise(x*f,z*f,s+i*17)*w;t+=w;w*=.5;f*=2.03}return a/t}
const sstep=(a,b,x)=>{const t=clamp((x-a)/(b-a),0,1);return t*t*(3-2*t)};

// 地形高度（雙線性內插）；沒有地形時回傳 0
function terrH(x,z){if(!TR)return FAR?farH(x,z):0;const n=TR.n;let fx=(x-TR.o)/TR.res,fz=(z-TR.o)/TR.res;if(FAR&&(fx<0||fz<0||fx>n-1||fz>n-1))return farH(x,z);fx=clamp(fx,0,n-1.001);fz=clamp(fz,0,n-1.001);
  const ix=fx|0,iz=fz|0,u=fx-ix,v=fz-iz,H=TR.h,i=iz*n+ix;return H[i]*(1-u)*(1-v)+H[i+1]*u*(1-v)+H[i+n]*(1-u)*v+H[i+n+1]*u*v}
function terrNormal(x,z,out){const e=1;out.x=terrH(x-e,z)-terrH(x+e,z);out.z=terrH(x,z-e)-terrH(x,z+e);out.y=2*e;const L=Math.hypot(out.x,out.y,out.z);out.x/=L;out.y/=L;out.z/=L;return out}

// 射線打地形：回傳距離 t，沒打到回傳 -1
function terrRay(ox,oy,oz,dx,dy,dz,maxT){
  if(!TR&&!FAR){if(dy<-1e-6){const t=-oy/dy;return t>0&&t<maxT?t:-1}return -1}
  const TMX=TR?TR.max:FAR.max;if(oy>TMX+.5&&dy>=0)return -1;
  let t=0,gap=oy-terrH(ox,oz);if(gap<-.05)return -1;// 起點已在地下（例如水底），不擋
  while(t<maxT){const pt=t;t=Math.min(maxT,t+Math.max(.45,gap*.6));const y=oy+dy*t;gap=y-terrH(ox+dx*t,oz+dz*t);
    if(gap<=0){let a=pt,b=t;for(let k=0;k<7;k++){const m=(a+b)/2;if(oy+dy*m-terrH(ox+dx*m,oz+dz*m)>0)a=m;else b=m}return b}
    if(y>TMX+.5&&dy>=0)return -1}
  return -1}

/* 生成高度場：在 decoEnd / buildTrees 之前呼叫（需要讀 DECO 頂點當成「有東西」的區域） */
function terrBuild(){TR=null;const amp=TERR_AMP[W.id];if(!amp)return;const h=W.half,E=h+130,res=2.5,n=Math.ceil(E*2/res)+1,o=-E;
  const occ=new Uint8Array(n*n);const ci=v=>Math.round((v-o)/res);
  const rect=(x0,z0,x1,z1)=>{if(x1<o||z1<o||x0>-o||z0>-o)return;const a=clamp(Math.floor((x0-o)/res),0,n-1),b=clamp(Math.ceil((x1-o)/res),0,n-1),c=clamp(Math.floor((z0-o)/res),0,n-1),d=clamp(Math.ceil((z1-o)/res),0,n-1);for(let z=c;z<=d;z++)for(let x=a;x<=b;x++)occ[z*n+x]=1};
  const circ=(x,z,r)=>rect(x-r*.7,z-r*.7,x+r*.7,z+r*.7);
  // 1) 所有方塊（樹木除外）
  for(const b of W.boxes){if(b.tree)continue;rect(b.minX,b.minZ,b.maxX,b.maxZ)}
  // 2) 合併的裝飾幾何（圍籬、棕櫚、殘骸…）
  for(const B of [DECO,DECOM]){if(!B)continue;const p=B.p;for(let i=0;i<p.length;i+=3){const x=ci(p[i]),z=ci(p[i+2]);if(x>=0&&z>=0&&x<n&&z<n)occ[z*n+x]=1}}
  // 3) 動態物件、道路、水域、地標、撤離點、跳板、毒氣區、出生點
  for(const m of W.dynObjs||[])if(m.position)circ(m.position.x,m.position.z,3);
  for(const r of W.roadRects||[])rect(...r);for(const r of W.flatRects||[])rect(...r);
  for(const w of W.water||[])rect(w.minX-4,w.minZ-4,w.maxX+4,w.maxZ+4);
  for(const l of W.landmarks||[])circ(l.x,l.z,l.r*.55);
  for(const e of W.extracts||[])circ(e.pos.x,e.pos.z,9);
  for(const p of W.pads||[])circ(p.x,p.z,3);for(const g of W.gas||[])circ(g.x,g.z,g.r);
  for(const s of W.spawnsP||[])circ(s.x,s.z,7);
  // 4) 距離轉換（chamfer）：離「有東西」越遠，地形越高
  const D=new Float32Array(n*n);for(let i=0;i<n*n;i++)D[i]=occ[i]?0:1e9;const r2=res*1.4142;
  for(let z=0;z<n;z++)for(let x=0;x<n;x++){const i=z*n+x;let d=D[i];if(x>0)d=Math.min(d,D[i-1]+res);if(z>0){d=Math.min(d,D[i-n]+res);if(x>0)d=Math.min(d,D[i-n-1]+r2);if(x<n-1)d=Math.min(d,D[i-n+1]+r2)}D[i]=d}
  for(let z=n-1;z>=0;z--)for(let x=n-1;x>=0;x--){const i=z*n+x;let d=D[i];if(x<n-1)d=Math.min(d,D[i+1]+res);if(z<n-1){d=Math.min(d,D[i+n]+res);if(x<n-1)d=Math.min(d,D[i+n+1]+r2);if(x>0)d=Math.min(d,D[i+n-1]+r2)}D[i]=d}
  // 5) 高度：大丘陵 + 小起伏；沙漠用脊狀沙丘
  const s=(W.seed||1)%100000,Hh=new Float32Array(n*n);let mx=0;const dune=W.id==='desert';
  for(let z=0;z<n;z++)for(let x=0;x<n;x++){const wx=o+x*res,wz=o+z*res,i=z*n+x;
    const big=fbm(wx/95,wz/95,s),small=fbm(wx/32,wz/32,s+51,3);
    let raw=dune?(1-Math.abs(fbm(wx/70,wz/45,s)*2-1))**2.2*.9+small*.25:sstep(.3,.72,big)*.85+small*.35;
    let f=sstep(3,15,D[i]);const out=Math.max(Math.abs(wx),Math.abs(wz))-h;if(out>0&&!FAR){f=Math.max(f,sstep(0,45,out));raw+=out*.012}
    let v=raw*amp*f;if(out>0&&FAR)v=lerp(v,farH(wx,wz),sstep(10,120,out));Hh[i]=v;if(v>mx)mx=v}
  if(FAR)mx=Math.max(mx,FAR.max);TR={res,n,o,h:Hh,max:mx,amp,built:false,mesh:null,D};
  liftTrees();TR.built=true}

// 樹木抬到地面
function liftTrees(){for(const t of W.treeList||[]){const b=t[3];const y=Math.max(0,terrH(t[0],t[1])-.25);const dy=y-(t[4]||0);t[4]=y;if(b){b.minY+=dy;b.maxY+=dy}}}

// 生成後才加的方塊：底部在 y=0 但地面有坡 → 局部整平
function terrFlatten(b){if(!TR||!TR.built||b.tree||!b.solid||Math.abs(b.minY)>.01)return;const cx=(b.minX+b.maxX)/2,cz=(b.minZ+b.maxZ)/2;
  if(Math.max(terrH(cx,cz),terrH(b.minX,b.minZ),terrH(b.maxX,b.maxZ),terrH(b.minX,b.maxZ),terrH(b.maxX,b.minZ))<.05)return;
  const R=26,n=TR.n,res=TR.res,o=TR.o;const x0=clamp(Math.floor((b.minX-R-o)/res),0,n-1),x1=clamp(Math.ceil((b.maxX+R-o)/res),0,n-1),z0=clamp(Math.floor((b.minZ-R-o)/res),0,n-1),z1=clamp(Math.ceil((b.maxZ+R-o)/res),0,n-1);
  for(let z=z0;z<=z1;z++)for(let x=x0;x<=x1;x++){const wx=o+x*res,wz=o+z*res;const dx=Math.max(b.minX-wx,0,wx-b.maxX),dz=Math.max(b.minZ-wz,0,wz-b.maxZ);TR.h[z*n+x]*=sstep(3,R,Math.hypot(dx,dz))}
  if(!TR.pend){TR.pend=true;setTimeout(terrRefresh,0)}}
function terrRefresh(){if(!TR)return;TR.pend=false;if(TR.mesh)terrFill(TR.mesh.geometry);liftTrees();if(W.treeMeshes){for(const m of W.treeMeshes){scene.remove(m);m.geometry.dispose();const i=W.meshes.indexOf(m);if(i>=0)W.meshes.splice(i,1)}buildTrees()}if(typeof buildMinimapBase==='function'&&mapBase)buildMinimapBase()}

/* 地形網格：取代原本的平面地板。水域底下的頂點壓到河床，坡越陡顏色越像岩石。 */
function terrFill(g){const n=TR.n,o=TR.o,res=TR.res,pos=g.attributes.position.array,col=g.attributes.color.array;const base=new T.Color(THEME.ground||'#6a6a5a'),rock=new T.Color(THEME.mtn||0x6a6a60);const rr=[rock.r/Math.max(.05,base.r),rock.g/Math.max(.05,base.g),rock.b/Math.max(.05,base.b)].map(v=>clamp(v,.55,1.5));
  for(let z=0;z<n;z++)for(let x=0;x<n;x++){const i=z*n+x,wx=o+x*res,wz=o+z*res;const w=waterAt(wx,wz);pos[i*3+1]=w?w.bed:TR.h[i]}
  g.attributes.position.needsUpdate=true;g.computeVertexNormals();const nr=g.attributes.normal.array;
  for(let i=0;i<n*n;i++){const sl=1-nr[i*3+1];const k=clamp(sl*3.2,0,.75);const lit=(1+clamp(TR.h[i]/(TR.amp*1.5),0,1)*.12)*(1-k*.18);for(let c=0;c<3;c++)col[i*3+c]=(1+(rr[c]-1)*k)*lit}
  g.attributes.color.needsUpdate=true;g.computeBoundingSphere()}
function terrMesh(){const n=TR.n,o=TR.o,res=TR.res,E=-o;const P=new Float32Array(n*n*3),C=new Float32Array(n*n*3),U=new Float32Array(n*n*2);
  for(let z=0;z<n;z++)for(let x=0;x<n;x++){const i=z*n+x;P[i*3]=o+x*res;P[i*3+2]=o+z*res;U[i*2]=(x*res)/(2*E);U[i*2+1]=1-(z*res)/(2*E)}
  const I=new Uint32Array((n-1)*(n-1)*6);let k=0;for(let z=0;z<n-1;z++)for(let x=0;x<n-1;x++){const a=z*n+x,b=a+1,c=a+n,d=c+1;I[k++]=a;I[k++]=c;I[k++]=b;I[k++]=b;I[k++]=c;I[k++]=d}
  const g=new T.BufferGeometry();g.setAttribute('position',new T.BufferAttribute(P,3));g.setAttribute('color',new T.BufferAttribute(C,3));g.setAttribute('uv',new T.BufferAttribute(U,2));g.setIndex(new T.BufferAttribute(I,1));terrFill(g);
  const mat=MAT.ground.clone();mat.vertexColors=true;mat.color=new T.Color(0xffffff);const m=new T.Mesh(g,mat);m.receiveShadow=true;scene.add(m);W.meshes.push(m);TR.mesh=m;return m}
