'use strict';
/* ================= 隨身電腦 · 駭入（K 鍵 / 手機「電腦」鈕） =================
   - 每張地圖有 4–6 個「訊號中繼站」（綠色天線，地圖上標 H）。站在中繼站 8 m 內打開隨身電腦，
     就能選擇 400 m 內的敵人（AI 或玩家）駭入他的電腦。
   - 駭入要 4 秒，期間要留在中繼站範圍內；離開或按 K 會中斷。冷卻 45 秒。
   - 被駭入的人 20 秒內：位置暴露給對方全隊（同追蹤晶片）、移動速度 -35%、畫面雜訊與視野變暗、小地圖失效。
     被駭的玩家也可以按 H 用醫療包「重開機」提早解除（跟拆晶片一樣）。 */
const HACK_RANGE=8,HACK_TIME=4,HACK_DUR=20,HACK_CD=45,HACK_REACH=400;
function setupHackSpots(){W.hackSpots=[];const L=(W.landmarks||[]).filter(l=>l.name!=='車庫'&&l.name!=='坦克'&&l.name!=='直升機'&&l.name!=='戰鬥機');
  const pts=[];const R=mulberry((W.seed||1)+521);const cand=L.slice().sort(()=>R()-.5);
  for(const l of cand){if(pts.length>=6)break;if(pts.some(p=>Math.hypot(p.x-l.x,p.z-l.z)<70))continue;let p=null;for(let i=0;i<20&&!p;i++){const a=R()*TAU,d=4+R()*Math.max(4,l.r*.5);const x=l.x+Math.cos(a)*d,z=l.z+Math.sin(a)*d;if(isFree(x,z,1.2))p={x,z}}if(p)pts.push(p)}
  for(const p of pts){const y=terrH(p.x,p.z);const g=new T.Group();g.position.set(p.x,y,p.z);
    const mt=new T.MeshStandardMaterial({color:0x3a4038,metalness:.5,roughness:.6});const base=new T.Mesh(new T.BoxGeometry(.9,1,.6),mt);base.position.y=.5;g.add(base);
    const pole=new T.Mesh(new T.CylinderGeometry(.05,.07,3.2,6),mt);pole.position.y=2.6;g.add(pole);
    const dish=new T.Mesh(new T.ConeGeometry(.45,.3,10,1,true),new T.MeshStandardMaterial({color:0xd8d8d0,side:T.DoubleSide}));dish.position.set(.25,3.4,0);dish.rotation.z=-1.2;g.add(dish);
    const led=new T.Mesh(new T.SphereGeometry(.09,8,6),new T.MeshBasicMaterial({color:0x40ff80}));led.position.set(0,4.25,0);g.add(led);
    const scr=new T.Mesh(new T.PlaneGeometry(.6,.35),new T.MeshBasicMaterial({color:0x2aff7a}));scr.position.set(0,.72,.31);g.add(scr);
    addObj(g);W.hackSpots.push({x:p.x,z:p.z,y,g,led})}}
function nearHackSpot(){if(!W.hackSpots)return null;let best=null,bd=1e9;for(const s of W.hackSpots){const d=Math.hypot(s.x-P.pos.x,s.z-P.pos.z);if(d<bd){bd=d;best=s}}return best?{s:best,d:bd}:null}
function hackTargets(){const out=[];
  for(const b of bots){if(b.dead||!hostile(P.team,b.team)||b.kind==='zombie'||b.kind==='civ'||b.static)continue;const d=b.pos.distanceTo(P.pos);if(d<=HACK_REACH)out.push({b,d,name:(b.rival?'敵對小隊':b.kind==='boss'?'頭目':b.kind==='heavy'?'重裝守軍':b.kind==='sniper'?'狙擊手':'守軍')+' #'+b.id})}
  for(const k in netPuppets){const q=netPuppets[k];if(!q.alive||!hostile(P.team,q.team))continue;const d=q.pos.distanceTo(P.pos);if(d<=HACK_REACH)out.push({p:q,d,name:'玩家 '+(q.nick||k)})}
  return out.sort((a,b)=>a.d-b.d).slice(0,8)}
function toggleLaptop(force){if(!M.running||!P||!P.alive)return;const el=$('laptop');const open=force!==undefined?force:el.hidden;if(open===!el.hidden)return;el.hidden=!open;UI.laptopOpen=open;
  if(open){unlockPointer();renderLaptop()}else{if(P.hack&&P.hack.t<HACK_TIME){P.hack=null;note('駭入已中斷')}lockPointer()}}
function renderLaptop(){const box=$('lapBody');if(!box)return;const ns=nearHackSpot();const cd=P.hackCd>0?Math.ceil(P.hackCd):0;let h='';
  if(!ns){h='<p class="hint">這張地圖沒有訊號中繼站。</p>'}
  else if(ns.d>HACK_RANGE){h=`<p class="hint">要站在<b style="color:#40ff80">訊號中繼站</b>（綠色天線，地圖上的 H）8 m 內才能駭入。<br>最近的中繼站：${Math.round(ns.d)} m（方位 ${dirLabel(ns.s.x,ns.s.z)}）</p>`}
  else if(P.hack){const k=P.hack.t/HACK_TIME;h=`<p>駭入中：<b>${esc(P.hack.name)}</b></p><div class="lapBar"><i style="width:${Math.round(k*100)}%"></i></div><p class="hint">留在中繼站範圍內，${Math.max(0,HACK_TIME-P.hack.t).toFixed(1)} 秒後完成。</p>`}
  else if(cd){h=`<p class="hint">系統冷卻中，${cd} 秒後可以再次駭入。</p>`}
  else{const L=hackTargets();h=L.length?'<p class="hint">選一個目標駭入（400 m 內）：</p>'+L.map((t,i)=>`<button type="button" class="lapT" data-i="${i}"><span>${esc(t.name)}</span><small>${Math.round(t.d)} m · ${dirLabel(t.b?t.b.pos.x:t.p.pos.x,t.b?t.b.pos.z:t.p.pos.z)}</small></button>`).join(''):'<p class="hint">400 m 內沒有可以駭入的敵人。</p>';box._targets=L}
  box.innerHTML=h}
function dirLabel(x,z){const a=(Math.atan2(x-P.pos.x,-(z-P.pos.z))*180/Math.PI+360)%360;return['北','東北','東','東南','南','西南','西','西北'][Math.round(a/45)%8]}
$('lapBody').addEventListener('click',e=>{const b=e.target.closest('.lapT');if(!b)return;const t=($('lapBody')._targets||[])[+b.dataset.i];if(!t)return;P.hack={t:0,tgt:t,name:t.name};blip(1200,.05,'square',.04);renderLaptop()});
$('lapClose').onclick=()=>toggleLaptop(false);
function updateHack(dt){if(!P)return;if(P.hackCd>0)P.hackCd-=dt;
  if(W.hackSpots&&M.frame%20===0)for(const s of W.hackSpots)s.led.visible=!s.led.visible;
  if(P.hackT>0){P.hackT-=dt;const fx=$('hackFx');if(fx.hidden)fx.hidden=false;if(P.hackT<=0||!P.alive){P.hackT=0;fx.hidden=true;$('mini').style.visibility=''}else if(M.frame%6===0){fx.style.backgroundPosition=`${Math.random()*200}px ${Math.random()*200}px`;$('mini').style.visibility=Math.random()<.7?'hidden':''}}
  if(!P.hack){if(UI.laptopOpen&&M.frame%15===0)renderLaptop();return}
  const ns=nearHackSpot();if(!ns||ns.d>HACK_RANGE||!P.alive||P.downed){P.hack=null;note('離開中繼站範圍，駭入中斷');if(UI.laptopOpen)renderLaptop();return}
  const t=P.hack.tgt;if((t.b&&t.b.dead)||(t.p&&!t.p.alive)){P.hack=null;note('目標已失去連線');return}
  P.hack.t+=dt;if(UI.laptopOpen&&M.frame%5===0)renderLaptop();
  if(P.hack.t>=HACK_TIME){const e={chip:HACK_DUR,slow:[HACK_DUR,.65],blur:4,mark:HACK_DUR,hack:HACK_DUR,how:'電腦駭入'};
    skHit(t.b?{b:t.b,pos:t.b.pos}:{p:t.p,pos:t.p.pos},e,P.pos);if(t.b){t.b.hackT=HACK_DUR;t.b.seeT=0}
    banner('駭入成功',`${P.hack.name} 的位置暴露 ${HACK_DUR} 秒，行動變慢、視野受損`,2.2);blip(600,.1,'square',.05);blip(900,.1,'square',.05,0,.1);blip(1300,.15,'square',.05,0,.2);
    M.stats.hacks=(M.stats.hacks||0)+1;P.hack=null;P.hackCd=HACK_CD;if(UI.laptopOpen)renderLaptop()}}
// 被駭（effToMe 呼叫）
function onHacked(e){const first=!(P.hackT>0);P.hackT=Math.max(P.hackT||0,e.hack);if(first){banner('你的電腦被駭入了','位置暴露、移動變慢、畫面受干擾 '+e.hack+' 秒 · 按 H 用醫療包重開機',2.6);blip(300,.15,'sawtooth',.05);blip(220,.2,'sawtooth',.05,0,.15)}}
