'use strict';
/* ================= in-raid UI ================= */
const UI={invOpen:false,mapOpen:false,respawnOpen:false};
let bannerT=0,noteT=0,hitT=0,hitKind='',heartT=0;
function banner(t,sub='',d=2.4){$('banner').innerHTML='';const s=document.createElement('span');s.textContent=t;$('banner').appendChild(s);if(sub){const sm=document.createElement('small');sm.textContent=sub;$('banner').appendChild(sm)}$('banner').style.opacity=1;bannerT=d}
function note(t){$('note').textContent=t;$('note').style.opacity=1;noteT=2.5}
function feedMsg(html){const d=document.createElement('div');d.innerHTML=html;const f=$('feed');f.prepend(d);while(f.children.length>5)f.lastChild.remove();setTimeout(()=>d.remove(),4500)}
function lootToast(lines){const box=$('loot');for(const [t,c,v] of lines){const d=document.createElement('div');const b=document.createElement('b');b.style.color=c;b.textContent=t;d.appendChild(b);if(v){const s=document.createElement('span');s.textContent=v;d.appendChild(s)}box.appendChild(d);setTimeout(()=>d.remove(),3800)}while(box.children.length>9)box.firstChild.remove()}
function hitmark(kind){hitT=kind==='kill'?.45:.18;hitKind=kind;if(!PF.settings.hitSnd)return;if(kind==='head'){blip(1900,.05,'triangle',.06);blip(2600,.05,'triangle',.04,0,.03)}else if(kind==='kill'){blip(1200,.07,'square',.05);blip(1700,.09,'square',.045,0,.06)}else blip(1500,.03,'triangle',.04)}
const dirs=[];function dmgDir(src){const el=document.createElement('div');el.className='arc';$('dirs').appendChild(el);dirs.push({el,x:src.x,z:src.z,t:1.3});if(dirs.length>6){const o=dirs.shift();o.el.remove()}}
const heading=()=>{let h=(-P.yaw*180/Math.PI)%360;return h<0?h+360:h};
function bearingTo(x,z){let b=Math.atan2(x-P.pos.x,-(z-P.pos.z))*180/Math.PI;return b<0?b+360:b}

UI.enterGame=()=>{$('hub').hidden=true;$('result').hidden=true;$('pause').hidden=true;$('respawn').hidden=true;$('inv').hidden=true;$('bigmap').hidden=true;UI.invOpen=UI.mapOpen=UI.respawnOpen=false;
  $('hud').hidden=false;$('touch').hidden=!isTouch;$('cqBar').hidden=M.mode==='extract';
  const lbl={conquest:['我方分數','敵方分數'],tdm:['我方擊殺','敵方擊殺'],relic:['我方得分','敵方得分'],duel:['你','對手'],zombie:['剩餘喪屍','下一波'],oitc:['你的擊殺','最高'],gungame:['你的擊殺','最高']}[M.mode]||M.hudLbl||['',''];$('tk1').title=lbl[0];$('tk2').title=lbl[1];$('cqL1').textContent=lbl[0];$('cqL2').textContent=lbl[1];$('timerLbl').textContent=M.mode==='extract'?'撤離倒數':M.mode==='zombie'?'波數':M.mode==='duel'?'回合':'剩餘時間';$('carryLbl').textContent=M.mode==='extract'?'攜帶價值':'分數';
  $('feed').innerHTML='';$('loot').innerHTML='';dirs.forEach(d=>d.el.remove());dirs.length=0;
  buildSlotButtons();buildSkillTiles();$('flagChips').innerHTML=W.flags.map((f,i)=>`<span class="flag" id="fc${i}">${f.label}</span>`).join('');
  for(const k in UI._c)delete UI._c[k];document.body.classList.add('ingame');$('chat').hidden=!M.net;$('chatLines').innerHTML='';$('clickPlay').hidden=true;$('countdown').hidden=true;
  $('tInv').textContent=M.mode==='extract'?'背包':'計分';if(isTouch)try{document.documentElement.requestFullscreen&&!document.fullscreenElement&&document.documentElement.requestFullscreen().then(()=>{try{screen.orientation.lock('landscape').catch(()=>{})}catch(e){}}).catch(()=>{})}catch(e){}}
UI.leaveGame=()=>{document.body.classList.remove('ingame');$('clickPlay').hidden=true;$('score').hidden=true;UI.killcamOn=false;$('killcam').hidden=true;$('countdown').hidden=true;$('hud').hidden=true;$('touch').hidden=true;$('inv').hidden=true;$('bigmap').hidden=true;$('respawn').hidden=true;$('pause').hidden=true;$('vig').style.opacity=0;UI.invOpen=UI.mapOpen=UI.respawnOpen=false}
UI.toHub=()=>{$('result').hidden=true;$('hub').hidden=false;Hub.render()}
UI.scope=b=>{const h=$('scope');if(h.hidden===!b)return;h.hidden=!b};
UI.prompt=(label,prog,tap,t)=>{if(isTouch){const b=$('tUse');b.hidden=!label;if(label){const txt=(prog>0?Math.round(prog*100)+'% · ':'')+label;if(b.textContent!==txt)b.textContent=txt}return}
  const el=$('prompt');el.hidden=!label;if(label){const h=`<kbd>F</kbd>${tap?'按':'按住'} ${label}`;if(el._h!==h){$('promptTxt').innerHTML=h;el._h=h}$('promptBar').style.width=(prog*100)+'%';$('promptBar').parentElement.hidden=tap}};
UI.exfil=(text,prog,ok)=>{const el=$('exfil');el.hidden=!text;if(!text)return;$('exfilTxt').textContent=text;$('exfilTxt').style.color=ok?'var(--exfil)':'var(--amber)';$('exfilBar').style.width=(prog*100)+'%'};
UI.openPause=()=>{$('pause').hidden=false;$('pauseHint').textContent=M.net?'連線中無法暫停，戰鬥仍在進行。':'按「繼續作戰」回到戰場。'};
UI.closePause=()=>{$('pause').hidden=true};
$('resumeBtn').onclick=()=>{initAudio();resumeGame();lockPointer()};
$('abandonBtn').onclick=()=>{$('pause').hidden=true;M.paused=false;if(M.mode==='conquest'){M.ending=true;stopMatch();if(M.net&&M.isHost)netEndForAll();UI.toHub()}else{if(M.net&&M.isHost&&Object.keys(netPuppets).length)netEndForAll();endRaid('abandon');if(M.running){stopMatch();UI.toHub()}}};
// respawn (conquest)
let respChoice=null;
UI.respawnOpen5=()=>{UI.respawnOpen=true;respChoice=null;const el=$('respawn');el.hidden=false;const b=$('respBtns');b.innerHTML='';const pb=$('respPresets');pb.innerHTML='';
  const ffa=MODES[M.mode].ffa;
  if(!ffa){PF.presets.forEach((pr,i)=>{const btn=document.createElement('button');btn.type='button';btn.className='card';btn.setAttribute('aria-pressed',String(PF.preset===i));
    btn.innerHTML=`<b>${pr.name}</b><small>${[pr.p1,pr.p2,pr.pistol].filter(Boolean).map(w=>WEAPONS[w].name).join(' · ')}</small>`;btn.onclick=()=>{PF.preset=i;savePF();[...pb.children].forEach(c=>c.setAttribute('aria-pressed','false'));btn.setAttribute('aria-pressed','true')};pb.appendChild(btn)})}
  const add=(label,pt)=>{const btn=document.createElement('button');btn.className='ghost';btn.type='button';btn.textContent=label;btn.onclick=()=>{respChoice=pt||'auto';[...b.children].forEach(c=>c.style.borderColor='');btn.style.borderColor='var(--amber)';if(P.respawnT<=0)respawnPlayer(pt)};b.appendChild(btn)};
  if(M.mode==='conquest'){add('基地',W.basePos[P.team]);for(const f of W.flags)if(f.owner===P.team)add('據點 '+f.label,{x:f.x+rnd(-5,5),z:f.z+rnd(-5,5)})}else add('立即重生',null)};
UI.respawnTick=t=>{$('respTxt').textContent=t>0?`${Math.ceil(t)} 秒後重生`+(MODES[M.mode].ffa?'':' · 可切換配裝（F1–F3）'):'點選重生';if(t<=0&&respChoice)respawnPlayer(respChoice==='auto'?null:respChoice);else if(t<=-3)respawnPlayer(null)};
UI.respawnClose=()=>{UI.respawnOpen=false;$('respawn').hidden=true};
// results
UI.showResult=(r,spectate)=>{const el=$('result');el.hidden=false;$('hud').hidden=true;$('touch').hidden=true;$('resItems').innerHTML='';$('resLost').textContent='';
  const st=$('resStats');st.innerHTML='';const stat=(k,v,c)=>{const d=document.createElement('div');d.innerHTML=`<span class="k">${k}</span><strong${c?` style="color:${c}"`:''}>${v}</strong>`;st.appendChild(d)};
  if(r.mode!=='extract'){$('resTitle').textContent=r.kind==='win'?'勝利':r.kind==='draw'?'平手':'戰敗';$('resTitle').className=r.kind==='win'?'win':'lose';$('resTag').textContent=MODES[r.mode].name+' · '+MAPS[M.map].name+' · '+clock(r.time);
    $('resSub').textContent=r.line||'';if(r.quests&&r.quests.length)for(const q of r.quests)stat('完成委託',q.desc+' +'+fmt(q.reward),'#72f5a8');stat('擊殺',r.kills);stat('陣亡',r.deaths||0);if(r.assists)stat('助攻',r.assists);if(r.caps)stat('佔領 / 得分',r.caps);if(r.heads)stat('爆頭',r.heads);stat('獎勵',fmt(r.reward),'var(--amber)')}
  else{const T2={win:['撤離成功','win'],dead:['陣亡','lose'],mia:['未能撤離','lose'],abandon:['放棄任務','lose']}[r.kind];$('resTitle').textContent=T2[0];$('resTitle').className=T2[1];
    $('resTag').textContent=`${MAPS[r.map].name} · 行動時間 ${clock(r.time)}`;
    $('resSub').textContent=r.kind==='win'?'所有攜帶的物品已存入倉庫，到商店可以出售。':'只有保險箱裡的物品被帶回。'+(spectate?' 你是房主，請留在這個畫面讓隊友繼續遊戲。':'');
    stat('擊殺',r.kills);stat('爆頭',r.heads);stat('搜索',r.searched);stat('帶回價值',fmt(r.value),'var(--amber)');if(r.lootK)stat('下局爆率',(r.lootK>1.02?'↑ ':r.lootK<.98?'↓ ':'')+'×'+r.lootK.toFixed(2),r.lootK>=1?'#72f5a8':'#ff6b5e');
    const cnt={};for(const id of r.items)cnt[id]=(cnt[id]||0)+1;for(const id in cnt){const c=document.createElement('span');c.className='chip';if(id.startsWith('__w_')){c.style.color='var(--amber)';c.textContent='槍枝：'+WEAPONS[id.slice(4)].name}else if(id.startsWith('__g_')){c.style.color='#8fb6ff';c.textContent='裝備：'+GEAR[GEAR_KIND[id.slice(4)]][id.slice(4)].name}else{c.style.color=RARITY[ITEMS[id].r];c.textContent=ITEMS[id].name+(cnt[id]>1?' ×'+cnt[id]:'')}$('resItems').appendChild(c)}
    if(r.lost&&r.lost.length)$('resLost').textContent='遺失：'+r.lost.slice(0,14).join('、')+(r.lost.length>14?'…':'')}
  $('resHub').textContent=spectate?'結束並返回倉庫':'返回倉庫'};
$('resHub').onclick=()=>{if(M.running){if(M.net&&M.isHost)netEndForAll();stopMatch()}UI.toHub()};
$('resAgain').onclick=()=>{if(M.running){if(M.net&&M.isHost)netEndForAll();stopMatch()}if(M.net){UI.toHub();Hub.tab='net';Hub.render();return}UI.toHub();Hub.tab='deploy';Hub.render()};
const clock=s=>{s=Math.max(0,Math.ceil(s));return `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`};

/* ---------- minimap / big map ---------- */
let mapBase=null,MS=2;
function buildMinimapBase(){MS=600/(W.half*2);mapBase=document.createElement('canvas');mapBase.width=mapBase.height=600;const g=mapBase.getContext('2d');const h=W.half;
  g.fillStyle=THEME.snowy?'#2a2f33':'#1b1d19';g.fillRect(0,0,600,600);
  if(TR){// 地形陰影 + 每 5 公尺等高線
    const N=200,im=g.createImageData(N,N),st=h*2/N,b0=THEME.snowy?[42,47,51]:[27,29,25];for(let j=0;j<N;j++)for(let i=0;i<N;i++){const x=-h+(i+.5)*st,z=-h+(j+.5)*st,y=terrH(x,z);
      const sh=clamp((terrH(x-2,z-2)-terrH(x+2,z+2))*.11,-.5,.5),el=clamp(y/(TR.amp||10),0,1.3)*14,ct=Math.floor(y/5)!==Math.floor(terrH(x+st,z)/5)||Math.floor(y/5)!==Math.floor(terrH(x,z+st)/5);
      const k=(j*N+i)*4,v=sh*40+el+(ct&&y>1?9:0);im.data[k]=clamp(b0[0]+v,0,255);im.data[k+1]=clamp(b0[1]+v,0,255);im.data[k+2]=clamp(b0[2]+v*.85,0,255);im.data[k+3]=255}
    const tc=document.createElement('canvas');tc.width=tc.height=N;tc.getContext('2d').putImageData(im,0,0);g.imageSmoothingEnabled=true;g.drawImage(tc,0,0,600,600)}
  const bx=b=>[(b.minX+h)*MS,(b.minZ+h)*MS,Math.max(1,(b.maxX-b.minX)*MS),Math.max(1,(b.maxZ-b.minZ)*MS)];
  for(const b of W.boxes){if(!b.solid||b.kind==='door')continue;if(b.minY>2&&b.maxY-b.minY<1){g.fillStyle='rgba(60,60,52,.9)';g.fillRect(...bx(b));continue}}
  for(const b of W.boxes){if(b.tree){g.fillStyle='rgba(52,74,44,.85)';g.fillRect(...bx(b));continue}if(!b.solid||b.minY>2||b.kind==='door')continue;g.fillStyle=b.maxY>2.2?'#a69c86':'#5d5a4e';g.fillRect(...bx(b))}
  for(const w of W.water||[]){g.fillStyle='#1d3a48';g.fillRect((w.minX+h)*MS,(w.minZ+h)*MS,(w.maxX-w.minX)*MS,(w.maxZ-w.minZ)*MS)}
  if(W.id==='harbor'){g.fillStyle='#1d3a48';g.fillRect((111+h)*MS,0,600,600);g.fillStyle='#4a4f55';g.fillRect((112+h)*MS,(-45+h)*MS,18*MS,90*MS)}}
// 大地圖視窗：中心 + 邊長（公尺）。滾輪縮放、拖曳平移、點一下發座標、雙擊回到核心區
const BMV={cx:0,cz:0,span:0,w:null};
function bmvReset(){BMV.cx=0;BMV.cz=0;BMV.span=W.half*2;BMV.w=W}
function toMap(x,z,size){if(BMV.w!==W)bmvReset();return[((x-BMV.cx)/BMV.span+.5)*size,((z-BMV.cz)/BMV.span+.5)*size]}
function fromMap(px,py,size){return[(px/size-.5)*BMV.span+BMV.cx,(py/size-.5)*BMV.span+BMV.cz]}
(function(){const c=$('bigmapC');let drag=null;const pt=e=>{const r=c.getBoundingClientRect();return[(e.clientX-r.left)/r.width*1000,(e.clientY-r.top)/r.height*1000]};
  c.addEventListener('wheel',e=>{e.preventDefault();if(!W)return;const [px,py]=pt(e);const [wx,wz]=fromMap(px,py,1000);const k=e.deltaY>0?1.35:1/1.35;const maxS=(W.world||W.half)*2;BMV.span=clamp(BMV.span*k,60,maxS);
    BMV.cx=wx-(px/1000-.5)*BMV.span;BMV.cz=wz-(py/1000-.5)*BMV.span;drawBigMap()},{passive:false});
  c.addEventListener('pointerdown',e=>{const [px,py]=pt(e);drag={px,py,cx:BMV.cx,cz:BMV.cz,moved:false};c.setPointerCapture(e.pointerId)});
  c.addEventListener('pointermove',e=>{if(!drag)return;const [px,py]=pt(e);if(Math.hypot(px-drag.px,py-drag.py)>6)drag.moved=true;if(drag.moved){BMV.cx=drag.cx-(px-drag.px)/1000*BMV.span;BMV.cz=drag.cz-(py-drag.py)/1000*BMV.span;drawBigMap()}});
  c.addEventListener('pointerup',e=>{if(!drag)return;const d=drag;drag=null;if(d.moved||!M.running)return;const [wx,wz]=fromMap(d.px,d.py,1000);mapPing(wx,wz,10/1000*BMV.span*1.6);drawBigMap()});
  c.addEventListener('dblclick',()=>{bmvReset();drawBigMap()})})();
const EXCOL={std:'#72f5a8',paid:'#ffb547',power:'#ff4b3e',heli:'#9ad0ff',nobag:'#6db5ff',task:'#c38bff'};
const EXNAME={std:'常規撤離',paid:'付費撤離',power:'拉閘撤離',heli:'直升機撤離',nobag:'無背包撤離',task:'特殊撤離'};
function toggleBigMap(){if(!M.running)return;UI.mapOpen=!UI.mapOpen;$('bigmap').hidden=!UI.mapOpen;if(UI.mapOpen){unlockPointer();drawBigMap()}else lockPointer()}
$('mapClose').onclick=()=>toggleBigMap();
function drawBigMap(){const c=$('bigmapC'),g=c.getContext('2d'),S=1000;if(BMV.w!==W)bmvReset();g.fillStyle='#141612';g.fillRect(0,0,S,S);
  if(worldBase&&W.world>W.half){const [a,b]=toMap(-WORLD_HALF,-WORLD_HALF,S),[a2,b2]=toMap(WORLD_HALF,WORLD_HALF,S);g.imageSmoothingEnabled=true;g.drawImage(worldBase,a,b,a2-a,b2-b);g.strokeStyle='rgba(255,90,60,.6)';g.lineWidth=2;g.strokeRect(a,b,a2-a,b2-b)}
  {const [a,b]=toMap(-W.half,-W.half,S),[a2,b2]=toMap(W.half,W.half,S);g.drawImage(mapBase,a,b,a2-a,b2-b);if(W.world>W.half){g.strokeStyle='rgba(255,181,71,.55)';g.lineWidth=1.5;g.strokeRect(a,b,a2-a,b2-b)}}
  g.textAlign='center';const zoomedOut=BMV.span>W.half*5;
  for(const s of W.sats||[]){const [x,y]=toMap(s.x,s.z,S);if(x<-50||y<-50||x>S+50||y>S+50)continue;const r=Math.max(4,s.r/BMV.span*S);g.strokeStyle='#d8d0bf';g.lineWidth=2;g.strokeRect(x-r,y-r,r*2,r*2)}
  g.font='500 17px "Noto Sans TC",sans-serif';for(const l of W.landmarks||[]){if(l.name==='車庫')continue;if(zoomedOut&&Math.max(Math.abs(l.x),Math.abs(l.z))<W.half)continue;const [x,y]=toMap(l.x,l.z,S);g.fillStyle='rgba(13,15,12,.6)';const tw=g.measureText(l.name).width;g.fillRect(x-tw/2-4,y-13,tw+8,19);g.fillStyle=M.visited&&M.visited.has(l.name)?'#72f5a8':'#d8d0bf';g.fillText(l.name,x,y+2)}
  drawTreasureBig(g,S);for(const b of W.buried||[])if(!b.dug&&!b.treasure){const [x,y]=toMap(b.pos.x,b.pos.z,S);g.fillStyle='#ffd34a';g.save();g.translate(x,y);g.rotate(Math.PI/4);g.fillRect(-8,-8,16,16);g.restore();g.fillText('埋藏點',x,y-14)}
  for(const b of bots)if(!b.dead&&b.team!==P.team&&(b.markT>0||b.chipT>0)){const [x,y]=toMap(b.pos.x,b.pos.z,S);g.fillStyle='#ff4b3e';g.beginPath();g.arc(x,y,6,0,TAU);g.fill();if(b.chipT>0){g.strokeStyle='#ff4b3e';g.lineWidth=2;g.beginPath();g.arc(x,y,11,0,TAU);g.stroke();g.fillText('晶片',x,y-15)}}
  g.font='700 16px "JetBrains Mono",monospace';for(const s of W.hackSpots||[]){const [x,y]=toMap(s.x,s.z,S);g.fillStyle='#0b120d';g.fillRect(x-10,y-10,20,20);g.strokeStyle='#40ff80';g.lineWidth=2;g.strokeRect(x-10,y-10,20,20);g.fillStyle='#40ff80';g.fillText('H',x,y+6)}g.font='500 17px "Noto Sans TC",sans-serif';
  drawPingsBig(g,S);
  if(typeof netPuppets!=='undefined')for(const k in netPuppets){const q=netPuppets[k];if(q.alive&&q.markT>0&&hostile(q.team,P.team)){const [x,y]=toMap(q.pos.x,q.pos.z,S);g.fillStyle='#ff4b3e';g.beginPath();g.arc(x,y,6,0,TAU);g.fill()}}
  for(const cc of W.cars||[])if(!cc.dead){const [x,y]=toMap(cc.pos.x,cc.pos.z,S);g.fillStyle='#9ad0ff';g.fillRect(x-7,y-5,14,10)}
  g.font='700 22px "Noto Sans TC",sans-serif';
  if(M.mode==='extract'){for(const e of W.extracts){const [x,y]=toMap(e.pos.x,e.pos.z,S);g.fillStyle=EXCOL[e.type];g.globalAlpha=extractOK(e)?1:.45;g.beginPath();g.arc(x,y,13,0,TAU);g.fill();g.globalAlpha=1;g.fillStyle='#efe7d6';g.fillText(e.name,x,y-20)}
    for(const s of W.switches){const [x,y]=toMap(s.pos.x,s.pos.z,S);g.fillStyle=s.on?'#30ff60':'#ffd23a';g.fillRect(x-8,y-8,16,16)}
    if(airdrop){const [x,y]=toMap(airdrop.x,airdrop.z,S);g.strokeStyle='#ff4b3e';g.lineWidth=4;g.beginPath();g.arc(x,y,18,0,TAU);g.stroke();g.fillStyle='#ff4b3e';g.fillText('空投',x,y-24)}}
  else for(const f of W.flags){const [x,y]=toMap(f.x,f.z,S);g.fillStyle=f.owner===1?'#4a8cff':f.owner===2?'#ff4b3e':'#cccccc';g.beginPath();g.arc(x,y,16,0,TAU);g.fill();g.fillStyle='#0d0f0c';g.fillText(f.label,x,y+8)}
  for(const k in netPuppets){const p=netPuppets[k];if(!p.alive)continue;const [x,y]=toMap(p.pos.x,p.pos.z,S);g.fillStyle='#72c8f5';g.beginPath();g.arc(x,y,9,0,TAU);g.fill();g.fillText(p.nick,x,y-14)}
  const [px,py]=toMap(P.pos.x,P.pos.z,S);g.save();g.translate(px,py);g.rotate(heading()*Math.PI/180);g.fillStyle='#ffb547';g.beginPath();g.moveTo(0,-16);g.lineTo(-11,12);g.lineTo(0,6);g.lineTo(11,12);g.closePath();g.fill();g.restore();
  g.textAlign='left';g.font='600 18px "JetBrains Mono",monospace';g.fillStyle='rgba(13,15,12,.7)';g.fillRect(12,S-40,330,30);g.fillStyle='#efe7d6';g.fillText('視野寬 '+(BMV.span>=2000?(BMV.span/1000).toFixed(1)+' km':Math.round(BMV.span)+' m')+' · 滾輪縮放 · 拖曳移動',20,S-19);g.textAlign='center';
  $('mapLegend').innerHTML='<span>點一下地圖＝發座標（隊友會前往）· 雙擊＝回到核心區</span>'+(M.mode==='extract'?Object.keys(EXNAME).map(k=>`<span><i style="background:${EXCOL[k]}"></i>${EXNAME[k]}</span>`).join('')+'<span><i style="background:#ffd23a;border-radius:0"></i>電閘</span><span>暗色圖示 = 尚未開放</span>':'<span><i style="background:#4a8cff"></i>我方據點</span><span><i style="background:#ff4b3e"></i>敵方據點</span><span><i style="background:#ccc"></i>中立</span>')}

/* ---------- HUD per frame ---------- */
UI._c={};const setT=(id,v)=>{if(UI._c[id]!==v){UI._c[id]=v;$(id).textContent=v}};
const cc=$('compass').getContext('2d'),mc=$('mini').getContext('2d');
const LBL={0:'北',45:'東北',90:'東',135:'東南',180:'南',225:'西南',270:'西',315:'西北'};
function marker(hd,bearing,col,label,ppd,w){let rel=((bearing-hd+540)%360)-180;const x=w/2+clamp(rel,-62,62)*ppd;cc.fillStyle=col;cc.beginPath();cc.moveTo(x,50);cc.lineTo(x-8,62);cc.lineTo(x,74);cc.lineTo(x+8,62);cc.closePath();cc.fill();if(label){cc.font='700 14px "JetBrains Mono",monospace';cc.fillText(label,x+(rel<0?-36:36),62)}}
function drawCompass(){const w=1120,hd=heading(),ppd=w/130;cc.clearRect(0,0,w,88);
  const gr=cc.createLinearGradient(0,0,w,0);gr.addColorStop(0,'rgba(10,12,9,0)');gr.addColorStop(.15,'rgba(10,12,9,.55)');gr.addColorStop(.85,'rgba(10,12,9,.55)');gr.addColorStop(1,'rgba(10,12,9,0)');cc.fillStyle=gr;cc.fillRect(0,0,w,46);
  cc.textAlign='center';cc.textBaseline='middle';
  for(let a=Math.floor((hd-65)/5)*5;a<=hd+65;a+=5){const x=w/2+(a-hd)*ppd,n=((a%360)+360)%360,big=n%45===0,mid=n%15===0;cc.fillStyle=big?'#efe7d6':'rgba(239,231,214,.55)';cc.fillRect(x-1,big?4:mid?8:12,2,big?14:mid?10:6);
    if(big){cc.font='700 22px "Noto Sans TC",sans-serif';cc.fillStyle=n===0?'#ffb547':'#efe7d6';cc.fillText(LBL[n],x,34)}else if(mid){cc.font='500 16px "JetBrains Mono",monospace';cc.fillStyle='rgba(239,231,214,.6)';cc.fillText(n,x,34)}}
  if(M.mode==='extract'){for(const e of W.extracts){if(!extractOK(e))continue;marker(hd,bearingTo(e.pos.x,e.pos.z),EXCOL[e.type],Math.round(Math.hypot(e.pos.x-P.pos.x,e.pos.z-P.pos.z))+'m',ppd,w)}
    for(const b of treasures())marker(hd,bearingTo(b.hint.x,b.hint.z),'#ffd34a','寶藏 '+Math.round(Math.hypot(b.hint.x-P.pos.x,b.hint.z-P.pos.z))+'m',ppd,w);
    if(airdrop&&!airdrop.looted)marker(hd,bearingTo(airdrop.x,airdrop.z),'#ff4b3e','空投 '+Math.round(Math.hypot(airdrop.x-P.pos.x,airdrop.z-P.pos.z))+'m',ppd,w)}
  else for(const f of W.flags)marker(hd,bearingTo(f.x,f.z),f.owner===P.team?'#4a8cff':f.owner?'#ff4b3e':'#cccccc',f.label,ppd,w);
  if(M.relic)marker(hd,bearingTo(M.relic.pos.x,M.relic.pos.z),'#ffd34a','聖物',ppd,w);if(M.mode==='relic'){const b=W.basePos[P.team];marker(hd,bearingTo(b.x,b.z),'#4a8cff','基地',ppd,w)}
  if(M.mode==='zombie')marker(hd,bearingTo(W.holdPos.x,W.holdPos.z),'#72f5a8','據點',ppd,w);
  for(const k in netPuppets){const p=netPuppets[k];if(p.alive&&!hostile(P.team,p.team))marker(hd,bearingTo(p.pos.x,p.pos.z),'#72c8f5','',ppd,w)}
  cc.fillStyle='#ffb547';cc.beginPath();cc.moveTo(w/2,52);cc.lineTo(w/2-7,44);cc.lineTo(w/2+7,44);cc.closePath();cc.fill()}
function drawMini(){const s=300,c=s/2,K=2.2;mc.clearRect(0,0,s,s);mc.save();mc.beginPath();mc.arc(c,c,c-2,0,TAU);mc.clip();mc.translate(c,c);mc.rotate(-heading()*Math.PI/180);
  if(worldBase&&W.world>W.half)mc.drawImage(worldBase,(-WORLD_HALF-P.pos.x)*K,(-WORLD_HALF-P.pos.z)*K,WORLD_HALF*2*K,WORLD_HALF*2*K);
  mc.save();mc.scale(K/MS,K/MS);mc.drawImage(mapBase,-(P.pos.x+W.half)*MS,-(P.pos.z+W.half)*MS);mc.restore();
  if(M.mode==='extract')for(const e of W.extracts){mc.fillStyle=EXCOL[e.type];mc.globalAlpha=extractOK(e)?.5:.15;mc.beginPath();mc.arc((e.pos.x-P.pos.x)*K,(e.pos.z-P.pos.z)*K,e.r*K,0,TAU);mc.fill();mc.globalAlpha=1}
  else for(const f of W.flags){mc.fillStyle=f.owner===1?'rgba(74,140,255,.5)':f.owner===2?'rgba(255,75,62,.5)':'rgba(200,200,200,.4)';mc.beginPath();mc.arc((f.x-P.pos.x)*K,(f.z-P.pos.z)*K,f.r*K,0,TAU);mc.fill()}
  for(const b of W.buried||[])if(!b.dug){mc.fillStyle='#ffd34a';mc.fillRect((b.pos.x-P.pos.x)*K-5,(b.pos.z-P.pos.z)*K-5,10,10)}
  if(M.relic){mc.fillStyle='#ffd34a';mc.beginPath();mc.arc((M.relic.pos.x-P.pos.x)*K,(M.relic.pos.z-P.pos.z)*K,7,0,TAU);mc.fill()}
  for(const b of bots){if(b.dead)continue;const ally=b.team===P.team;if(!ally&&b.spotT<=0&&b.markT<=0&&b.pos.distanceTo(P.pos)>12&&!skRevealBot(b))continue;mc.fillStyle=ally?'#72c8f5':'#ff4b3e';mc.beginPath();mc.arc((b.pos.x-P.pos.x)*K,(b.pos.z-P.pos.z)*K,b.kind==='boss'?8:5,0,TAU);mc.fill()}
  for(const k in netPuppets){const p=netPuppets[k];if(!p.alive)continue;const en=hostile(P.team,p.team);if(en&&!skRevealPup(p))continue;mc.fillStyle=en?'#ff4b3e':'#72c8f5';mc.beginPath();mc.arc((p.pos.x-P.pos.x)*K,(p.pos.z-P.pos.z)*K,6,0,TAU);mc.fill()}
  if(airdrop&&!airdrop.looted){let x=(airdrop.x-P.pos.x)*K,y=(airdrop.z-P.pos.z)*K;const L=Math.hypot(x,y),R=c-10;if(L>R){x*=R/L;y*=R/L}mc.strokeStyle='#ff4b3e';mc.lineWidth=3;mc.beginPath();mc.arc(x,y,7+2*Math.sin(M.t*6),0,TAU);mc.stroke()}
  drawTreasureMini(mc,K,c);for(const s of W.hackSpots||[]){let x=(s.x-P.pos.x)*K,y=(s.z-P.pos.z)*K;const L=Math.hypot(x,y);if(L>c-10)continue;mc.strokeStyle='#40ff80';mc.lineWidth=2;mc.strokeRect(x-5,y-5,10,10)}
  drawPingsMini(mc,K,c);mc.restore();mc.fillStyle='#ffb547';mc.beginPath();mc.moveTo(c,c-11);mc.lineTo(c-8,c+8);mc.lineTo(c,c+4);mc.lineTo(c+8,c+8);mc.closePath();mc.fill();
  mc.strokeStyle='rgba(239,231,214,.25)';mc.lineWidth=2;mc.beginPath();mc.arc(c,c,c-2,0,TAU);mc.stroke()}
function buildSlotButtons(){const el=$('slots');el.innerHTML='';P.slots.forEach((s,i)=>{if(!s)return;const b=document.createElement('button');b.type='button';b.dataset.i=i;
  b.innerHTML=`<b>${i+1} ${s.knife?'戰術刀':s.def.name.split(' ')[0]}</b><span></span>`;b.addEventListener('click',()=>switchTo(i));b.addEventListener('touchstart',e=>{e.preventDefault();switchTo(i)},{passive:false});el.appendChild(b)})}
function buildSkillTiles(){const o=OPERATORS[P.op];$('skills').innerHTML=['s1','s2','s3'].map((k,i)=>`<div class="sk" id="sk_${k}"><div class="cd"></div><kbd>${['長按'+bindLabel('leanL'),bindLabel('s2'),bindLabel('s3')][i]}</kbd><span>${o[k].name}</span><i class="n"></i></div>`).join('')+`<div class="sk pas" title="${esc(o.passive.desc)}"><kbd>被動</kbd><span>${o.passive.name}</span></div>`;
  $('tS1').textContent=o.s1.name.slice(0,4);$('tS2').textContent=o.s2.name.slice(0,4);$('tS3').textContent=o.s3.name.slice(0,4)}
const ST_LABEL=[['frozenT','凍結','#7fe7ff'],['stunT','暈眩','#ffd34a'],['disarmT','繳械','#ffb547'],['slowT','減速','#ffb547'],['blurT','模糊','#c38bff'],['deafT','失聰','#c38bff'],['nosprintT','無法衝刺','#ffb547'],['invisT','隱形','#62f0e0'],['speedT','加速','#72f5a8'],['staminaT','無限體力','#72f5a8']];
function statusChips(){const st=P.st;if(!st)return'';let h='';for(const [k,l,c] of ST_LABEL)if(st[k]>0)h+=`<span style="border-color:${c};color:${c}">${l} ${Math.ceil(st[k])}</span>`;
  if(P.hackT>0)h+=`<span style="border-color:#40ff80;color:#40ff80">電腦被駭 ${Math.ceil(P.hackT)}（H 重開機）</span>`;
  if(P.chipT>0)h+=`<span style="border-color:#ff4b3e;color:#ff4b3e">晶片追蹤·位置暴露 ${Math.ceil(P.chipT)}（H 拆除）</span>`;
  if(st.frost>0)h+=`<span style="border-color:#9fe8ff;color:#9fe8ff">寒霜 ×${st.frost}</span>`;if(st.dots.length)h+=`<span style="border-color:#ff6b5e;color:#ff6b5e">持續傷害</span>`;
  if(st.shield>0)h+=`<span style="border-color:#ff9ad5;color:#ff9ad5">護盾 ${Math.ceil(st.shield)}</span>`;if(P.fshield)h+=`<span style="border-color:#5ad1ff;color:#5ad1ff">推進護盾 ${Math.ceil(P.fshield.hp)}</span>`;
  if(P.overT>0)h+=`<span style="border-color:#ff7a3d;color:#ff7a3d">超載 ${Math.ceil(P.overT)}</span>`;if(P.suitT>0)h+=`<span style="border-color:#3d7bff;color:#3d7bff">防爆套裝 ${Math.ceil(P.suitT)}</span>`;
  if(P.anchor)h+=`<span style="border-color:#5ad1ff;color:#5ad1ff">定位錨 ${Math.ceil(P.anchor.life-P.anchor.t)}</span>`;if(P.radarT>0)h+=`<span style="border-color:#62f0e0;color:#62f0e0">雷達駭入 ${Math.ceil(P.radarT)}</span>`;
  if(P.skMode)h+=`<span style="border-color:#5fe0a0;color:#5fe0a0">${P.skMode.kind==='stim'?'治療針':'冷凝榴彈'} ×${P.skMode.n}</span>`;if(P.nvg)h+=`<span style="border-color:#7dff8a;color:#7dff8a">夜視</span>`;
  if(Math.abs(P.lean)>0)h+=`<span>${P.lean<0?'左':'右'}探頭</span>`;if(P.proneOn)h+=`<span>趴下</span>`;return h}
function hud(dt){
  const s=curW();
  if(M.frame%15===0&&typeof dayPhase==='function')setT('todTag',dayPhase()+' '+clockStr()+(W.weather&&WEATHERS[W.weather]?' · '+WEATHERS[W.weather].name:''));
  if(M.mode==='extract'){if(M.timeLimit>9000){setT('timer',clockStr());setT('timerLbl','遊戲時間 · '+(WEATHERS[W.weather]||{}).name);$('timer').className=''}else{setT('timerLbl','撤離倒數');setT('timer',clock(M.left));$('timer').className=M.left<180?'warn':''}if(P.swim||P.breath<30){$('breathRow').hidden=false;$('brFill').style.width=(P.breath/30*100)+'%'}else $('breathRow').hidden=true;setT('carry',fmt(invValue()))}
  else{if(M.timeLimit>9000&&M.mode!=='zombie'&&M.mode!=='duel')setT('timerLbl','已進行');setT('timer',M.mode==='zombie'?`第 ${M.wave} 波`:M.mode==='duel'||M.mode==='rats'?`第 ${Math.max(1,M.round)} 回合`:M.timeLimit>9000?clock(M.t):clock(M.cqLeft||0));setT('carry',String(M.stats.score));
    const mine=P.team===2?2:1,oth=mine===1?2:1;
    if(M.hudV){setT('tk1',M.hudV[0]);setT('tk2',M.hudV[1])}
    else if(M.mode==='conquest'){setT('tk1',String(M.score[mine]));setT('tk2',String(M.score[oth]))}
    else if(M.mode==='tdm'||M.mode==='relic'){setT('tk1',String(M.score[mine]));setT('tk2',String(M.score[oth]))}
    else if(M.mode==='duel'){setT('tk1',String(M.rounds[1]));setT('tk2',String(M.rounds[2]))}
    else if(M.mode==='zombie'){setT('tk1',String(bots.filter(b=>!b.dead).length+(M.toSpawn||0)));setT('tk2',M.waveState==='prep'?Math.ceil(Math.max(0,M.waveT))+'s':'')}
    else{const top=ffaBoard()[0];setT('tk1',String(M.stats.kills));setT('tk2',top.me?'領先':String(top.kills))}
    W.flags.forEach((f,i)=>{const e=$('fc'+i);if(!e)return;const col=f.owner===mine?'#4a8cff':f.owner?'#ff4b3e':'#888';if(e._c!==col+f.inMe){e._c=col+f.inMe;e.style.borderColor=col;e.style.color=col;e.style.background=f.inMe?'rgba(255,255,255,.12)':''}});
    if(UI.scoreOpen&&M.frame%20===0)renderScore()}
  setT('kills',`擊殺 ${M.stats.kills} · 爆頭 ${M.stats.heads}`);
  $('hpFill').style.width=Math.min(100,P.hp)+'%';$('stFill').style.width=P.stam+'%';$('stFill').style.background=P.stamLock?'var(--danger)':'#9be15d';setT('stNum',String(Math.round(P.stam)));$('hpFill').style.background=P.hp<35?'var(--danger)':'var(--text)';setT('hpNum',P.downed?'倒地':String(Math.ceil(P.hp))+(P.st&&P.st.shield>0?' +'+Math.ceil(P.st.shield):''));if(M.frame%6===0){const sc=statusChips();const el=$('stChips');if(el._h!==sc){el._h=sc;el.innerHTML=sc}}
  setT('helmT',P.helmet.tier?['','Ⅰ','Ⅱ','Ⅲ','Ⅳ','Ⅴ'][P.helmet.tier]+' 盔':'頭盔');$('helmFill').style.width=(P.helmet.max?P.helmet.dur/P.helmet.max*100:0)+'%';setT('helmNum',P.helmet.tier?`${Math.ceil(P.helmet.dur)}/${P.helmet.max}`:'—');
  setT('armT',P.armor.tier?['','Ⅰ','Ⅱ','Ⅲ','Ⅳ','Ⅴ'][P.armor.tier]+' 甲':'護甲');$('armFill').style.width=(P.armor.max?P.armor.dur/P.armor.max*100:0)+'%';setT('armNum',P.armor.tier?`${Math.ceil(P.armor.dur)}/${P.armor.max}`:'—');
  setT('items',`[H] 醫療 ${invCount('med')+invCount('surg')}  [G] ${P.nades?(P.nades.type==='frag'?'手雷':'煙霧彈')+' '+P.nades.n:'—'}  [T] 修甲 ${invCount('repair')}  [L] 手電 ${P.torchOn?'開':'關'}  [Z] 夜視 ${P.nvg?'開':'關'}`);
  if(s){if(s.knife){setT('wname','戰術刀');setT('mag','—');setT('res','');setT('wstate','左鍵 揮砍 · 背刺 ×3')}
    else{setT('wname',s.def.name);setT('mag',String(s.mag));setT('res','/ '+P.ammo[s.def.ammo]);$('mag').className=s.mag<=Math.ceil(s.st.mag*.2)?'low':'';
      setT('wstate',P.healT>0?'治療中…':P.repairT>0?'修復護甲中…':P.reloadT>0?'換彈中…':s.mag===0?(P.ammo[s.def.ammo]?(isTouch?'點換彈':'按 R 換彈'):'彈藥耗盡'):(s.def.auto?'全自動':s.def.bolt?'栓動':s.def.pel?'泵動':'半自動')+(P.ads?' · 開鏡':''))}}
  [...$('slots').children].forEach(b=>{const i=+b.dataset.i,x=P.slots[i];b.classList.toggle('on',i===P.cur);const t=x.knife?'近戰':x.mag+' / '+P.ammo[x.def.ammo];if(b.lastChild.textContent!==t)b.lastChild.textContent=t});
  const o=OPERATORS[P.op];for(const k of ['s1','s2','s3']){const el=$('sk_'+k);if(!el)continue;const c=skCd(k);let p=c/o[k].cd*100;if(k==='s1'&&P.qDown>=0&&keys.KeyQ&&!P.qFired&&c<=0)p=100-Math.min(1,(M.t-P.qDown)/1.2)*100;if(o[k].charges){const n=el.lastChild;const t='×'+P.chg[k];if(n.textContent!==t)n.textContent=t}el.firstChild.style.setProperty('--p',p+'%');el.classList.toggle('ready',p<=0);
    const tb=$('t'+k.toUpperCase());tb.classList.toggle('cd',p>0);tb.classList.toggle('rdy',p<=0)}
  if(isTouch){$('tAds').classList.toggle('on',P.ads);$('tCrouch').classList.toggle('on',P.crouchOn);$('tLight').classList.toggle('on',P.torchOn);$('tProne').classList.toggle('on',P.proneOn);$('tNvg').classList.toggle('on',P.nvg)}
  const sp=currentSpread(),gap=5+sp*700,xh=$('xh');xh.style.opacity=(1-P.adsK)*(P.sprint?.3:1)*(P.alive?1:0);
  xh.children[0].style.top=(-gap-9)+'px';xh.children[1].style.top=gap+'px';xh.children[2].style.left=(-gap-9)+'px';xh.children[3].style.left=gap+'px';
  hitT-=dt;const hEl=$('hit');hEl.style.opacity=Math.max(0,hitT/.18);hEl.style.color=hitKind==='kill'?'#ff4b3e':hitKind==='head'?'#ffb547':'#efe7d6';hEl.style.transform=`scale(${hitKind==='kill'?1.4:1})`;
  for(let i=dirs.length-1;i>=0;i--){const d=dirs[i];d.t-=dt;if(d.t<=0){d.el.remove();dirs.splice(i,1);continue}d.el.style.transform=`rotate(${bearingTo(d.x,d.z)-heading()}deg)`;d.el.style.opacity=Math.min(1,d.t)}
  const low=clamp((40-P.hp)/40,0,1);$('vig').style.opacity=Math.min(1,low*.75+P.dmgFlash*.8+(!P.alive||P.downed?.6:0));$('blind').style.opacity=Math.min(1,P.blindT/1.5);
  if(low>0&&P.alive){heartT-=dt;if(heartT<=0){heartT=.85-low*.3;blip(55,.12,'sine',.25*low+.05);blip(48,.12,'sine',.2*low+.04,0,.16)}}
  // squad
  const sq=Object.values(netPuppets);const sqh=sq.map(p=>`${p.nick} · ${p.downed?'倒地':p.alive?Math.round(p.hp)+' HP':'陣亡'}`).join('|');if(UI._c.sq!==sqh){UI._c.sq=sqh;$('squad').innerHTML='';for(const p of sq){const d=document.createElement('div');d.textContent=`${p.nick} · ${p.downed?'倒地':p.alive?Math.round(p.hp)+' HP':'陣亡'}`;$('squad').appendChild(d)}}
  if(bannerT>0){bannerT-=dt;if(bannerT<=0)$('banner').style.opacity=0}if(noteT>0){noteT-=dt;if(noteT<=0)$('note').style.opacity=0}
  invTick();$('xh').style.visibility=P.car||P.emote?'hidden':'';drawCompass();drawMini();if(UI.mapOpen&&(M.frame%15===0))drawBigMap();if(UI.invOpen&&M.frame%30===0)$('invVal').textContent=fmt(invValue());
}

/* ---------- touch controls ---------- */
(function(){const TS=2.4,stickEl=$('stick'),knob=stickEl.firstElementChild,zone=$('tZone');
  const stickMove=(x,y)=>{let dx=x-touchS.ox,dy=y-touchS.oy;const l=Math.hypot(dx,dy),R=55;if(l>R){dx*=R/l;dy*=R/l}touchS.jx=dx/R;touchS.jy=dy/R;knob.style.transform=`translate(${dx}px,${dy}px)`};
  zone.addEventListener('touchstart',e=>{e.preventDefault();if(!M.running)return;initAudio();for(const t of e.changedTouches){
    if(t.clientX<innerWidth*.42&&touchS.stickId===null){touchS.stickId=t.identifier;touchS.ox=t.clientX;touchS.oy=t.clientY;touchS.jx=touchS.jy=0;stickEl.hidden=false;stickEl.style.left=t.clientX+'px';stickEl.style.top=t.clientY+'px';knob.style.transform=''}
    else if(touchS.lookId===null){touchS.lookId=t.identifier;touchS.lx=t.clientX;touchS.ly=t.clientY}}},{passive:false});
  zone.addEventListener('touchmove',e=>{e.preventDefault();for(const t of e.changedTouches){if(t.identifier===touchS.stickId)stickMove(t.clientX,t.clientY);else if(t.identifier===touchS.lookId){lookDX+=(t.clientX-touchS.lx)*TS;lookDY+=(t.clientY-touchS.ly)*TS;touchS.lx=t.clientX;touchS.ly=t.clientY}}},{passive:false});
  const zEnd=e=>{for(const t of e.changedTouches){if(t.identifier===touchS.stickId){touchS.stickId=null;touchS.jx=touchS.jy=0;stickEl.hidden=true}if(t.identifier===touchS.lookId)touchS.lookId=null}};
  zone.addEventListener('touchend',zEnd);zone.addEventListener('touchcancel',zEnd);
  const tb=(id,down,up)=>{const el=$(id);el.addEventListener('touchstart',e=>{e.preventDefault();e.stopPropagation();if(!M.running||!P)return;initAudio();down&&down(e)},{passive:false});const end=e=>{e.preventDefault();up&&up(e)};el.addEventListener('touchend',end,{passive:false});el.addEventListener('touchcancel',end,{passive:false});return el};
  tb('tReload',()=>startReload());tb('tJump',()=>{keys.Space=true;setTimeout(()=>keys.Space=false,140)});
  tb('tCrouch',()=>{if(P.sprint&&P.onGround&&P.slideT<=0)startSlide();else P.crouchOn=!P.crouchOn});tb('tAds',()=>P.alive&&toggleADS());tb('tKnife',()=>quickMelee());
  tb('tNade',()=>skillKeyDown('nade'));tb('tPing',()=>doPing());tb('tLap',()=>toggleLaptop());tb('tCant',()=>toggleCant());tb('tDrop',()=>dropCurrentWeapon());tb('tEmote',()=>openEmotes());tb('tProne',()=>toggleProne());tb('tNvg',()=>toggleNVG());tb('tHeal',()=>startHeal());tb('tLight',()=>toggleTorch());tb('tInv',()=>{if(M.mode==='extract')toggleInventory();else UI.scoreboard(!UI.scoreOpen)});tb('tMap',()=>toggleBigMap());
  for(const k of ['s1','s2','s3'])tb('t'+k.toUpperCase(),()=>skillKeyDown(k));
  tb('tUse',()=>{keys.KeyF=true;tapInteract()},()=>{keys.KeyF=false});tb('tPause',()=>pauseGame());
  const fire=tb('tFire',e=>{const t=e.changedTouches[0];touchS.fireId=t.identifier;touchS.fx=t.clientX;touchS.fy=t.clientY;mouse.l=true;mouse.lPressed=true},()=>{mouse.l=false;touchS.fireId=null;readyFireUp()});
  fire.addEventListener('touchmove',e=>{e.preventDefault();for(const t of e.changedTouches)if(t.identifier===touchS.fireId){lookDX+=(t.clientX-touchS.fx)*TS;lookDY+=(t.clientY-touchS.fy)*TS;touchS.fx=t.clientX;touchS.fy=t.clientY}},{passive:false});
  document.addEventListener('visibilitychange',()=>{if(document.hidden&&M.running)pauseGame()});
})();

/* ---------- click to play (pointer lock needs a click) ---------- */
UI.needClick=()=>{if(isTouch){return}$('clickPlay').hidden=false};
$('clickPlay').addEventListener('click',()=>{initAudio();$('clickPlay').hidden=true;lockPointer(true)});
/* ---------- countdown ---------- */
UI.countdown=t=>{const el=$('countdown');if(t<=0){el.hidden=true;return}el.hidden=false;const v=String(Math.ceil(t));if(el.textContent!==v){el.textContent=v;blip(660,.12,'square',.05)}};
/* ---------- killcam ---------- */
UI.killcamOn=false;let kc=null;
UI.killcam=(pos,name,weapon,done)=>{UI.killcamOn=true;kc={pos,t:2.8,done,from:camera.position.clone()};const el=$('killcam');el.hidden=false;$('kcName').textContent=name||'敵人';$('kcWeap').textContent=weapon||''};
UI.skipKillcam=()=>{if(!kc)return;kc.t=0};
function killcamTick(dt){if(!UI.killcamOn||!kc)return;kc.t-=dt;const tp=kc.pos;const dir=_e1.set(kc.from.x-tp.x,0,kc.from.z-tp.z);const L=dir.length()||1;dir.multiplyScalar(1/L);
  const k=clamp(1-kc.t/2.8,0,1);camera.position.set(tp.x+dir.x*lerp(L,4,Math.min(1,k*2)),tp.y+2.2,tp.z+dir.z*lerp(L,4,Math.min(1,k*2)));camera.lookAt(tp.x,tp.y+1.4,tp.z);
  if(kc.t<=0){UI.killcamOn=false;$('killcam').hidden=true;const d=kc.done;kc=null;d&&d()}}
/* ---------- scoreboard ---------- */
UI.scoreOpen=false;UI.scoreboard=show=>{UI.scoreOpen=show;$('score').hidden=!show;if(show)renderScore()};
function renderScore(){const el=$('scoreBody');const rows=[];
  rows.push({name:(PF.nick||'你')+'（你）',team:P.team,k:M.stats.kills,d:M.stats.deaths,a:M.stats.assists,gg:P.gg||0,me:true});
  for(const k in netPuppets){const p=netPuppets[k];const ps=M.pstats[k]||{k:0,d:0};rows.push({name:p.nick,team:p.team,k:ps.k,d:ps.d,gg:ps.gg||0})}
  for(const b of bots)if(b.kind==='soldier'||b.kind==='gunman')rows.push({name:b.name,team:b.team,k:b.kills,d:b.deaths,gg:b.gg||0,bot:true});
  const ffa=MODES[M.mode].ffa;rows.sort((a,b)=>M.mode==='gungame'?b.gg-a.gg||b.k-a.k:b.k-a.k);
  const tbl=(list,title,col)=>`<div class="sbt"><h3 style="color:${col}">${title}</h3><table><tr><th>玩家</th>${M.mode==='gungame'?'<th>等級</th>':''}<th>擊殺</th><th>陣亡</th></tr>${list.map(r=>`<tr class="${r.me?'me':''}"><td>${esc(r.name)}${r.bot?' <small>AI</small>':''}</td>${M.mode==='gungame'?`<td>${r.gg+1}</td>`:''}<td>${r.k}</td><td>${r.d}</td></tr>`).join('')}</table></div>`;
  if(ffa||M.mode==='zombie'||M.mode==='duel')el.innerHTML=tbl(rows,MODES[M.mode].name,'var(--amber)');
  else{const mine=P.team;el.innerHTML=tbl(rows.filter(r=>r.team===mine),'我方','#72c8f5')+tbl(rows.filter(r=>r.team!==mine),'敵方','#ff6b5e')}}
/* ---------- chat ---------- */
UI.openChat=()=>{const i=$('chatInput');i.hidden=false;i.value='';i.focus();unlockPointer();UI.chatting=true};
$('chatInput').addEventListener('keydown',e=>{e.stopPropagation();if(e.key==='Enter'){netChat($('chatInput').value);$('chatInput').hidden=true;UI.chatting=false;lockPointer(true)}else if(e.key==='Escape'){$('chatInput').hidden=true;UI.chatting=false;lockPointer(true)}});
UI.chatLine=(n,m)=>{const d=document.createElement('div');const b=document.createElement('b');b.textContent=n+'：';d.appendChild(b);d.appendChild(document.createTextNode(m));$('chatLines').appendChild(d);while($('chatLines').children.length>6)$('chatLines').firstChild.remove();setTimeout(()=>d.remove(),12000);blip(1200,.04,'triangle',.03)};
