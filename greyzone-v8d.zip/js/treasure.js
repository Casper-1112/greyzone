'use strict';
/* ================= 挖寶（藏寶圖） =================
   - 物資箱、金庫偶爾會開出「藏寶圖」。在背包裡點一下藏寶圖就會讀取：
     寶藏埋在某個地標或外圍據點附近，大地圖、小地圖與指南針上會出現金色圓圈（半徑 30 m）。
   - 走進圓圈 25 m 內，地上的土堆和金色光點才會出現，對著土堆按住 F 4 秒挖出寶箱。
   - 寶箱裡至少 3 件高價值物品，有機會出大紅。可以同時持有多張藏寶圖。
   - 另外也可以把自己的物品埋起來，下一局再挖（背包裡的「埋藏」格）。 */
function readTreasureMap(){const L=(W.landmarks||[]).filter(l=>!['車庫','坦克','直升機','戰鬥機'].includes(l.name)&&Math.hypot(l.x-P.pos.x,l.z-P.pos.z)>60);
  const pool=(W.sats&&W.sats.length&&Math.random()<.55)?W.sats.map(s=>({name:s.name.replace(/（.*/,''),x:s.x,z:s.z,r:s.r})):L;if(!pool.length){note('這張地圖讀不出藏寶位置');return}
  const l=pick(pool);let p=null;for(let i=0;i<60&&!p;i++){const a=Math.random()*TAU,d=rnd(8,Math.max(14,(l.r||20)*.9));const x=l.x+Math.cos(a)*d,z=l.z+Math.sin(a)*d;if(isFree(x,z,1)&&!waterAt(x,z))p={x,z}}if(!p)p=freePointNear(l.x,l.z,20);
  const y=terrH(p.x,p.z);const m=new T.Group();m.position.set(p.x,y,p.z);
  const mound=new T.Mesh(new T.SphereGeometry(.9,10,6,0,TAU,0,Math.PI/2),new T.MeshStandardMaterial({color:0x6a5434,roughness:1}));mound.scale.y=.4;m.add(mound);
  const xm=new T.MeshBasicMaterial({color:0xffd34a});for(const r of [.8,-.8]){const bar=new T.Mesh(new T.BoxGeometry(1.6,.04,.18),xm);bar.position.y=.38;bar.rotation.y=r;m.add(bar)}
  const glow=new T.Sprite(new T.SpriteMaterial({map:softTex,color:0xffd34a,transparent:true,blending:T.AdditiveBlending,depthWrite:false,opacity:.8}));glow.scale.set(2.4,2.4,1);glow.position.y=.9;m.add(glow);m.visible=false;addObj(m);
  const cx=p.x+rnd(-14,14),cz=p.z+rnd(-14,14);
  (W.buried||(W.buried=[])).push({treasure:true,pos:new T.Vector3(p.x,y+.3,p.z),m,dug:false,hint:{x:cx,z:cz,r:30},near:l.name});
  banner('讀取藏寶圖',`寶藏埋在「${l.name}」附近 · 打開大地圖（M）看金色圓圈`,3);blip(520,.15,'sine',.06);blip(780,.2,'sine',.06,0,.15)}
function treasures(){return(W.buried||[]).filter(b=>b.treasure&&!b.dug)}
function updateTreasure(){if(M.frame%10)return;for(const b of treasures())b.m.visible=Math.hypot(b.pos.x-P.pos.x,b.pos.z-P.pos.z)<25}
function digTreasure(b){b.dug=true;scene.remove(b.m);const L=DIFFS[M.diff].loot*(PF.lootK||1)*skinLootK();
  const c=makeDropC(b.pos.x,b.pos.y-.3,b.pos.z,'drop',(NET.myId||'me')+':tr'+(dropSeq++));c.grid.name='寶箱';c.grid.items=[];
  const n=3+(Math.random()*2|0);for(let i=0;i<n;i++)giPut(c.grid,mkItem('item',rollValuable(L+1.4)));if(Math.random()<.25*L)giPut(c.grid,mkItem('item',pick(['gem','core','qcpu','ecmo'].filter(k=>ITEMS[k]))));
  emit(b.pos.clone(),26,'dust',4,.9,.09);banner('挖到寶藏了！','',1.8);blip(660,.2,'triangle',.06);blip(990,.3,'triangle',.06,0,.15);M.stats.searched++;openLoot(c)}
// 地圖繪製
function drawTreasureBig(g,S){for(const b of treasures()){const h=b.hint;const [x,y]=toMap(h.x,h.z,S);const r=Math.max(10,h.r/BMV.span*S);g.strokeStyle='#ffd34a';g.lineWidth=3;g.setLineDash([8,6]);g.beginPath();g.arc(x,y,r,0,TAU);g.stroke();g.setLineDash([]);g.fillStyle='#ffd34a';g.fillText('寶藏',x,y-r-8)}}
function drawTreasureMini(mc,K,c){for(const b of treasures()){const near=b.m.visible;const tx=near?b.pos.x:b.hint.x,tz=near?b.pos.z:b.hint.z;let x=(tx-P.pos.x)*K,y=(tz-P.pos.z)*K;const L=Math.hypot(x,y),R=c-12;if(L>R){x*=R/L;y*=R/L}
  mc.strokeStyle='#ffd34a';mc.lineWidth=3;mc.beginPath();if(near){mc.moveTo(x-6,y-6);mc.lineTo(x+6,y+6);mc.moveTo(x+6,y-6);mc.lineTo(x-6,y+6)}else mc.arc(x,y,Math.min(R,b.hint.r*K),0,TAU);mc.stroke()}}
