'use strict';
/* ================= 標點（O 鍵 / 手機「標點」鈕）=================
   - 準心指著地面或建築 → 在那裡放一個黃色標點（最遠 300 m），30 秒後消失；
     再按一次並指著原標點 5 m 內 → 取消標點。
   - 準心指著敵人 → 改成「發現敵人」：該敵人被標記 8 秒，全隊看得到。
   - 同隊 AI 隊友（不在交戰中）會跑到標點附近散開待命，交戰結束後也會繼續前往。
   - 連線時：標點傳給同隊玩家；房主端的 AI 隊友也會照做。
   - 畫面上顯示菱形標記與距離，小地圖、大地圖同步顯示。 */
const PINGS={};// key: 'me' 或玩家 id → {x,y,z,t,team,name,obj,tag}
const PING_LIFE=30;
const _pv=new T.Vector3();

function pingObj(col){const g=new T.Group();
  const beam=new T.Mesh(new T.CylinderGeometry(.07,.07,60,6,1,true),new T.MeshBasicMaterial({color:col,transparent:true,opacity:.45,depthWrite:false,blending:T.AdditiveBlending}));beam.position.y=30;g.add(beam);
  const ring=new T.Mesh(new T.RingGeometry(.9,1.25,28),new T.MeshBasicMaterial({color:col,transparent:true,opacity:.8,side:T.DoubleSide,depthWrite:false}));ring.rotation.x=-Math.PI/2;ring.position.y=.08;g.add(ring);g.userData.ring=ring;
  scene.add(g);return g}
function pingTag(cls){const d=document.createElement('div');d.className='pingTag '+(cls||'');$('hud').appendChild(d);return d}
function clearPing(k){const p=PINGS[k];if(!p)return;scene.remove(p.obj);p.tag.remove();delete PINGS[k]}
function clearAllPings(){for(const k in PINGS)clearPing(k)}

// 放置 / 取消（本機）
function doPing(){if(!M.running||!P||!P.alive||UI.invOpen||UI.mapOpen)return;if(P.bird)camera.updateMatrixWorld();const a=eyeAim();
  // 1) 準心指著敵人 → 發現敵人
  let best=null,bd=1e9;const tryT=(t,isBot)=>{const c=_pv.set(t.pos.x,t.pos.y+1.2,t.pos.z);const v=c.clone().sub(a.e);const L=v.length();if(L>220)return;const ang=Math.acos(clamp(v.dot(a.f)/L,-1,1));if(ang<Math.max(.025,.9/L)&&L<bd&&los(a.e,c)){bd=L;best={t,isBot}}};
  for(const b of bots)if(!b.dead&&hostile(b.team,P.team))tryT(b,true);
  if(typeof netPuppets!=='undefined')for(const k in netPuppets){const q=netPuppets[k];if(q.alive&&hostile(q.team,P.team))tryT(q,false)}
  if(best){if(best.isBot)markBot(best.t,8,true);else markPup(best.t,8,true);flushMarks();note(`發現敵人 · ${Math.round(bd)} m（全隊標記 8 秒）`);blip(1250,.08,'square',.05);blip(1600,.1,'square',.05,0,.09);return}
  // 2) 地面 / 物體位置
  const RNG=P.bird?600:300;if(!rayWorld(a.e,a.f,RNG)){note(`太遠了，標點最遠 ${RNG} m；也可以打開大地圖（M）直接點`);return}
  const p=a.e.clone().addScaledVector(a.f,RH.t);placePing(p.x,p.y,p.z,5,P.bird?'偵察鳥':'')}
// 在世界座標放標點（準心、偵察鳥、大地圖點擊共用）；cancelR 內點到自己的標點＝取消
function placePing(x,y,z,cancelR,src){const old=PINGS.me;if(old&&Math.hypot(old.x-x,old.z-z)<cancelR){clearPing('me');note('已取消標點');blip(500,.08,'sine',.05,-200);if(M.net)netSend({t:'ping',c:1,team:P.team});allyRecall(P.team);return}
  setPing('me',x,y,z,P.team,'你');const d=Math.round(Math.hypot(x-P.pos.x,z-P.pos.z));
  const n=allyGo(PINGS.me);note(`${src?src+' · ':''}已發座標（${d} m）`+(n?` · ${n} 名隊友前往`:M.net?' · 隊友看得到':''));blip(880,.07,'sine',.06);blip(1320,.09,'sine',.05,0,.07);
  if(M.net)netSend({t:'ping',x:+x.toFixed(1),y:+y.toFixed(1),z:+z.toFixed(1),team:P.team,n:PF.nick||'隊友'})}
function mapPing(x,z,cancelR){if(!M.running||!P||!P.alive)return;const WH=(W.world||W.half)-3;x=clamp(x,-WH,WH);z=clamp(z,-WH,WH);placePing(x,terrH(x,z),z,cancelR,'地圖')}

function setPing(k,x,y,z,team,name){clearPing(k);const mine=k==='me';const obj=pingObj(mine?0xffc640:0x6fd0ff);obj.position.set(x,y,z);
  const tag=pingTag(mine?'':'ally');PINGS[k]={x,y,z,t:PING_LIFE,team,name,obj,tag}}

// AI 隊友前往；回傳出發人數（只有單機或房主端控制 AI）
function allyGo(pg){if(M.net&&!M.isHost)return 0;if(MODES[M.mode]&&MODES[M.mode].ffa)return 0;let n=0;
  for(const b of bots){if(b.dead||b.puppet||b.team!==pg.team||b.static)continue;if(!b.goalOff)b.goalOff=new T.Vector3();b.goal={x:pg.x,z:pg.z};b.goalOff.set(rnd(-4,4),0,rnd(-4,4));b.goalT=PING_LIFE;b.pingGo=true;b.path=null;b.pathT=0;n++}return n}
function allyRecall(team){if(M.net&&!M.isHost)return;for(const b of bots)if(b.pingGo&&b.team===team){b.pingGo=false;b.goalT=0}}

// 收到別人的標點
function onPingMsg(m){if(!M.running)return;const k=m.from||'peer';if(m.team!==P.team)return;// 只看同隊
  if(m.c){clearPing(k);allyRecall(m.team);return}
  setPing(k,m.x,m.y,m.z,m.team,m.n||'隊友');allyGo(PINGS[k]);note(`${m.n||'隊友'} 標了一個點`);blip(980,.07,'sine',.05)}

// 每幀：倒數、跳動動畫、畫面上的距離標籤
function updatePings(dt){const w=innerWidth,h=innerHeight;
  for(const k in PINGS){const p=PINGS[k];p.t-=dt;if(p.t<=0){clearPing(k);if(k==='me')allyRecall(P.team);continue}
    const r=p.obj.userData.ring;const s=1+.25*Math.sin(M.t*6);r.scale.set(s,s,s);p.obj.children[0].material.opacity=p.t<5?.45*p.t/5:.45;
    _pv.set(p.x,p.y+2.2,p.z).project(camera);const vis=_pv.z<1&&Math.abs(_pv.x)<1.05&&Math.abs(_pv.y)<1.05&&!UI.mapOpen;
    if(!vis){p.tag.style.display='none';continue}
    const d=Math.round(Math.hypot(p.x-P.pos.x,p.y-P.pos.y,p.z-P.pos.z));p.tag.style.display='';p.tag.style.left=((_pv.x+1)/2*w)+'px';p.tag.style.top=((1-_pv.y)/2*h)+'px';
    const txt=(k==='me'?'':p.name+' · ')+d+' m';if(p.tag._t!==txt){p.tag._t=txt;p.tag.textContent=txt}}}

// 小地圖（已經平移、旋轉過的座標系）
function drawPingsMini(mc,K,c){for(const k in PINGS){const p=PINGS[k];let x=(p.x-P.pos.x)*K,y=(p.z-P.pos.z)*K;const L=Math.hypot(x,y),R=c-10;if(L>R){x*=R/L;y*=R/L}
  mc.fillStyle=k==='me'?'#ffc640':'#6fd0ff';mc.save();mc.translate(x,y);mc.rotate(Math.PI/4);mc.fillRect(-5,-5,10,10);mc.restore()}}
function drawPingsBig(g,S){for(const k in PINGS){const p=PINGS[k];const [x,y]=toMap(p.x,p.z,S);g.fillStyle=k==='me'?'#ffc640':'#6fd0ff';g.save();g.translate(x,y);g.rotate(Math.PI/4);g.fillRect(-8,-8,16,16);g.restore();g.fillText(k==='me'?'標點':p.name,x,y-15)}}
