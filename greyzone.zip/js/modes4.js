'use strict';
/* ================= phase 4: new modes ================= */
Object.assign(MODES,{
  rats:{name:'紅鼠窩',tag:'3v3v3 · 回合',desc:'三支三人小隊在小地圖互相淘汰，最後存活的隊伍拿下回合，先贏 3 回合獲勝。',team:true,custom:true,maps:['warehouse'],pvp:true},
  disaster:{name:'天災倖存',tag:'20 人 · 生存',desc:'地震、隕石、龍捲風、洪水、雷擊、酸雨輪番來襲。每人只有手槍，最後活著的人獲勝。',custom:true,ffa:true,maps:['town','desert','tower','forest'],pvp:true},
  sf:{name:'特種部隊',tag:'攻 20 · 守 10',desc:'20 名匪徒進攻要塞，10 名警察防守。匪徒佔領要塞獲勝；警察撐過 10 分鐘獲勝。',team:true,respawn:true,custom:true,maps:['space','prison','nuclear'],pvp:true},
  nuke:{name:'核彈危機',tag:'10v10 · 任務',desc:'攻方駭入 3 台終端機發射核彈，再躲進避難所；守方無限復活要阻止他們。核彈爆炸時在避難所裡的一方獲勝。',team:true,respawn:true,custom:true,maps:['nuclear','space','dam'],pvp:true},
  bedwars:{name:'床戰',tag:'4 隊 · 守床',desc:'每隊有一張床，床還在就能復活。打開物資箱拿武器，摧毀敵方的床、淘汰全隊，最後的隊伍獲勝。',team:true,respawn:true,custom:true,maps:['warehouse','town'],pvp:true},
  bio:{name:'生化危機',tag:'小隊 · 殭屍 · 頭目',desc:'彈藥醫療有限，斷電警報、封鎖與毒氣擴散。三人小隊互相對抗又要對付殭屍，擊殺反應爐的頭目並成為最後存活的隊伍。',team:true,custom:true,maps:['nuclear'],pvp:true},
});
MODES.conquest.desc='20v20 大戰場：10 個據點，每分鐘依佔領數得分，先到 100 分獲勝。坦克、直升機、飛彈發射器、固定機槍、反車輛地雷。無限復活。';
MODES.conquest.tag='20v20 · 載具';MODES.extract.desc+=' 可選擇敵對小隊數量（6 隊混戰）。';
const TEAMC={1:'#4a8cff',2:'#ff4b3e',3:'#5fd35f',4:'#ffd34a',5:'#c38bff',6:'#62f0e0'};
const TEAMN={1:'藍隊',2:'紅隊',3:'綠隊',4:'黃隊',5:'紫隊',6:'青隊'};
function ringBases(n,r){const out={};for(let t=1;t<=n;t++){const a=(t-1)/n*TAU+.4;let x=Math.cos(a)*r,z=Math.sin(a)*r;const p=freePointNear(x,z,14);out[t]={x:p.x,z:p.z}}return out}
function squad(team,n,kind='soldier',opt={}){const b0=W.basePos[team];const out=[];for(let i=0;i<n;i++){const p=freePointNear(b0.x,b0.z,8);const b=makeBot(kind,team,p.x,0,p.z,Object.assign({wid:opt.wid||botGun()},opt));b.goalOff=new T.Vector3(rnd(-5,5),0,rnd(-5,5));out.push(b)}return out}
function aliveTeams(){const s=new Set();if(P.alive&&!P.downed)s.add(P.team);for(const b of bots)if(!b.dead&&b.team<90)s.add(b.team);for(const k in netPuppets){const p=netPuppets[k];if(p.alive)s.add(p.team)}return s}
function nearestEnemyPos(b){let best=null,bd=1e9;for(const e of hostileEntities(b.team)){const d=e.pos.distanceTo(b.pos);if(d<bd){bd=d;best=e}}return best?{x:best.pos.x,z:best.pos.z}:null}
function goalNear(b,p,r=6){if(!b.goalOff)b.goalOff=new T.Vector3();b.goal={x:p.x,z:p.z};b.goalOff.set(rnd(-r,r),0,rnd(-r,r))}
function setHud(l1,l2){M.hudLbl=[l1,l2];$('cqL1').textContent=l1;$('cqL2').textContent=l2}
function endCustom(wt,line,rw=120000){if(M.ending)return;const win=wt===P.team;finishGeneric({mode:M.mode,kind:!wt?'draw':win?'win':'lose',kills:M.stats.kills,deaths:M.stats.deaths,assists:M.stats.assists,score:M.stats.score,reward:(win?rw:Math.round(rw*.3))+M.stats.kills*3000,scaled:true,line,time:M.t},{t:'cEnd',wt,line,rw})}

const MODE4={
/* ---------- 紅鼠窩 3v3v3 ---------- */
rats:{setup(cfg){W.basePos=ringBases(3,W.half*.62);M.rounds={1:0,2:0,3:0};M.round=0;M.myTeam=cfg.myTeam&&cfg.myTeam<=3?cfg.myTeam:1;setHud('回合','存活隊伍');return{spawn:W.basePos[M.myTeam],lo:FREE_LOADOUT(PF.presets[PF.preset]||PF.loadout)}},
  spawn(){for(const t of [1,2,3])squad(t,Math.max(0,3-humansOnTeam(t))).forEach(b=>b.noRespawn=true);this.newRound(true)},
  newRound(first){M.round++;M.roundOver=false;M.roundT=0;for(const b of bots){const p=freePointNear(W.basePos[b.team].x,W.basePos[b.team].z,6);reviveBot(b,p);b.noRespawn=true}
    if(!first)respawnPlayer(freePointNear(W.basePos[P.team].x,W.basePos[P.team].z,5));banner(`第 ${M.round} 回合`,'淘汰其他兩隊',2);if(M.net&&M.isHost)netSend({t:'banner',a:`第 ${M.round} 回合`,b:''})},
  goal(b){const e=nearestEnemyPos(b);if(e)goalNear(b,e,4);else goalNear(b,{x:0,z:0},10);b.goalT=3},
  onPlayerDied(){return true},
  update(dt){if(!respawning()||M.ending)return;M.hudV=[`${M.rounds[P.team]}`,`${aliveTeams().size}`];if(M.roundOver){M.roundT-=dt;if(M.roundT<=0)this.newRound(false);return}
    const al=aliveTeams();if(al.size<=1){const w=[...al][0]||0;M.roundOver=true;M.roundT=4;if(w){M.rounds[w]++;banner(`${TEAMN[w]}拿下第 ${M.round} 回合`,`${M.rounds[1]} : ${M.rounds[2]} : ${M.rounds[3]}`,3)}
      for(const t of [1,2,3])if(M.rounds[t]>=3){endCustom(t,`${TEAMN[t]}先拿下 3 回合（${M.rounds[1]}:${M.rounds[2]}:${M.rounds[3]}）`,120000);return}}}},

/* ---------- 天災倖存 ---------- */
disaster:{setup(cfg){M.myTeam=cfg.myTeam||300;M.dis={t:12,cur:null,n:0};setHud('存活','災難');return{spawn:ffaSpawn(),lo:{pistol:'g19',helmet:'h0',armor:'a0',rig:'rig1',bag:'bag0',pouch:'pouch1',meds:2}}},
  spawn(){for(let i=0;i<19-(M.net?Object.keys(NET.members).length-1:0);i++){const p=ffaSpawn();const b=makeBot('gunman',400+i,p.x,0,p.z,{wid:pick(['g19','f92','m9'])});b.noRespawn=true;b.goalOff=new T.Vector3()}},
  goal(b){const d=M.dis.cur;if(d==='flood'||d==='acid'){const r=W.roofSpots.filter(s=>s.roof||s.indoor).sort((a,c)=>Math.hypot(a.x-b.pos.x,a.z-b.pos.z)-Math.hypot(c.x-b.pos.x,c.z-b.pos.z))[0];if(r){goalNear(b,r,2);b.goalT=6;return}}
    if(Math.random()<.4){const e=nearestEnemyPos(b);if(e){goalNear(b,e,6);b.goalT=5;return}}goalNear(b,{x:rnd(-W.half*.6,W.half*.6),z:rnd(-W.half*.6,W.half*.6)},4);b.goalT=8},
  onPlayerDied(){return true},
  update(dt){if(M.ending)return;const D=M.dis;const alive=(P.alive?1:0)+bots.filter(b=>!b.dead).length+Object.values(netPuppets).filter(p=>p.alive).length;M.hudV=[String(alive),D.cur?DIS_NAME[D.cur]:Math.ceil(D.t)+'s'];
    if(respawning()){D.t-=dt;if(D.t<=0){if(D.cur){disCleanup();D.cur=null;D.t=8;banner('災難暫歇','準備下一波',1.6)}else{D.n++;D.cur=pick(Object.keys(DIS_NAME));D.t=14+Math.min(10,D.n);D.tick=0;D.data={};banner(DIS_NAME[D.cur],DIS_HINT[D.cur],2.4);if(M.net&&M.isHost)netSend({t:'dis',k:D.cur,s:(Math.random()*1e9)|0})}}}
    if(D.cur)disasterTick(D,dt);
    if(respawning()&&alive<=1){const wb=bots.find(b=>!b.dead);const wp=Object.values(netPuppets).find(p=>p.alive);const wt=P.alive?P.team:wb?wb.team:wp?wp.team:0;const nm=P.alive?(PF.nick||'你'):wb?wb.name:wp?wp.nick:'無人';endCustom(wt,`最後倖存者：${nm}`,150000)}}},

/* ---------- 特種部隊 ---------- */
sf:{setup(cfg){const h=W.holdPos;M.fort={x:h.x,z:h.z,r:12,prog:0};W.basePos={1:freePointNear(-W.half*.75,-W.half*.6,12),2:freePointNear(h.x,h.z,10)};M.myTeam=cfg.myTeam||1;M.sfLeft=600;
    const ring=new T.Mesh(new T.RingGeometry(11.6,12,48),new T.MeshBasicMaterial({color:0xffb547,transparent:true,opacity:.6,side:T.DoubleSide,depthWrite:false}));ring.rotation.x=-Math.PI/2;ring.position.set(h.x,.06,h.z);addObj(ring);
    setHud('佔領進度','剩餘時間');return{spawn:W.basePos[M.myTeam],lo:FREE_LOADOUT(PF.presets[PF.preset]||PF.loadout)}},
  spawn(cfg){const s=COUNT[cfg.count||'mid'].c/10;squad(1,Math.round(20*s)-humansOnTeam(1),'gunman');squad(2,Math.round(10*s)-humansOnTeam(2),'heavy',{}).forEach(b=>{b.defend=true})},
  goal(b){if(b.team===2){goalNear(b,M.fort,9);b.goalT=6}else{goalNear(b,M.fort,7);b.goalT=5}},
  update(dt){botRespawnTick(dt);if(!respawning()||M.ending)return;M.sfLeft-=dt;const f=M.fort;let a=0,d=0;const inF=p=>Math.hypot(p.x-f.x,p.z-f.z)<f.r;
    if(P.alive&&inF(P.pos))P.team===1?a++:d++;for(const b of bots)if(!b.dead&&inF(b.pos))b.team===1?a++:d++;for(const k in netPuppets){const p=netPuppets[k];if(p.alive&&inF(p.pos))p.team===1?a++:d++}
    if(a>0&&d===0)f.prog=Math.min(100,f.prog+dt*2.5);else if(d>a)f.prog=Math.max(0,f.prog-dt*1.5);M.hudV=[Math.round(f.prog)+'%',clock(Math.max(0,M.sfLeft))];
    if(f.prog>=100)endCustom(1,'匪徒攻下要塞',110000);else if(M.sfLeft<=0)endCustom(2,'警察守住要塞 10 分鐘',110000)}},

/* ---------- 核彈危機 ---------- */
nuke:{setup(cfg){M.myTeam=cfg.myTeam||1;const h=W.half;W.basePos={1:freePointNear(-h*.75,-h*.75,12),2:freePointNear(h*.2,h*.2,12)};
    W.terms=[];const tp=[[-h*.3,h*.1],[h*.1,-h*.35],[h*.4,h*.4]];tp.forEach(([x,z],i)=>{const p=freePointNear(x,z,10);const t={kind:'hack',x:p.x,z:p.z,need:8,label:`駭入終端機 ${'ABC'[i]}`,nuke:true};W.terms.push(t);dbox(p.x,p.z+.5,1.2,.5,1.3,'metal',0);
      const m=new T.Mesh(new T.BoxGeometry(.9,.6,.05),new T.MeshBasicMaterial({color:0xff4b3e}));m.position.set(p.x,1.3,p.z+.22);addObj(m);t.screen=m;landmark('終端機 '+'ABC'[i],p.x,p.z,6)});
    const sp=freePointNear(h*.7,-h*.6,10);M.shelter={x:sp.x,z:sp.z,r:7};dbox(sp.x,sp.z,16,16,.3,'metal',3.2);for(const [dx,dz,w,d] of [[0,-8,16,.4],[-8,0,.4,16],[8,0,.4,16]])dbox(sp.x+dx,sp.z+dz,w,d,3.2,'dark',0);landmark('避難所',sp.x,sp.z,8);
    M.lives=3;M.nukeT=-1;setHud('終端機','核彈');return{spawn:W.basePos[M.myTeam],lo:FREE_LOADOUT(PF.presets[PF.preset]||PF.loadout)}},
  spawn(cfg){const n=Math.round(10*COUNT[cfg.count||'mid'].c/10);squad(1,n-humansOnTeam(1)).forEach(b=>b.lives=2);squad(2,n-humansOnTeam(2))},
  goal(b){const open=W.terms.filter(t=>!t.done);if(b.team===1){if(M.nukeT>=0){goalNear(b,M.shelter,3)}else if(open.length)goalNear(b,open[b.id%open.length],2);b.goalT=4}else{const tgt=M.nukeT>=0?M.shelter:open.length?open[b.id%open.length]:M.shelter;goalNear(b,tgt,8);b.goalT=5}},
  onPlayerDied(){if(P.team===1){M.lives--;if(M.lives<=0){note('你的生命已用完');return true}}return false},
  canRespawn(b){if(b.team===1){b.lives=(b.lives||2)-1;return b.lives>0}return true},
  update(dt){botRespawnTick(dt);const done=W.terms.filter(t=>t.done).length;M.hudV=[`${done}/3`,M.nukeT>=0?Math.ceil(M.nukeT)+'s':'待命'];
    for(const t of W.terms)if(t.screen)t.screen.material.color.setHex(t.done?0x30ff60:0xff4b3e);
    if(!respawning()||M.ending)return;
    // bots hack terminals by standing on them
    for(const t of W.terms)if(!t.done){const hk=bots.some(b=>!b.dead&&b.team===1&&Math.hypot(b.pos.x-t.x,b.pos.z-t.z)<2.5);if(hk){t.bp=(t.bp||0)+dt;if(t.bp>12)termDone(t,true)}}
    if(done===3&&M.nukeT<0){M.nukeT=60;banner('核彈已發射','60 秒後爆炸，攻方快進避難所！',3);if(M.net)netSend({t:'banner',a:'核彈已發射',b:'60 秒後爆炸'});for(const b of bots)b.goalT=0}
    if(M.nukeT>=0){M.nukeT-=dt;if(M.nukeT<=0)nukeBoom()}
    const atk=(P.team===1&&(P.alive||M.lives>0)?1:0)+bots.filter(b=>b.team===1&&(!b.dead||(b.lives||0)>0)).length+Object.values(netPuppets).filter(p=>p.team===1&&p.alive).length;
    if(atk===0&&M.nukeT>-2)endCustom(2,'攻方全滅，核彈被阻止',110000)}},

/* ---------- 床戰 ---------- */
bedwars:{setup(cfg){W.basePos=ringBases(4,W.half*.68);M.myTeam=cfg.myTeam&&cfg.myTeam<=4?cfg.myTeam:1;M.beds={};
    for(const t of [1,2,3,4]){const b=W.basePos[t];const g=new T.Group();const frame=new T.Mesh(new T.BoxGeometry(1.4,.5,2.2),new T.MeshStandardMaterial({color:0x5a3a22}));frame.position.y=.25;g.add(frame);
      const sheet=new T.Mesh(new T.BoxGeometry(1.3,.2,2),new T.MeshStandardMaterial({color:new T.Color(TEAMC[t])}));sheet.position.y=.6;g.add(sheet);const pil=new T.Mesh(new T.BoxGeometry(1.1,.18,.4),new T.MeshStandardMaterial({color:0xeeeeee}));pil.position.set(0,.78,-.7);g.add(pil);
      g.position.set(b.x,0,b.z);addObj(g);const box={minX:b.x-.7,maxX:b.x+.7,minZ:b.z-1.1,maxZ:b.z+1.1,minY:0,maxY:.9,solid:true,shoot:true,kind:'bed',bedTeam:t};W.boxes.push(box);gridAdd(box);M.beds[t]={hp:400,alive:true,g,box,x:b.x,z:b.z}}
    M.itemBoxes=[];for(let i=0;i<12;i++){const p=freePointNear(rnd(-W.half*.5,W.half*.5),rnd(-W.half*.5,W.half*.5),20);const c=lootBox(p.x,p.z,'weapon');if(c){c.bedItem=true;M.itemBoxes.push(c)}}
    setHud('我方床','剩餘隊伍');return{spawn:W.basePos[M.myTeam],lo:{p1:null,p2:null,pistol:'g19',helmet:'h1',armor:'a1',rig:'rig1',bag:'bag0',pouch:'pouch2',meds:1}}},
  spawn(){for(const t of [1,2,3,4])squad(t,Math.max(0,3-humansOnTeam(t)),'soldier',{wid:pick(['mp5','t65k2','m870','uzi'])})},
  goal(b){const enemyBeds=Object.entries(M.beds).filter(([t,bd])=>+t!==b.team&&bd.alive);if(enemyBeds.length&&Math.random()<.6){const [,bd]=enemyBeds.sort((a,c)=>Math.hypot(a[1].x-b.pos.x,a[1].z-b.pos.z)-Math.hypot(c[1].x-b.pos.x,c[1].z-b.pos.z))[0];goalNear(b,bd,2);b.goalT=6;b.bedTgt=bd}
    else{const e=nearestEnemyPos(b);if(e)goalNear(b,e,5);b.goalT=5;b.bedTgt=null}},
  onPlayerDied(){if(M.beds[P.team]&&M.beds[P.team].alive)return false;note('你的床已被摧毀，無法復活');return true},
  canRespawn(b){return M.beds[b.team]&&M.beds[b.team].alive},
  update(dt){botRespawnTick(dt);const al=aliveTeams();for(const t in M.beds){const bd=M.beds[t];if(bd.alive&&!bd.box.off)al.add(+t)}
    M.hudV=[M.beds[P.team].alive?'完好':'已毀',String(new Set([...Object.keys(M.beds).filter(t=>M.beds[t].alive).map(Number),...aliveTeams()]).size)];
    if(!respawning()||M.ending)return;
    for(const b of bots)if(!b.dead&&b.bedTgt&&b.bedTgt.alive&&Math.hypot(b.pos.x-b.bedTgt.x,b.pos.z-b.bedTgt.z)<2.2)bedDamage(b.bedTgt,40*dt,b.team);
    for(const c of M.itemBoxes)if(c.searched||c.grid&&!c.grid.items.length){c.reT=(c.reT||25)-dt;if(c.reT<=0){c.reT=25;c.searched=false;c.items=null;c.grid=null;setStrip(c,0x9ad06a)}}
    const teams=new Set([...Object.keys(M.beds).filter(t=>M.beds[t].alive).map(Number),...aliveTeams()]);if(teams.size<=1){const w=[...teams][0]||0;endCustom(w,(w?TEAMN[w]:'無人')+'是最後的隊伍',130000)}}},

/* ---------- 生化危機 ---------- */
bio:{setup(cfg){W.basePos=ringBases(6,W.half*.78);M.myTeam=1;M.bio={outT:40,dark:false,lockT:60,gasT:50,bossDead:false};setHud('存活小隊','頭目');
    return{spawn:W.basePos[1],lo:Object.assign(FREE_LOADOUT(PF.presets[PF.preset]||PF.loadout),{pouch:'pouch0',meds:1})}},
  spawn(cfg){for(let t=1;t<=6;t++)squad(t,Math.max(0,3-humansOnTeam(t))).forEach(b=>b.noRespawn=true);const n=Math.round(30*COUNT[cfg.count||'mid'].x/20);for(let i=0;i<n;i++){const p=freePointNear(rnd(-W.half*.8,W.half*.8),rnd(-W.half*.8,W.half*.8),20);const z=makeBot('zombie',99,p.x,0,p.z);z.noRespawn=true}
    const bs=W.bossSpot||{x:0,z:0};const boss=makeBot('zbrute',99,bs.x,bs.y||0,bs.z);boss.maxHp=boss.hp=2500;boss.isBioBoss=true;boss.noRespawn=true;for(const k in P.ammo)P.ammo[k]=Math.round(P.ammoCap[k]*.5)},
  goal(b){if(Math.random()<.5){const e=nearestEnemyPos(b);if(e){goalNear(b,e,6);b.goalT=6;return}}goalNear(b,W.bossSpot||{x:0,z:0},20);b.goalT=8},
  onPlayerDied(){return true},
  onKill(b){if(b.isBioBoss){M.bio.bossDead=true;banner('反應爐頭目已被擊殺','',2.4)}},
  update(dt){const B=M.bio;const teams=new Set([...aliveTeams()].filter(t=>t<=6));M.hudV=[String(teams.size),B.bossDead?'已擊殺':'存活'];
    if(respawning()&&!M.ending){B.outT-=dt;if(B.outT<=0){B.dark=!B.dark;B.outT=B.dark?20:45;banner(B.dark?'全區斷電':'電力恢復',B.dark?'警報響起，殭屍被吸引':'',1.8);if(B.dark){triggerAlarm&&triggerAlarm(P.pos)}if(M.net)netSend({t:'bioDark',d:B.dark})}
      B.lockT-=dt;if(B.lockT<=0){B.lockT=60;for(const d of W.doors)if(Math.random()<.35&&!d.locked){if(d.open)toggleDoor(d,true);d.locked='ice';d.iceT=25}banner('區域封鎖','部分門被鎖死 25 秒',1.6)}
      B.gasT-=dt;if(B.gasT<=0){B.gasT=50;const x=rnd(-W.half*.6,W.half*.6),z=rnd(-W.half*.6,W.half*.6);gasZone(x,z,10);banner('毒氣擴散','小地圖上避開綠色區域',1.6)}
      if(teams.size<=1&&B.bossDead){const w=[...teams][0]||0;endCustom(w,w===P.team?'你的小隊存活並擊殺了頭目':`${TEAMN[w]||'其他小隊'}存活到最後`,160000)}
      else if(teams.size===0)endCustom(0,'所有小隊都被消滅',60000)}
    if(B.dark!==B._dk){B._dk=B.dark;W.glows.forEach(g=>g.visible=!B.dark);M.forceNight=B.dark}}},
};
/* ---------- disasters ---------- */
const DIS_NAME={quake:'地震',meteor:'隕石雨',tornado:'龍捲風',flood:'洪水',lightning:'雷暴',acid:'酸雨',fire:'野火'};
const DIS_HINT={quake:'遠離建築物，小心落石',meteor:'注意地上的紅圈',tornado:'遠離旋風',flood:'快爬到高處',lightning:'不要站在空曠處',acid:'躲進室內',fire:'火會蔓延，快離開'};
function disHitAll(fn){if(P.alive)fn({me:true,pos:P.pos});if(respawning())for(const b of bots)if(!b.dead)fn({b,pos:b.pos})}
function disDmg(t,d,how){if(t.me)damagePlayer(d,null,{gas:true,how});else damageBot(t.b,d,'body',{how},null)}
function disasterTick(D,dt){D.tick-=dt;const k=D.cur,dd=D.data;
  switch(k){
  case 'quake':P.shake=Math.max(P.shake,.6);if(D.tick<=0){D.tick=.35;disHitAll(t=>{if(Math.random()<.12){const p=t.pos;const x=p.x+rnd(-3,3),z=p.z+rnd(-3,3);fireball(new T.Vector3(x,.5,z),.6);emit(new T.Vector3(x,1,z),12,'dust',4,.8,.08);if(Math.hypot(x-p.x,z-p.z)<1.6)disDmg(t,22,'落石')}})}break;
  case 'meteor':if(!dd.list)dd.list=[];if(D.tick<=0&&respawning()){D.tick=.7;const tg=Math.random()<.5&&P.alive?P.pos:(pick(bots.filter(b=>!b.dead))||{pos:P.pos}).pos;const x=tg.x+rnd(-8,8),z=tg.z+rnd(-8,8);dd.list.push({x,z,t:1.6,m:ringMark(x,z,4,0xff4b3e)});if(M.net)netSend({t:'disM',x,z})}
    for(let i=dd.list.length-1;i>=0;i--){const m=dd.list[i];m.t-=dt;if(m.t<=0){scene.remove(m.m);dd.list.splice(i,1);const p=new T.Vector3(m.x,.4,m.z);fireball(p,2.4);boomSnd(.5,0);disHitAll(t=>{const d=Math.hypot(t.pos.x-m.x,t.pos.z-m.z);if(d<4.5)disDmg(t,90*(1-d/5),'隕石')})}}break;
  case 'tornado':{if(!dd.p){dd.p=new T.Vector3(rnd(-W.half*.5,W.half*.5),0,rnd(-W.half*.5,W.half*.5));dd.v=new T.Vector3()}const tgt=P.alive?P.pos:dd.p;dd.v.lerp(new T.Vector3(tgt.x-dd.p.x,0,tgt.z-dd.p.z).normalize().multiplyScalar(5),dt*.5);dd.p.addScaledVector(dd.v,dt);
    for(let i=0;i<6;i++){const a=Math.random()*TAU,r=Math.random()*5;puff({x:dd.p.x+Math.cos(a)*r,y:Math.random()*14,z:dd.p.z+Math.sin(a)*r},1,3,1.2,0x7a7468,.6,.3,.8)}
    disHitAll(t=>{const dx=dd.p.x-t.pos.x,dz=dd.p.z-t.pos.z,d=Math.hypot(dx,dz);if(d<14){const f=(14-d)/14;if(t.me){P.vel.x+=dx/d*f*20*dt;P.vel.z+=dz/d*f*20*dt}else{moveCircle(t.b.pos,dx/d*f*4*dt,dz/d*f*4*dt,.4,t.b.pos.y,t.b.pos.y+1.8)}if(d<5&&D.tick<=0)disDmg(t,12,'龍捲風')}});if(D.tick<=0)D.tick=.5;break}
  case 'flood':{dd.h=Math.min(2.6,(dd.h||0)+dt*.25);if(!dd.m){dd.m=new T.Mesh(new T.PlaneGeometry(W.half*2,W.half*2),new T.MeshStandardMaterial({color:0x3a6a7a,transparent:true,opacity:.7,depthWrite:false}));dd.m.rotation.x=-Math.PI/2;addObj(dd.m);D.cleanup=()=>{scene.remove(dd.m)}}dd.m.position.y=dd.h;
    if(D.tick<=0){D.tick=1;disHitAll(t=>{if(t.pos.y<dd.h-.4)disDmg(t,9,'洪水')})}break}
  case 'lightning':if(D.tick<=0){D.tick=.9;disHitAll(t=>{if(Math.random()<.18&&!ceilingHit(t.pos.x,t.pos.z,.3,t.pos.y,t.pos.y+30)){const p=t.pos;tracer(new T.Vector3(p.x+rnd(-2,2),60,p.z+rnd(-2,2)),new T.Vector3(p.x,0,p.z),0xdde6ff,.15);W.flashT=.12;boomSnd(.4,0);disDmg(t,35,'雷擊')}})}break;
  case 'acid':if(D.tick<=0){D.tick=1;disHitAll(t=>{if(!ceilingHit(t.pos.x,t.pos.z,.3,t.pos.y,t.pos.y+30))disDmg(t,7,'酸雨')})}if(Math.random()<dt*30)emit(new T.Vector3(camera.position.x+rnd(-10,10),camera.position.y+8,camera.position.z+rnd(-10,10)),1,'acid',1,.6,.05,-12);break;
  case 'fire':{if(!dd.z){dd.z=[];D.cleanup=null}if(D.tick<=0&&respawning()){D.tick=1.2;const src=dd.z.length&&Math.random()<.7?pick(dd.z):{x:rnd(-W.half*.6,W.half*.6),z:rnd(-W.half*.6,W.half*.6)};const x=src.x+rnd(-6,6),z=src.z+rnd(-6,6);dd.z.push({x,z});zoneAt(new T.Vector3(x,0,z),'fire',4,20,{dps:18,how:'野火'})}break}}}
function disCleanup(){const D=M.dis;if(D&&D.cleanup){D.cleanup();D.cleanup=null}}
function ringMark(x,z,r,col){const m=new T.Mesh(new T.RingGeometry(r-.3,r,32),new T.MeshBasicMaterial({color:col,transparent:true,opacity:.8,side:T.DoubleSide,depthWrite:false}));m.rotation.x=-Math.PI/2;m.position.set(x,.08,z);scene.add(m);return m}
function nukeBoom(){M.nukeT=-2;W.flashT=1.5;$('blind').style.opacity=1;setTimeout(()=>$('blind').style.opacity=0,1200);boomSnd(1,0);P.shake=3;const sh=M.shelter;const inS=p=>Math.hypot(p.x-sh.x,p.z-sh.z)<sh.r+1;
  const atkSafe=(P.team===1&&P.alive&&inS(P.pos))||bots.some(b=>!b.dead&&b.team===1&&inS(b.pos))||Object.values(netPuppets).some(p=>p.alive&&p.team===1&&inS(p.pos));
  if(P.alive&&!inS(P.pos))damagePlayer(999,null,{gas:true,how:'核爆'});for(const b of bots)if(!b.dead&&!inS(b.pos))damageBot(b,9999,'body',{how:'核爆'},null);
  setTimeout(()=>endCustom(atkSafe?1:2,atkSafe?'核彈爆炸，攻方在避難所存活':'核彈爆炸，攻方沒有人進入避難所',140000),1800)}
function bedDamage(bd,d,byTeam){if(!bd.alive)return;bd.hp-=d;emit(new T.Vector3(bd.x,.8,bd.z),2,'dust',2,.4,.04);if(bd.hp<=0){bd.alive=false;bd.box.off=true;bd.g.visible=false;const t=+Object.keys(M.beds).find(k=>M.beds[k]===bd);
  banner(`${TEAMN[t]}的床被摧毀了`,t===P.team?'你們無法再復活！':'',2.4);boomSnd(.5,0);if(M.net&&M.isHost)netSend({t:'bed',tm:t})}}
function onCustomMsg(m){if(m.t==='bed'&&M.beds&&M.beds[m.tm]&&M.beds[m.tm].alive)bedDamage(M.beds[m.tm],9999,0);if(m.t==='bedHit'&&M.isHost&&M.beds&&M.beds[m.tm])bedDamage(M.beds[m.tm],m.d,0);
  if(m.t==='dis'&&M.dis){M.dis.cur=m.k;M.dis.t=16;M.dis.data={};M.dis.tick=0;banner(DIS_NAME[m.k],DIS_HINT[m.k],2.4)}
  if(m.t==='disM'&&M.dis&&M.dis.data){(M.dis.data.list||(M.dis.data.list=[])).push({x:m.x,z:m.z,t:1.6,m:ringMark(m.x,m.z,4,0xff4b3e)})}
  if(m.t==='bioDark'&&M.bio){M.bio.dark=m.d}
  if(m.t==='cEnd'&&!M.isHost){endCustom(m.wt,m.line,m.rw)}}

/* ================= 全面戰場: vehicles, launchers, mounted MGs, AT mines ================= */
function tankMesh(col){const g=new T.Group();const m=new T.MeshStandardMaterial({color:col,roughness:.7,metalness:.35}),dk=new T.MeshStandardMaterial({color:0x1a1a18,roughness:.8});
  const B=(w,h,d,mt,x,y,z,par=g)=>{const q=new T.Mesh(new T.BoxGeometry(w,h,d),mt);q.position.set(x,y,z);q.castShadow=true;par.add(q);return q};
  B(3.2,1,6,m,0,.95,0);B(.7,.9,6.4,dk,-1.7,.55,0);B(.7,.9,6.4,dk,1.7,.55,0);const tur=new T.Group();tur.position.set(0,1.75,-.2);g.add(tur);B(2.2,.8,2.6,m,0,0,0,tur);
  const br=new T.Mesh(new T.CylinderGeometry(.13,.15,3.6,10).rotateX(Math.PI/2),dk);br.position.set(0,.05,2.9);tur.add(br);B(.5,.3,.6,dk,.7,.55,-.4,tur);g.userData.tur=tur;g.userData.wheels=[];return g}
function spawnVehicle(kind,x,z,yaw,team){const p=freePointNear(x,z,10);x=p.x;z=p.z;const id=(W.cars||(W.cars=[])).length;let g;
  if(kind==='tank')g=tankMesh(team===1?0x4a5a3a:0x5a4a3a);else{g=heliModel();scene.remove(g);g.userData.wheels=[]}g.position.set(x,terrH(x,z)+(kind==='heli'?.9:0),z);g.rotation.y=yaw;addObj(g);
  const c={id,g,pos:g.position,yaw,spd:0,hp:kind==='tank'?1600:900,maxHp:kind==='tank'?1600:900,name:kind==='tank'?'主戰坦克':'武裝直升機',driver:null,net:null,dead:false,kind,team,cd:0,vy:0};W.cars.push(c);landmark(kind==='tank'?'坦克':'直升機',x,z,4);return c}
function setupWarfare(){const B=W.basePos;W.launchers=[];W.mgs=[];W.atMines=[];
  for(const t of [1,2]){const b=B[t];const ax=-b.x,az=-b.z,L=Math.hypot(ax,az)||1;const yaw=Math.atan2(ax/L,az/L);
    spawnVehicle('tank',b.x+az/L*10,b.z-ax/L*10,yaw,t);spawnVehicle('tank',b.x-az/L*10,b.z+ax/L*10,yaw,t);spawnVehicle('heli',b.x-ax/L*12,b.z-az/L*12,yaw,t);
    const lp=freePointNear(b.x+ax/L*6,b.z+az/L*6,6);dbox(lp.x,lp.z,1.6,1.6,1.4,'metal',0);{const tb=new T.Mesh(new T.BoxGeometry(1.2,.6,2.2),new T.MeshStandardMaterial({color:0x4a5a3a,metalness:.4}));tb.position.set(lp.x,1.7,lp.z);tb.rotation.x=-.5;addObj(tb)}landmark('飛彈發射器',lp.x,lp.z,4);W.launchers.push({pos:new T.Vector3(lp.x,1,lp.z),team:t,cd:0})}
  for(const f of W.flags.slice(0,6)){const p=freePointNear(f.x+4,f.z+4,4);dbox(p.x,p.z,.5,.5,1,'metal',0);const g=new T.Group();g.position.set(p.x,1.1,p.z);const gun=new T.Mesh(new T.BoxGeometry(.18,.18,1.3),new T.MeshStandardMaterial({color:0x2a2a28,metalness:.6}));gun.position.z=.4;g.add(gun);addObj(g);W.mgs.push({pos:new T.Vector3(p.x,1,p.z),g,heat:0,user:null})}
  for(let i=0;i<8;i++){const f=pick(W.flags);const p=freePointNear(f.x+rnd(-20,20),f.z+rnd(-20,20),6);const m=new T.Mesh(new T.CylinderGeometry(.35,.38,.12,10),new T.MeshStandardMaterial({color:0x3a3a30}));m.position.set(p.x,.06,p.z);addObj(m);W.atMines.push({x:p.x,z:p.z,m,dead:false})}}
function extraFlags(){const lab='ABCDEFGHIJ';const pts=W.flagsPos.map(f=>[f[0],f[1]]);const cand=(W.landmarks||[]).filter(l=>l.name!=='車庫').map(l=>[l.x,l.z]);for(let i=0;i<200&&pts.length<10;i++){const c=cand.length&&i<60?cand[(i*7)%cand.length]:[rnd(-W.half*.75,W.half*.75),rnd(-W.half*.75,W.half*.75)];if(pts.every(p=>Math.hypot(p[0]-c[0],p[1]-c[1])>38)){const f=freePointNear(c[0],c[1],6);pts.push([f.x,f.z])}}
  return pts.slice(0,10).map((p,i)=>[p[0],p[1],lab[i]])}
// vehicle driving extensions (called from updateCar)
function updateArmor(c,dt){const st=(keys.KeyA?1:0)-(keys.KeyD?1:0);let th=(keys.KeyW?1:0)-(keys.KeyS?1:0);if(touchS.stickId!==null){th=-touchS.jy;}
  if(c.kind==='tank'){c.spd+=th*6*dt;c.spd=clamp(c.spd,-4,9);if(!th)c.spd*=1-dt*1.5;c.yaw+=st*dt*.9;const fx=Math.sin(c.yaw),fz=Math.cos(c.yaw);moveCircle(c.pos,fx*c.spd*dt,fz*c.spd*dt,2,c.pos.y,c.pos.y+2.5);c.pos.y=groundAt(c.pos.x,c.pos.z,1.6,c.pos.y+.8);c.g.rotation.y=c.yaw;
    const tur=c.g.userData.tur;tur.rotation.y=angDiff(P.yaw+Math.PI,c.yaw);c.cd-=dt;if(mouse.lPressed&&c.cd<=0){mouse.lPressed=false;c.cd=2.6;camera.updateMatrixWorld();camFwd(_f);const dir=_f.clone();const o=c.pos.clone().add(new T.Vector3(0,2,0)).addScaledVector(dir,4.5);
      lobFrom('frag',o,dir.multiplyScalar(80),{impact:true,grav:2,fuse:3,boom:p=>boomAt(p,5.5,280,'坦克砲')});boomSnd(.6,0);P.shake=.8;emit(o,14,'fire',6,.4,.08)}
    for(const b of bots)if(!b.dead&&hostile(P.team,b.team)&&Math.abs(c.spd)>3&&Math.hypot(b.pos.x-c.pos.x,b.pos.z-c.pos.z)<2.6)damageBot(b,200,'body',{player:true,pos:P.pos,how:'坦克輾壓'},null)}
  else{const hy=(keys.Space?1:0)-(keys.KeyC?1:0);const sy=Math.sin(P.yaw),cy=Math.cos(P.yaw);let mx=-sy*th+cy*(-st),mz=-cy*th-sy*(-st);if(touchS.stickId!==null){mx=-sy*(-touchS.jy)+cy*touchS.jx;mz=-cy*(-touchS.jy)-sy*touchS.jx}
    c.vel=c.vel||new T.Vector3();c.vel.x+=(mx*22-c.vel.x)*dt*1.5;c.vel.z+=(mz*22-c.vel.z)*dt*1.5;c.vy+=(hy*8-c.vy)*dt*2;moveCircle(c.pos,c.vel.x*dt,c.vel.z*dt,2.5,c.pos.y,c.pos.y+2.5);c.pos.y=clamp(c.pos.y+c.vy*dt,groundAt(c.pos.x,c.pos.z,2,c.pos.y+.5)+.9,70);
    c.yaw+=angDiff(P.yaw+Math.PI,c.yaw)*Math.min(1,dt*3);c.g.rotation.set(-c.vel.dot(new T.Vector3(-sy,0,-cy))*.012*0,c.yaw,0);for(const r of c.g.userData.rot||[])r.rotation.y+=dt*30;c.spd=Math.hypot(c.vel.x,c.vel.z);
    c.cd-=dt;if(mouse.l&&c.cd<=0){c.cd=.075;camera.updateMatrixWorld();camFwd(_f);const a=camera.position.clone(),d=_f.clone().add(new T.Vector3(rnd(-.02,.02),rnd(-.02,.02),rnd(-.02,.02))).normalize();const h=rayActors(a,d,180,P.team);const wall=rayWorld(a,d,180)?RH.t:180;const end=a.clone().addScaledVector(d,Math.min(wall,h?h.t:180));
      tracer(c.pos.clone().add(new T.Vector3(0,-.6,0)),end,0xffd890,.03);gunSnd(.18,900,.08,0);if(h&&h.t<wall)skHit(h.isBot?{b:h.ent,pos:h.ent.pos}:{p:h.ent,pos:h.ent.pos},{dmg:22,how:'直升機機砲'},c.pos);else emit(end,3,'dust',2,.3,.05)}}
  P.pos.set(c.pos.x,c.pos.y+.4,c.pos.z);P.vel.set(0,0,0);P.speed=c.spd;
  for(const mn of W.atMines||[])if(!mn.dead&&c.kind!=='heli'&&Math.hypot(mn.x-c.pos.x,mn.z-c.pos.z)<2.4){mn.dead=true;scene.remove(mn.m);boomAt(new T.Vector3(mn.x,.3,mn.z),5,150,'反車輛地雷');carDamage(c,700)}}
function armorCam(c){const fx=-Math.sin(P.yaw)*Math.cos(P.pitch),fy=Math.sin(P.pitch),fz=-Math.cos(P.yaw)*Math.cos(P.pitch);const d=c.kind==='heli'?13:10;camera.position.set(c.pos.x-fx*d,c.pos.y+(c.kind==='heli'?3:4.2)-fy*d,c.pos.z-fz*d);camera.rotation.set(P.pitch,P.yaw,0);camera.updateMatrixWorld()}
// launchers & MGs
function useLauncher(l){if(l.cd>0){note(`飛彈發射器冷卻中 ${Math.ceil(l.cd)} 秒`);return}l.cd=40;const pp=P.pitch;P.mslFrom=l.pos.clone().add(new T.Vector3(0,3.5,0));P.pitch=1.2;try{SK['bastion.s3']()}finally{P.mslFrom=null}P.mslPitch=pp;note('飛彈發射：滑鼠導引，左鍵引爆')}
function mountMG(g){if(g.user)return;g.user='me';P.mg=g;note('固定機槍：左鍵射擊，F 離開（會過熱）')}
function updateMG(dt){const g=P.mg;if(!g)return false;P.pos.set(g.pos.x,0,g.pos.z+(-.9));P.vel.set(0,0,0);g.g.rotation.y=P.yaw+Math.PI;g.heat=Math.max(0,g.heat-dt*25);
  if(mouse.l&&g.heat<100&&(g.cd=(g.cd||0)-dt)<=0){g.cd=.085;g.heat+=6;camera.updateMatrixWorld();camFwd(_f);const a=camera.position.clone(),d=_f.clone().add(new T.Vector3(rnd(-.012,.012),rnd(-.012,.012),rnd(-.012,.012))).normalize();const h=rayActors(a,d,200,P.team);const wall=rayWorld(a,d,200)?RH.t:200;const end=a.clone().addScaledVector(d,Math.min(wall,h?h.t:200));
    tracer(g.pos.clone().add(new T.Vector3(0,.2,0)),end,0xffd890,.03);gunSnd(.25,700,.08,0);P.kick+=.006;if(h&&h.t<wall)skHit(h.isBot?{b:h.ent,pos:h.ent.pos}:{p:h.ent,pos:h.ent.pos},{dmg:30,how:'固定機槍'},g.pos);else emit(end,3,'dust',2,.3,.05)}
  if(g.heat>=100&&!g.oh){g.oh=true;note('機槍過熱！')}if(g.heat<40)g.oh=false;return true}
function leaveMG(){if(P.mg){P.mg.user=null;P.mg=null}}
function updateWarfare(dt){for(const l of W.launchers||[])if(l.cd>0)l.cd-=dt}
