'use strict';
/* ================= humanoid rig (segmented, procedurally animated) =================
   Faces +Z. Root origin at the feet. Bones: hips > (thighL/R > shinL/R), spine > (head, shL/R > elL/R, gunPivot)
*/
const RIG={geo:{},prims:{}};
const hexC=h=>{const c=new T.Color(h);return[Math.pow(c.r,1.45),Math.pow(c.g,1.45),Math.pow(c.b,1.45)]};
function rPrim(k,mk){return RIG.prims[k]||(RIG.prims[k]=mk())}
function gbNew(){return{p:[],n:[],uv:[],i:[],c:[]}}
const _rgm=new T.Matrix4(),_rgq=new T.Quaternion(),_rge=new T.Euler(),_rgv=new T.Vector3(),_rgs=new T.Vector3(),_rgn=new T.Matrix3();
function gbAdd(B,geo,col,x,y,z,rx=0,ry=0,rz=0,sx=1,sy=1,sz=1){
  _rge.set(rx,ry,rz);_rgq.setFromEuler(_rge);_rgm.compose(_rgv.set(x,y,z),_rgq,_rgs.set(sx,sy,sz));_rgn.getNormalMatrix(_rgm);
  const P=geo.attributes.position,N=geo.attributes.normal,base=B.p.length/3,v=new T.Vector3();const c=hexC(col);
  for(let i=0;i<P.count;i++){v.fromBufferAttribute(P,i).applyMatrix4(_rgm);B.p.push(v.x,v.y,v.z);v.fromBufferAttribute(N,i).applyMatrix3(_rgn).normalize();B.n.push(v.x,v.y,v.z);B.uv.push(0,0);B.c.push(c[0],c[1],c[2])}
  if(geo.index){const I=geo.index.array;for(let i=0;i<I.length;i++)B.i.push(base+I[i])}else for(let i=0;i<P.count;i++)B.i.push(base+i)}
const gBox=(B,col,x,y,z,w,h,d,rx,ry,rz)=>gbAdd(B,rPrim('box',()=>new T.BoxGeometry(1,1,1)),col,x,y,z,rx,ry,rz,w,h,d);
const gCyl=(B,col,x,y,z,rt,rb,h,rx,ry,rz,seg=10)=>gbAdd(B,rPrim('cyl'+rt+'_'+rb+'_'+seg,()=>new T.CylinderGeometry(rt,rb,1,seg)),col,x,y,z,rx,ry,rz,1,h,1);
const gSph=(B,col,x,y,z,r,sx=1,sy=1,sz=1,half=false,rx=0)=>gbAdd(B,rPrim(half?'hs':'sp',()=>half?new T.SphereGeometry(1,14,8,0,TAU,0,Math.PI/2):new T.SphereGeometry(1,14,10)),col,x,y,z,rx,0,0,r*sx,r*sy,r*sz);
function gbGeo(B){const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(B.p,3));g.setAttribute('normal',new T.Float32BufferAttribute(B.n,3));g.setAttribute('uv',new T.Float32BufferAttribute(B.uv,2));g.setAttribute('color',new T.Float32BufferAttribute(B.c,3));g.setIndex(B.i);g.computeBoundingSphere();return g}

/* ---------- palettes ---------- */
const KIND_PAL={
  grunt:{uni:0x5b5440,pants:0x4d4836,vest:0x3b3a2c,gear:0x2e2c22,skin:0x9a7a5f,helm:0x3d4033,glove:0x22201a,boot:0x1d1b17,head:'mask',pack:false},
  heavy:{uni:0x2f322c,pants:0x2a2c27,vest:0x1f211c,gear:0x181a16,skin:0x8a6a50,helm:0x26291f,glove:0x151513,boot:0x111110,head:'heavy',pack:true,bulk:1.12},
  sniper:{uni:0x4f5a3a,pants:0x48523a,vest:0x3c4530,gear:0x2f3626,skin:0x9a7a5f,helm:0x56603f,glove:0x2a2a20,boot:0x1d1b17,head:'hood',pack:false,ghillie:true},
  boss:{uni:0x2a2a2a,pants:0x232323,vest:0x151515,gear:0x111111,skin:0x9a7a5f,helm:0x7a1c18,glove:0x101010,boot:0x0c0c0c,head:'beret',pack:false,bulk:1.08,accent:0xb02a20},
  soldier:{uni:0x4a5560,pants:0x3e4852,vest:0x2c363c,gear:0x252c31,skin:0x9a7a5f,helm:0x34404a,glove:0x1e2226,boot:0x16181a,head:'helmet',pack:true},
  gunman:{uni:0x6b5a48,pants:0x2f3542,vest:0x4a3f33,gear:0x3a3128,skin:0xa3805f,helm:0x2a2a2a,glove:0x2a221b,boot:0x231d18,head:'cap',pack:false,novest:true},
  zombie:{uni:0x3b3a33,pants:0x34332b,vest:0x3b3a33,gear:0x2a2924,skin:0x6f8a5a,helm:0x2a2924,glove:0x6f8a5a,boot:0x23221d,head:'zombie',pack:false,novest:true,gore:0x5a1a14},
  zbrute:{uni:0x3a2f2a,pants:0x2e2722,vest:0x3a2f2a,gear:0x2a2420,skin:0x5f7a4c,helm:0x2a2924,glove:0x5f7a4c,boot:0x23221d,head:'zombie',pack:false,novest:true,gore:0x5a1a14,bulk:1.3},
};
const SKIN_MOD={
  base:null,
  purple:{vest:0x3a2357,helm:0x2e1d46,gear:0x24173a,trim:0xb36bff,glow:1.4,name:'紫·幻影'},
  gold:{vest:0x6e5418,helm:0x5e4813,gear:0x3b2f10,trim:0xffcf5a,glow:1.1,name:'金·榮耀',metal:true},
  red:{vest:0x5e1010,helm:0x4a0c0c,gear:0x2d0a0a,trim:0xff3b2f,glow:1.6,name:'紅·赤焰'},
};
function rigPalette(o){let p;if(o.op&&typeof OPERATORS!=='undefined'&&OPERATORS[o.op]){const op=OPERATORS[o.op];p=Object.assign({},KIND_PAL.soldier,op.look||{})}else p=Object.assign({},KIND_PAL[o.kind]||KIND_PAL.grunt);
  const sm=o.skin&&SKIN_MOD[o.skin];if(sm){p.vest=sm.vest;p.helm=sm.helm;p.gear=sm.gear;p.trim=sm.trim;p.glow=sm.glow;p.metal=sm.metal}
  if(!p.trim)p.trim=p.accent||0x8a8a7a;p.team=o.team;return p}

/* ---------- part geometry ---------- */
function rigParts(p){const key=JSON.stringify(p);if(RIG.geo[key])return RIG.geo[key];
  const bulk=p.bulk||1,G={},team=({1:0x3f7fe0,2:0xd8392b,3:0x4fc34f,4:0xe8c030,5:0xa86be0,6:0x40d8d0,7:0xe07a30})[p.team]||0xd8a030,Z=p.head==='zombie';
  // hips
  let B=gbNew();gBox(B,p.pants,0,-.02,0,.34*bulk,.2,.22*bulk);gBox(B,p.gear,0,.07,0,.37*bulk,.05,.25*bulk);
  if(!Z){gBox(B,p.gear,-.17*bulk,.02,.03,.05,.09,.1);gBox(B,p.gear,.15*bulk,.03,-.09,.08,.1,.06);gBox(B,0x111111,.18*bulk,-.04,.02,.04,.14,.07)}
  G.hips=gbGeo(B);
  // thigh
  B=gbNew();gCyl(B,p.pants,0,-.215,0,.085*bulk,.066*bulk,.43);if(!Z){gBox(B,p.gear,.075*bulk,-.2,.0,.04,.14,.1)}G.thigh=gbGeo(B);
  B=gbNew();gCyl(B,p.pants,0,-.215,0,.085*bulk,.066*bulk,.43);if(!Z){gBox(B,p.gear,-.075*bulk,-.22,.0,.035,.12,.09)}G.thighL=gbGeo(B);
  // shin + boot
  B=gbNew();if(!Z)gBox(B,p.gear,0,-.03,.065,.11,.12,.05);gCyl(B,p.pants,0,-.19,0,.064*bulk,.052*bulk,.38);gBox(B,p.boot,0,-.4,.035,.115,.1,.25);gBox(B,0x0b0b0a,0,-.445,.035,.12,.018,.26);G.shin=gbGeo(B);
  // spine / torso
  B=gbNew();gCyl(B,p.uni,0,.1,0,.15*bulk,.155*bulk,.24,0,0,0,12);gBox(B,p.uni,0,.36,0,.4*bulk,.3,.24*bulk);gCyl(B,p.uni,0,.53,0,.09,.11,.05);
  if(!p.novest){gBox(B,p.vest,0,.35,.125*bulk,.36*bulk,.32,.06);gBox(B,p.vest,0,.35,-.125*bulk,.36*bulk,.32,.06);gBox(B,p.vest,-.19*bulk,.3,0,.04,.2,.22*bulk);gBox(B,p.vest,.19*bulk,.3,0,.04,.2,.22*bulk);
    for(let i=-1;i<=1;i++)gBox(B,p.gear,i*.1,.27,.17*bulk,.08,.11,.05);gBox(B,p.gear,-.1,.43,.165*bulk,.07,.05,.04);gBox(B,p.gear,.09,.44,.16*bulk,.1,.06,.035);
    gBox(B,p.vest,-.12,.5,0,.07,.04,.28*bulk);gBox(B,p.vest,.12,.5,0,.07,.04,.28*bulk);gBox(B,0x1a1a1a,-.13,.46,-.17*bulk,.05,.1,.04);gCyl(B,0x1a1a1a,-.13,.58,-.17*bulk,.006,.006,.16)}
  else{gBox(B,p.vest,0,.36,.12,.38*bulk,.28,.02);if(p.gore){gBox(B,p.gore,.06,.3,.125,.12,.1,.012);gBox(B,p.gore,-.1,.18,.15,.08,.06,.012)}}
  if(p.pack){gBox(B,p.gear,0,.33,-.25*bulk,.3,.36,.15);gBox(B,p.vest,0,.53,-.25*bulk,.26,.06,.12);gBox(B,p.gear,.13,.24,-.32*bulk,.06,.14,.05);gBox(B,p.gear,-.13,.24,-.32*bulk,.06,.14,.05)}
  if(p.ghillie){for(let i=0;i<14;i++){const a=i/14*TAU;gBox(B,i%2?0x55633d:0x46512f,Math.sin(a)*.2,.28+(i%3)*.08,Math.cos(a)*.15,.12,.22,.05,rnd(-.4,.4),a,rnd(-.3,.3))}}
  G.spine=gbGeo(B);
  // trim (skin glow)
  B=gbNew();if(!p.novest){gBox(B,p.trim,0,.51,.158*bulk,.36*bulk,.014,.012);gBox(B,p.trim,-.17*bulk,.35,.158*bulk,.012,.3,.012);gBox(B,p.trim,.17*bulk,.35,.158*bulk,.012,.3,.012);gBox(B,p.trim,0,.2,.158*bulk,.36*bulk,.014,.012);gBox(B,p.trim,0,.35,-.158*bulk,.012,.3,.012)}
  else gBox(B,p.trim,0,.48,.13,.3,.012,.012);G.trim=gbGeo(B);
  // head
  B=gbNew();gCyl(B,p.skin,0,.04,0,.05,.058,.09);
  const hs=p.head;const hc=Z?p.skin:p.skin;gSph(B,hc,0,.15,0,.105,1,1.13,1.05);gBox(B,hc,0,.13,.1,.03,.045,.04);
  if(hs==='helmet'||hs==='heavy'){gSph(B,p.helm,0,.165,-.005,.132,1.02,.98,1.1,true);gBox(B,p.helm,0,.165,0,.27,.03,.29);gBox(B,0x1a1a1a,0,.24,.12,.06,.05,.04);gBox(B,p.gear,-.13,.17,0,.03,.06,.12);gBox(B,p.gear,.13,.17,0,.03,.06,.12);
    gCyl(B,p.gear,-.115,.12,0,.045,.045,.04,0,0,Math.PI/2);gCyl(B,p.gear,.115,.12,0,.045,.045,.04,0,0,Math.PI/2);
    if(hs==='heavy'){gBox(B,0x0e1112,0,.12,.115,.2,.15,.03);gBox(B,0x3a4a52,0,.15,.13,.16,.05,.01)}else{gBox(B,0x111111,0,.17,.1,.2,.045,.035);gBox(B,0x2c4450,0,.17,.118,.17,.03,.005)}}
  else if(hs==='mask'){gSph(B,0x2a2a24,0,.16,0,.112,1,1.12,1.06);gBox(B,0x111111,0,.17,.1,.2,.045,.035);gBox(B,0x55513f,0,.17,.117,.16,.028,.004);gSph(B,p.helm,0,.2,-.005,.122,1,.8,1.08,true)}
  else if(hs==='hood'){gSph(B,p.uni,0,.16,-.015,.13,1,1.1,1.1);gBox(B,0x2c3326,0,.1,.09,.16,.07,.04);gBox(B,0x111111,0,.17,.1,.18,.035,.03)}
  else if(hs==='cap'){gSph(B,p.helm,0,.2,0,.112,1,.65,1.05,true);gBox(B,p.helm,0,.205,.11,.17,.012,.1);gBox(B,0x111111,-.115,.14,0,.025,.06,.05);gCyl(B,0x111111,0,.25,0,.115,.115,.012)}
  else if(hs==='beret'){gCyl(B,p.helm,.015,.235,0,.12,.115,.05,0,0,-.18,14);gBox(B,0x111111,0,.16,.103,.17,.03,.01)}
  else if(hs==='hair'){gSph(B,p.hair||0x1d1612,0,.18,-.01,.115,1,1,1.08,true);gBox(B,p.hair||0x1d1612,0,.12,-.11,.07,.16,.05,.3);gBox(B,0x111111,0,.16,.1,.19,.035,.03);gBox(B,p.trim,0,.16,.118,.15,.02,.004)}
  else if(hs==='visor'){gSph(B,p.helm,0,.165,0,.13,1,1.02,1.1);gBox(B,p.trim,0,.15,.12,.19,.06,.02);gBox(B,p.gear,0,.07,.07,.14,.06,.05)}
  else if(hs==='gasmask'){gSph(B,p.helm,0,.17,-.005,.128,1,.95,1.08,true);gBox(B,0x1b1d1b,0,.11,.11,.14,.1,.06);gCyl(B,0x2a2d2a,0,.08,.15,.04,.045,.05,Math.PI/2,0,0);gBox(B,0x2c4450,-.045,.16,.105,.05,.04,.01);gBox(B,0x2c4450,.045,.16,.105,.05,.04,.01)}
  else if(hs==='zombie'){gBox(B,0x3a1010,0,.08,.1,.08,.035,.02);gBox(B,0xffee66,-.04,.17,.105,.03,.025,.01);gBox(B,0xffee66,.04,.17,.105,.03,.025,.01);gSph(B,0x2a2620,0,.2,-.02,.1,1,.7,1,true)}
  G.head=gbGeo(B);
  // upper arm, forearm
  B=gbNew();gSph(B,p.novest?p.uni:p.vest,0,-.01,0,.075*bulk,1,.8,1);gCyl(B,p.uni,0,-.14,0,.058*bulk,.05*bulk,.28);G.uarm=gbGeo(B);
  B=gbNew();gSph(B,p.vest,0,-.01,0,.075*bulk,1,.8,1);gCyl(B,p.uni,0,-.14,0,.058*bulk,.05*bulk,.28);gCyl(B,team,0,-.08,0,.062*bulk,.062*bulk,.05);G.uarmL=gbGeo(B);
  B=gbNew();gCyl(B,p.uni,0,-.12,0,.05*bulk,.042*bulk,.24);gBox(B,p.glove,0,-.27,.01,.07,.09,.06);G.farm=gbGeo(B);
  RIG.geo[key]=G;return G}
function rigGunGeo(cls){const k='gun_'+cls;if(RIG.geo[k])return RIG.geo[k];const B=gbNew();const m=0x1c1d1b,p2=0x2e2c26,t=0x5a4e3a;
  if(cls==='pistol'){gBox(B,m,0,0,.42,.035,.05,.17);gBox(B,p2,0,-.06,.37,.03,.1,.05,.25)}
  else if(cls==='none'){}
  else{const L={rifle:1,ak:1,smg:.75,shotgun:1.05,dmr:1.15,sniper:1.3,lmg:1.15}[cls]||1;
    gBox(B,cls==='ak'?0x4a3420:m,0,-.01,.02,.04,.08,.18);gBox(B,m,0,0,.24,.055,.09,.3*L);gBox(B,cls==='ak'?0x5a3c22:p2,0,-.005,.24+.25*L,.055,.065,.18*L);gCyl(B,m,0,0,.3+.42*L,.012,.012,.25*L,Math.PI/2,0,0,8);
    if(cls==='lmg')gBox(B,p2,0,-.09,.24,.09,.1,.1);else if(cls==='shotgun')gCyl(B,p2,0,-.045,.42,.02,.02,.3,Math.PI/2,0,0,8);else gBox(B,p2,0,-.1,.25,.034,.13,.06,-.2);
    gBox(B,p2,0,-.08,.12,.035,.09,.04,.35);if(cls==='sniper'||cls==='dmr'){gCyl(B,0x111111,0,.075,.24,.025,.025,.26,Math.PI/2,0,0,10)}else gBox(B,0x111111,0,.065,.22,.04,.045,.08)}
  return RIG.geo[k]=gbGeo(B)}
function gunCls(wid){if(!wid)return 'rifle';if(wid==='knife'||wid==='none')return 'none';const w=typeof WEAPONS!=='undefined'&&WEAPONS[wid];return w?w.model:'rifle'}

/* ---------- build ---------- */
function makeRig(o={}){const p=rigPalette(o);const G=rigParts(p);
  const mat=new T.MeshStandardMaterial({vertexColors:true,roughness:.82,metalness:p.metal?.25:0});
  const trimMat=new T.MeshStandardMaterial({color:p.trim,emissive:p.glow?p.trim:0x000000,emissiveIntensity:p.glow||0,roughness:.5,metalness:p.metal?.8:.1});
  const gunMat=new T.MeshStandardMaterial({vertexColors:true,roughness:.5,metalness:.45});
  const M_=(geo,m=mat,sh=true)=>{const x=new T.Mesh(geo,m);x.castShadow=sh;return x};
  const root=new T.Group(),body=new T.Group();root.add(body);
  const hips=new T.Group();hips.position.y=.95;body.add(hips);hips.add(M_(G.hips));
  const mkLeg=s=>{const th=new T.Group();th.position.set(.1*s,-.05,0);hips.add(th);th.add(M_(s<0?G.thighL:G.thigh));const sh=new T.Group();sh.position.y=-.43;th.add(sh);sh.add(M_(G.shin));return[th,sh]};
  const [thL,shL]=mkLeg(-1),[thR,shR]=mkLeg(1);
  const spine=new T.Group();spine.position.y=.08;hips.add(spine);spine.add(M_(G.spine));const trim=M_(G.trim,trimMat,false);spine.add(trim);
  const head=new T.Group();head.position.y=.55;spine.add(head);head.add(M_(G.head));
  const mkArm=s=>{const sh=new T.Group();sh.position.set(.235*s*(p.bulk||1),.48,0);spine.add(sh);sh.add(M_(s<0?G.uarmL:G.uarm,mat,false));const el=new T.Group();el.position.y=-.28;sh.add(el);el.add(M_(G.farm,mat,false));return[sh,el]};
  const [uaL,faL]=mkArm(-1),[uaR,faR]=mkArm(1);
  const gunPivot=new T.Group();gunPivot.position.set(.02,.43,.1);spine.add(gunPivot);const gunMesh=M_(rigGunGeo(gunCls(o.wid)),gunMat,false);gunPivot.add(gunMesh);
  if(o.bighead)head.scale.setScalar(2.3);
  const R={root,body,hips,spine,head,thL,shL,thR,shR,uaL,faL,uaR,faR,gunPivot,gunMesh,mat,trimMat,gunMat,cls:gunCls(o.wid),zombie:p.head==='zombie',ph:Math.random()*6,sw:0,
    k:{crouch:0,prone:0,sprint:0,air:0,down:0,lean:0,reload:0,thr:0,kick:0,fwd:1,side:0,emote:0},deadT:-1,fall:1,pitch:0,lowT:0};
  root.updateMatrixWorld(true);
  return R}
function rigSetWeapon(R,wid){const c=gunCls(wid);if(c===R.cls)return;R.cls=c;R.gunMesh.geometry=rigGunGeo(c)}
function rigDispose(R){R.mat.dispose();R.trimMat.dispose();R.gunMat.dispose()}
function rigFlash(R,on){R.mat.emissive.setRGB(on?1:0,on?1:0,on?1:0)}
function rigAlpha(R,a){const t=a<.99;for(const m of [R.mat,R.trimMat,R.gunMat]){if(m.transparent!==t){m.transparent=t;m.needsUpdate=true}m.opacity=a;m.depthWrite=!t}}

/* ---------- two-bone IK ---------- */
const _ik={S:new T.Vector3(),E:new T.Vector3(),d:new T.Vector3(),n:new T.Vector3(),q:new T.Quaternion(),qi:new T.Quaternion(),DOWN:new T.Vector3(0,-1,0),t:new T.Vector3()};
function ikArm(sh,el,target,pole,a=.28,b=.27){const S=_ik.S.copy(sh.position);const d=_ik.d.subVectors(target,S);let L=d.length();d.multiplyScalar(1/(L||1));L=clamp(L,.08,a+b-.005);
  const cosA=clamp((a*a+L*L-b*b)/(2*a*L),-1,1),sinA=Math.sqrt(1-cosA*cosA);const n=_ik.n.copy(pole).addScaledVector(d,-pole.dot(d));if(n.lengthSq()<1e-6)n.set(0,-1,0);n.normalize();
  const E=_ik.E.copy(S).addScaledVector(d,a*cosA).addScaledVector(n,a*sinA);
  _ik.t.subVectors(E,S).normalize();sh.quaternion.setFromUnitVectors(_ik.DOWN,_ik.t);
  const T2=_ik.t.copy(S).addScaledVector(d,L).sub(E).normalize();_ik.qi.copy(sh.quaternion).invert();T2.applyQuaternion(_ik.qi);el.quaternion.setFromUnitVectors(_ik.DOWN,T2)}

/* ---------- animate ---------- */
const _rv1=new T.Vector3(),_rv2=new T.Vector3(),_poleL=new T.Vector3(-.9,-1,-.35),_poleR=new T.Vector3(.9,-1,-.5),_rE=new T.Euler(),_rQ=new T.Quaternion();
function gunToSpine(R,x,y,z,out){out.set(x,y,z);out.applyQuaternion(R.gunPivot.quaternion).add(R.gunPivot.position);return out}
/* s: {spd, fwd, side, sprint, crouch, prone, air, pitch, reload(0..1|-1), thr(0..1|-1), fire, lean, down, dead, fall, emote, far} */
function rigAnimate(R,s,dt){const k=R.k,a=Math.min(1,dt*10);
  if(s.dead){if(R.deadT<0){R.deadT=0;R.fall=s.fall||1}R.deadT+=dt;const t=Math.min(1,R.deadT/.7),e=t*t;
    R.body.rotation.set(-e*1.45,0,e*.25*R.fall);R.body.position.set(0,e*.16,-e*.2);R.hips.position.y=.95;
    R.thL.rotation.set(-e*.5,0,-.15*e);R.thR.rotation.set(-e*.2,0,.2*e);R.shL.rotation.x=e*.9;R.shR.rotation.x=e*.4;R.spine.rotation.set(-.2*e,0,0);R.head.rotation.set(-.4*e,.5*e*R.fall,0);
    R.uaL.quaternion.setFromEuler(_rE.set(-.4*e,0,-1.3*e));R.faL.rotation.set(-.5*e,0,0);R.uaR.quaternion.setFromEuler(_rE.set(-.2*e,0,1.2*e));R.faR.rotation.set(-.3*e,0,0);
    R.gunPivot.visible=e<.5;return}
  if(R.deadT>=0){R.deadT=-1;R.body.rotation.set(0,0,0);R.body.position.set(0,0,0);R.gunPivot.position.set(.02,.43,.1)}
  if(s.far){R.lowT-=dt;if(R.lowT>0)return;R.lowT=.12;dt=Math.max(dt,.12)}
  k.crouch+=((s.crouch?1:0)-k.crouch)*a;k.prone+=((s.prone?1:0)-k.prone)*Math.min(1,dt*5);k.sprint+=((s.sprint?1:0)-k.sprint)*a;k.air+=((s.air?1:0)-k.air)*a;k.down+=((s.down?1:0)-k.down)*Math.min(1,dt*6);
  k.lean+=((s.lean||0)-k.lean)*a;k.kick=Math.max(0,k.kick-dt*12);if(s.fire)k.kick=1;R.pitch+=((s.pitch||0)-R.pitch)*a;
  const spd=s.spd||0;const mv=clamp(spd/4,0,1.6);R.ph+=dt*(spd*2.6+(spd>.2?1.5:0))*(k.prone>.5?.5:1);
  const fw=s.fwd===undefined?1:s.fwd,sd=s.side||0;k.fwd+=(fw-k.fwd)*a;k.side+=(sd-k.side)*a;
  const ph=R.ph,sw=Math.sin(ph),cw=Math.cos(ph),amp=(.42+.2*k.sprint)*Math.min(1,mv)*(1-k.crouch*.35);
  // ---- legs
  const stand={hy:.95,th:0,sh:0},cr={hy:.64,th:-1.15,sh:1.75},air={th:-.75,sh:1.25};
  let hy=lerp(stand.hy,cr.hy,k.crouch);let thBase=lerp(0,cr.th,k.crouch),shBase=lerp(0,cr.sh,k.crouch);thBase=lerp(thBase,air.th,k.air*.8);shBase=lerp(shBase,air.sh,k.air*.8);
  const bob=Math.abs(cw)*.035*Math.min(1,mv)*(1-k.air);hy+=bob-.02*Math.min(1,mv);
  const swF=amp*k.fwd*(1-k.air),swS=amp*k.side*.7*(1-k.air);
  R.thL.rotation.set(thBase-sw*swF,0,-sw*swS*.6-.03);R.thR.rotation.set(thBase+sw*swF,0,sw*swS*.6+.03);
  R.shL.rotation.x=shBase+Math.max(0,-cw)*amp*(1.3+k.sprint*.9)*(1-k.air)*(k.fwd<0?.5:1);R.shR.rotation.x=shBase+Math.max(0,cw)*amp*(1.3+k.sprint*.9)*(1-k.air)*(k.fwd<0?.5:1);
  // downed: sitting wounded
  if(k.down>0){const d=k.down;hy=lerp(hy,.3,d);R.thL.rotation.x=lerp(R.thL.rotation.x,-1.45,d);R.thR.rotation.x=lerp(R.thR.rotation.x,-1.2,d);R.shL.rotation.x=lerp(R.shL.rotation.x,.25,d);R.shR.rotation.x=lerp(R.shR.rotation.x,.8,d)}
  // prone: rotate whole body forward, legs straight, crawl sway
  R.body.rotation.x=k.prone*Math.PI/2;R.body.position.set(0,.14*k.prone,-.9*k.prone);
  if(k.prone>0){const pr=k.prone,m1=Math.min(1,mv);hy=lerp(hy,.95,pr);
    R.thL.rotation.set(lerp(R.thL.rotation.x,.05+sw*.25*m1,pr),0,lerp(R.thL.rotation.z,-.18-sw*.12*m1,pr));R.thR.rotation.set(lerp(R.thR.rotation.x,.05-sw*.25*m1,pr),0,lerp(R.thR.rotation.z,.18-sw*.12*m1,pr));
    R.shL.rotation.x=lerp(R.shL.rotation.x,.15+Math.max(0,sw)*.6*m1,pr);R.shR.rotation.x=lerp(R.shR.rotation.x,.15+Math.max(0,-sw)*.6*m1,pr)}
  R.hips.position.y=hy;
  R.hips.position.x=k.lean*.08;R.hips.rotation.y=k.side*.25*(1-k.prone);
  // ---- torso
  const lean=k.sprint*.22+k.crouch*.18-k.down*.35+(R.zombie?.25:0);R.spine.rotation.set(lean,-R.hips.rotation.y+(R.zombie?0:.08),-k.lean*.38+sw*.03*Math.min(1,mv)*(1-k.prone));
  const pitch=clamp(R.pitch,-1.1,1.1);R.head.rotation.set(-pitch*.45-lean*.6-k.prone*1.25,-.08,k.lean*.2);
  if(s.emote&&s.emote!=='wave'){emotePose(R,s,dt);return}else if(R.props)for(const k in R.props)R.props[k].visible=false;
  // ---- gun / arms
  const thr=s.thr>=0?s.thr:-1,rl=s.reload>=0?s.reload:-1;
  if(R.zombie||R.cls==='none'){const reach=R.zombie?1:0;R.gunPivot.visible=false;
    const tl=_rv1.set(-.16,.42+Math.sin(ph*.5)*.05,.4*reach+.1),tr=_rv2.set(.16,.4+Math.cos(ph*.5)*.05,.42*reach+.1);
    if(!R.zombie){tl.set(-.2,.15+sw*.08*mv,.1-sw*.15*mv);tr.set(.2,.15-sw*.08*mv,.1+sw*.15*mv);if(s.fire||k.kick>0){tr.set(.15,.45,.45*k.kick+.1)}}
    if(s.fire&&R.zombie){tr.z+=.15;tl.z+=.15}
    ikArm(R.uaL,R.faL,tl,_poleL);ikArm(R.uaR,R.faR,tr,_poleR);return}
  R.gunPivot.visible=true;
  let gx=0,gy=0,gz=0;const pist=R.cls==='pistol';
  // aim pitch relative to torso (keep barrel on target)
  let aimX=-pitch-lean-k.prone*Math.PI/2;
  let ry=0,rz=0;
  if(k.sprint>0&&k.prone<.5){aimX=lerp(aimX,.75,k.sprint);ry=lerp(0,pist?0:-.7,k.sprint);gy=-.08*k.sprint;gx=-.04*k.sprint}
  if(k.down>0){aimX=lerp(aimX,.4,k.down*.6)}
  if(rl>=0){const w=Math.sin(Math.min(1,rl)*Math.PI);rz=.45*w;aimX+=.25*w;gz-=.05*w}
  if(thr>=0){const w=Math.sin(thr*Math.PI);aimX=lerp(aimX,.9,w);ry=lerp(ry,-.6,w);gx-=.08*w}
  gz-=k.kick*.05*(pist?.6:1);
  R.gunPivot.rotation.set(aimX-k.kick*.08,ry,rz);R.gunPivot.position.set((pist?.02:.1)+gx,(pist?.45:.47)+gy,(pist?.1:.06)+gz);R.gunPivot.updateMatrix();
  // hand targets
  const tr=pist?gunToSpine(R,.0,-.06,.36,_rv2):gunToSpine(R,0,-.08,.12,_rv2);
  let tl=pist?gunToSpine(R,-.01,-.07,.36,_rv1):gunToSpine(R,-.01,-.06,R.cls==='smg'?.32:.42,_rv1);
  if(rl>=0){const q=rl;if(q<.3)tl.lerp(gunToSpine(R,0,-.14,.25,new T.Vector3()),q/.3);else if(q<.55)tl.copy(gunToSpine(R,0,-.14,.25,new T.Vector3())).lerp(new T.Vector3(-.18,.08,.14),(q-.3)/.25);
    else if(q<.8)tl.set(-.18,.08,.14).lerp(gunToSpine(R,0,-.14,.25,new T.Vector3()),(q-.55)/.25);else tl.copy(gunToSpine(R,0,-.14,.25,new T.Vector3())).lerp(gunToSpine(R,-.01,-.06,.42,new T.Vector3()),(q-.8)/.2)}
  if(thr>=0){const q=thr;const back=_rv2.set(.24,.72,-.18),fwd=new T.Vector3(.1,.62,.5);if(q<.55)tr.copy(back);else tr.copy(back).lerp(fwd,(q-.55)/.45)}
  if(s.emote==='wave'){tr.set(.32,.8+Math.sin(M.t*8)*.05,.12+Math.sin(M.t*8)*.1)}
  ikArm(R.uaL,R.faL,tl,_poleL);ikArm(R.uaR,R.faR,tr,_poleR)}

/* convenience: derive locomotion params from velocity & yaw */
function rigLoco(vx,vz,yaw){const sp=Math.hypot(vx,vz);if(sp<.05)return[0,1,0];const fx=Math.sin(yaw),fz=Math.cos(yaw);return[sp,(vx*fx+vz*fz)/sp,(vx*fz-vz*fx)/sp]}

/* ---------- emotes ---------- */
function rigProp(R,k){R.props=R.props||{};if(R.props[k])return R.props[k];const g=new T.Group();const m=c=>new T.MeshStandardMaterial({color:c,roughness:.5});
  if(k==='sing'){const a=new T.Mesh(new T.CylinderGeometry(.018,.014,.16,8),m(0x222222));const b=new T.Mesh(new T.SphereGeometry(.035,8,6),m(0x9a9a9a));b.position.y=.09;g.add(a,b)}
  else if(k==='eat'){const a=new T.Mesh(new T.BoxGeometry(.1,.05,.07),m(0xc89a5a));g.add(a)}
  else if(k==='drink'){const a=new T.Mesh(new T.CylinderGeometry(.03,.03,.16,10),m(0x3a7a4a));const b=new T.Mesh(new T.CylinderGeometry(.012,.02,.05,8),m(0x3a7a4a));b.position.y=.1;g.add(a,b)}
  else if(k==='cards'){for(let i=0;i<5;i++){const c=new T.Mesh(new T.BoxGeometry(.05,.075,.003),m(i%2?0xf0f0f0:0xe8e0d0));c.rotation.z=(i-2)*.2;c.position.x=(i-2)*.012;g.add(c)}}
  g.position.set(0,-.3,.03);R.faR.add(g);return R.props[k]=g}
function emotePose(R,s,dt){const t=s.emoteT||0,e=s.emote;R.gunPivot.visible=false;for(const k in R.props||{})R.props[k].visible=k===e;if(e!=='dance')rigProp(R,e).visible=true;
  const L=_rv1,Rr=_rv2;
  if(e==='dance'){const b=Math.sin(t*7);R.hips.position.y=.95+Math.abs(b)*.06-.04;R.hips.rotation.y=b*.35;R.spine.rotation.set(.05,-b*.2,b*.15);R.head.rotation.set(-.1,b*.3,b*.2);
    R.thL.rotation.set(-Math.max(0,b)*.6,0,-.1);R.thR.rotation.set(-Math.max(0,-b)*.6,0,.1);R.shL.rotation.x=Math.max(0,b)*.9;R.shR.rotation.x=Math.max(0,-b)*.9;
    L.set(-.32,.78+b*.12,.15);Rr.set(.32,.78-b*.12,.15)}
  else if(e==='sing'){const b=Math.sin(t*4);R.spine.rotation.set(-.05,b*.1,0);R.head.rotation.set(-.15+Math.sin(t*8)*.05,b*.15,0);L.set(-.38,.55+Math.abs(Math.sin(t*2))*.25,.25);Rr.set(.05,.62,.22)}
  else if(e==='eat'){const c=Math.max(0,Math.sin(t*3));L.set(-.15,.25,.18);Rr.set(.06,.4+c*.24,.2-c*.04);R.head.rotation.set(.1-c*.08,0,0)}
  else if(e==='drink'){const c=Math.min(1,Math.max(0,Math.sin(t*1.5)*1.4));L.set(-.18,.2,.12);Rr.set(.05,.45+c*.2,.18);R.head.rotation.set(-c*.5,0,0);if(R.props.drink)R.props.drink.rotation.x=-c*1.4}
  else if(e==='cards'){R.hips.position.y=.62;R.thL.rotation.set(-1.15,0,-.1);R.thR.rotation.set(-1.15,0,.1);R.shL.rotation.x=1.75;R.shR.rotation.x=1.75;R.spine.rotation.set(.25,0,0);R.head.rotation.set(.35+Math.sin(t)*.05,Math.sin(t*.7)*.2,0);
    L.set(-.08,.3,.32);Rr.set(.1,.3+Math.max(0,Math.sin(t*2.4))*.15,.3)}
  ikArm(R.uaL,R.faL,L,_poleL);ikArm(R.uaR,R.faR,Rr,_poleR)}
