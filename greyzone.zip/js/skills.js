'use strict';
/* ================= operator skills · statuses · deployables =================
   Owner-authoritative: whoever casts a skill simulates it. Effects on AI go straight to the bots
   (clients report to the host). Effects on other humans are sent as events ('ske') and each
   receiver applies them to itself.
*/
PCOL.ice=new T.Color(0x9fe8ff);PCOL.violet=new T.Color(0xc38bff);PCOL.acid=new T.Color(0xc8e04a);PCOL.blue=new T.Color(0x5ad1ff);PCOL.heal=new T.Color(0x7dffb2);

/* ---------- statuses ---------- */
const ST_T=['slowT','frozenT','disarmT','deafT','blurT','nosprintT','invisT','stunT','speedT','staminaT','hitBoostT'];
function newSt(){return{slowT:0,slowK:1,frost:0,frostT:0,frozenT:0,disarmT:0,deafT:0,blurT:0,nosprintT:0,invisT:0,stunT:0,shield:0,speedT:0,speedK:1,staminaT:0,hitBoostT:0,dots:[],shredSet:null}}
function stTick(st,dt,b){for(const k of ST_T)if(st[k]>0)st[k]-=dt;if(st.slowT<=0)st.slowK=1;
  if(st.frost>0){st.frostT-=dt;if(st.frostT<=0){st.frost--;st.frostT=1}}
  for(let i=st.dots.length-1;i>=0;i--){const d=st.dots[i];d.t-=dt;d.acc+=d.dps*dt;
    if(d.acc>=4||d.t<=0){const a=d.acc;d.acc=0;
      if(b){if(!b.dead&&d.local)damageBot(b,a,'body',{player:true,pos:P.pos,how:d.how,dot:true},null)}
      else if(P&&st===P.st&&P.alive)damagePlayer(a,null,{dot:true,by:d.by,how:d.how,fire:d.fire})}
    if(d.t<=0)st.dots.splice(i,1)}}
function stMul(st){if(!st)return 1;if(st.frozenT>0)return 0;let m=1;if(st.slowT>0)m*=st.slowK;if(st.frost>0)m*=Math.max(.4,1-st.frost*.1);if(st.speedT>0)m*=st.speedK;if(st.stunT>0)m*=.25;return m}
function stCanFire(st){return!st||(st.frozenT<=0&&st.disarmT<=0&&st.stunT<=0)}
function addFrost(st,n){st.frost+=n;st.frostT=2.4;if(st.frost>=5){st.frost=0;st.frozenT=2;return true}return false}

/* ---------- teams ---------- */
function teamOf(peer){if(!peer||peer===NET.myId)return P.team;const p=netPuppets[peer];return p?p.team:((M.cfg&&M.cfg.teams&&M.cfg.teams[peer])||1)}
function hostile(a,b){if(MODES[M.mode]&&MODES[M.mode].ffa)return true;return a!==b}
function canMark(p){return!(p&&p.op==='formless')}
function opHas(op){return P&&P.op===op}

/* ---------- apply effects ---------- */
// e: {dmg,how,head,expl,fire, slow:[t,k], frost, stun, disarm, blur, deaf, nosprint, mark, dot:[dps,t], shred, heal, over, shield, speed:[t,k], stamina, revive, refill, pull:[x,z]}
function effToMe(e,src,owner){if(!P||(!P.alive&&!e.revive))return;const st=P.st;
  if(e.revive&&P.downed){revivePlayer();return}
  if(e.heal){const cap=e.over?150:100;if(P.hp<cap)P.hp=Math.min(cap,P.hp+e.heal);emit(_sv(P.pos.x,P.pos.y+1.2,P.pos.z),6,'heal',2,.6,.05,-2)}
  if(e.shield){st.shield=Math.min(100,st.shield+e.shield);note('獲得護盾 +'+e.shield)}
  if(e.speed){st.speedT=Math.max(st.speedT,e.speed[0]);st.speedK=e.speed[1]}
  if(e.stamina)st.staminaT=Math.max(st.staminaT,e.stamina);
  if(e.refill){for(const k in P.ammo)P.ammo[k]=P.ammoCap[k];invAdd('med');note('補給：彈藥補滿、急救包 +1');blip(700,.08,'sine',.05)}
  if(e.ally)return;
  if(e.chip){const first=!(P.chipT>0);P.chipT=Math.max(P.chipT||0,e.chip);if(first){banner('你被植入了追蹤晶片','位置已暴露給敵方 '+e.chip+' 秒 · 按 H 用醫療包挖出',2.4);blip(1800,.08,'square',.05);blip(1400,.08,'square',.05,0,.1)}}
  if(P.suitT>0&&src&&frontOf(src)&&(e.expl||e.dmg))return;
  if(e.slow&&!(P.dash&&P.dash.charge)){st.slowT=Math.max(st.slowT,e.slow[0]);st.slowK=Math.min(st.slowT>e.slow[0]?st.slowK:1,e.slow[1])}
  if(e.frost&&addFrost(st,e.frost))banner('被凍結','',1);
  if(e.stun){st.stunT=Math.max(st.stunT,e.stun);P.shake=Math.max(P.shake,.8)}
  if(e.disarm)st.disarmT=Math.max(st.disarmT,e.disarm);
  if(e.blur)st.blurT=Math.max(st.blurT,e.blur);
  if(e.deaf)st.deafT=Math.max(st.deafT,e.deaf);
  if(e.nosprint)st.nosprintT=Math.max(st.nosprintT,e.nosprint);
  if(e.dot)st.dots.push({dps:e.dot[0],t:e.dot[1],acc:0,by:owner,how:e.how,fire:e.fire});
  if(e.shred&&P.armor.tier>0)P.armor.dur=Math.max(0,P.armor.dur-e.shred);
  if(e.pull&&src){const tx=e.pull[0],tz=e.pull[1];if(isFree(tx,tz,.4)){P.pos.x=tx;P.pos.z=tz}P.vel.set(0,0,0)}
  if(e.dmg)damagePlayer(e.dmg,src,{by:owner,how:e.how,explosion:e.expl,head:e.head,fire:e.fire,skill:true})}
function stApplyBot(b,e,src){const st=b.st;
  if(e.slow){st.slowT=Math.max(st.slowT,e.slow[0]);st.slowK=Math.min(st.slowK,e.slow[1])}
  if(e.frost)addFrost(st,e.frost);
  if(e.stun){b.stunT=Math.max(b.stunT,e.stun);b.stunBig=!!e.knock}
  if(e.disarm)st.disarmT=Math.max(st.disarmT,e.disarm);
  if(e.blur){st.slowT=Math.max(st.slowT,e.blur);st.slowK=Math.min(st.slowK,.7);b.seeT=0}
  if(e.deaf)st.deafT=Math.max(st.deafT,e.deaf);
  if(e.nosprint){st.slowT=Math.max(st.slowT,e.nosprint);st.slowK=Math.min(st.slowK,.8)}
  if(e.shred)b.armor=Math.max(0,b.armor-2);
  if(e.pull&&!b.puppet){if(isFree(e.pull[0],e.pull[1],.4)){b.pos.x=e.pull[0];b.pos.z=e.pull[1]}}}
function effToBot(b,e,src){if(!b||b.dead)return;if(e.ally)return;
  stApplyBot(b,e,src);
  if(b.puppet&&M.net){const s=Object.assign({},e);delete s.dmg;delete s.dot;delete s.mark;netSend({t:'bst',id:b.id,e:s})}
  if(e.dot)b.st.dots.push({dps:e.dot[0],t:e.dot[1],acc:0,local:true,how:e.how});
  if(e.mark)markBot(b,e.mark,true);if(e.chip)b.chipT=Math.max(b.chipT||0,e.chip);
  if(e.dmg)damageBot(b,e.dmg,e.head?'head':'body',{player:true,pos:P.pos,how:e.how,expl:e.expl},null)}
function frontOf(src){const dx=src.x-P.pos.x,dz=src.z-P.pos.z,l=Math.hypot(dx,dz)||1;return(-Math.sin(P.yaw)*dx-Math.cos(P.yaw)*dz)/l>.45}
const _sv=(x,y,z)=>new T.Vector3(x,y,z);

/* ---------- marks (shared with team) ---------- */
let markQ={b:[],p:[],d:0};
function markBot(b,d,share){b.markT=Math.max(b.markT,d);if(share){markQ.b.push(b.id);markQ.d=Math.max(markQ.d,d)}}
function markPup(p,d,share){if(!canMark(p))return;p.markT=Math.max(p.markT,d);if(share){markQ.p.push(p.id);markQ.d=Math.max(markQ.d,d)}}
function flushMarks(){if(!M.net||(!markQ.b.length&&!markQ.p.length))return markQ={b:[],p:[],d:0};netSend({t:'mark',b:[...new Set(markQ.b)],p:[...new Set(markQ.p)],d:markQ.d});markQ={b:[],p:[],d:0}}
function onMarkMsg(m){if(hostile(teamOf(m.from),P.team))return;for(const id of m.b||[]){const b=bots.find(x=>x.id===id);if(b)b.markT=Math.max(b.markT,m.d)}for(const id of m.p||[]){const p=netPuppets[id];if(p&&canMark(p))p.markT=Math.max(p.markT,m.d);}}

/* ---------- target queries (owner side) ---------- */
function eachHostile(pos,r,fn,opt={}){const r2=r*r;
  for(const b of bots){if(b.dead||!hostile(P.team,b.team))continue;const dx=b.pos.x-pos.x,dy=b.pos.y+1-pos.y,dz=b.pos.z-pos.z;if(dx*dx+dz*dz+(opt.flat?0:dy*dy*.5)>r2)continue;if(!coneOK(opt,dx,dz))continue;
    if(opt.los&&!los(_sv(pos.x,pos.y,pos.z),_sv(b.pos.x,b.pos.y+1.3,b.pos.z)))continue;fn({b,pos:b.pos})}
  for(const k in netPuppets){const p=netPuppets[k];if(!p.alive||!hostile(P.team,p.team))continue;const dx=p.pos.x-pos.x,dy=p.pos.y+1-pos.y,dz=p.pos.z-pos.z;if(dx*dx+dz*dz+(opt.flat?0:dy*dy*.5)>r2)continue;if(!coneOK(opt,dx,dz))continue;
    if(opt.los&&!los(_sv(pos.x,pos.y,pos.z),_sv(p.pos.x,p.pos.y+1.3,p.pos.z)))continue;fn({p,pos:p.pos})}}
function coneOK(o,dx,dz){if(!o.cone)return true;const l=Math.hypot(dx,dz)||1;return(dx*o.cone[0]+dz*o.cone[1])/l>Math.cos(o.cone[2])}
function nearestHostile(pos,r,opt={}){let best=null,bd=r;eachHostile(pos,r,t=>{const d=Math.hypot(t.pos.x-pos.x,t.pos.z-pos.z);if(d<bd&&(!opt.skip||!opt.skip.has(t.b||t.p))){bd=d;best=t}},opt);return best}
// apply effect from a local skill to a target handle {b}|{p}
function skHit(t,e,src){if(t.b)effToBot(t.b,e,src);else if(t.p){if(e.mark)markPup(t.p,e.mark,true);t.p.flash=.06;const ev={type:'hit',to:t.p.id,x:src.x,y:src.y,z:src.z,e};netSend({t:'ske',ev})}}

/* ---------- events ---------- */
function fx(ev){skFx(ev,null);if(M.net)netSend({t:'ske',ev})}
function skFx(ev,owner){const local=!owner;const oTeam=local?P.team:teamOf(owner);const hostileMe=!local&&hostile(oTeam,P.team);const pos=_sv(ev.x,ev.y,ev.z);
  switch(ev.type){
  case 'boom':{if(local){explode(pos,ev.r,ev.dmg,{player:true,team:P.team,selfSafe:ev.selfSafe,how:ev.how});if(ev.e)eachHostile(pos,ev.r,t=>skHit(t,ev.e,pos),{los:true})}
    else{fireball(pos,ev.r*.55);emit(pos,30,'fire',12,.6,.12,4);puff(pos,8,5,3,0x4a443c);lightFlash(_sv(pos.x,pos.y+1,pos.z),9,30);const dp=camera.position.distanceTo(pos);boomSnd(clamp(1-dp/150,.2,1),panTo(pos.x,pos.z));P.shake=Math.max(P.shake,clamp(2.4-dp/14,.2,2.4));
      if(hostileMe&&P.alive){const pe=_sv(P.pos.x,P.pos.y+P.eyeH(),P.pos.z),d=pe.distanceTo(pos);if(d<ev.r&&los(_sv(pos.x,pos.y+.4,pos.z),pe)){damagePlayer(ev.dmg*.55*Math.pow(1-d/ev.r,.8),pos,{explosion:true,by:owner,how:ev.how});if(ev.e)effToMe(Object.assign({},ev.e,{dmg:0}),pos,owner)}}}
    break}
  case 'flash':{emit(pos,30,'white',10,.3,.06,0);lightFlash(pos,12,30);blip(3000,.4,'sine',.15);
    if(local)eachHostile(pos,ev.r||9,t=>{if(t.b){t.b.stunT=Math.max(t.b.stunT,3.5);if(t.b.puppet)netSend({t:'bst',id:t.b.id,e:{stun:3.5}})}},{los:true});
    if(local||hostileMe){const pe=_sv(P.pos.x,P.pos.y+P.eyeH(),P.pos.z);if(pe.distanceTo(pos)<(ev.r||9)&&los(pos,pe)){camFwd(_f);const to=pos.clone().sub(pe).normalize();if(to.dot(_f)>.2||pe.distanceTo(pos)<3)P.blindT=Math.max(P.blindT||0,opHas('rhino')?1.3:2.6)}}break}
  case 'smoke':W.smokes.push({x:ev.x,y:Math.max(0,groundAt(ev.x,ev.z,.2,(ev.y||0)+.5))+1.4,z:ev.z,r:ev.r||6.5,t:0,life:ev.life||14,kind:ev.kind||'plain',local,team:oTeam,col:ev.kind==='heal'||ev.kind==='symb'?0xb8f0c8:ev.kind==='thermal'?0xd8c8b8:0xcfd2cc});break;
  case 'zone':zones.push(Object.assign({},ev,{owner,local,team:oTeam,t:0,tick:0,hitSet:new Set()}));if(ev.zt==='cold')freezeDoors(pos,ev.r+1,ev.life);if(local&&ev.burn)burnDeployables(pos,ev.r);break;
  case 'pulse':{const cone=ev.cone;
    if(local){if(ev.ally){if(Math.hypot(P.pos.x-ev.x,P.pos.z-ev.z)<ev.r)effToMe(ev.e,pos,null)}else eachHostile(pos,ev.r,t=>skHit(t,ev.e,pos),{cone,los:ev.los,flat:true})}
    else if(P.alive){const dx=P.pos.x-ev.x,dz=P.pos.z-ev.z;const inR=Math.hypot(dx,dz)<ev.r&&coneOK({cone},dx,dz)&&(!ev.los||los(pos,_sv(P.pos.x,P.pos.y+1.3,P.pos.z)));
      if(inR&&(ev.ally?!hostileMe:hostileMe))effToMe(ev.e,pos,owner)}
    ring(pos,ev.r,ev.col||0x7fb8d8,ev.cone);break}
  case 'hit':if(!local&&ev.to===NET.myId)effToMe(ev.e,pos,owner);break;
  case 'wall':makeWall(ev,local);break;
  case 'tr':tracer(_sv(ev.x,ev.y,ev.z),_sv(ev.bx,ev.by,ev.bz),ev.col||0xffd890,ev.w||.025);break;
  case 'end':{const k=owner+':'+ev.id;const m=rMovers[k];if(m){scene.remove(m.m);if(m.box)m.box.off=true;delete rMovers[k]}break}
  case 'devhit':if(ev.owner===NET.myId){const d=devices.find(x=>x.id===ev.id);if(d)devDamage(d,ev.dmg)}break;
  }}
function onSkillMsg(m){if(!M.running)return;if(m.t==='ske')skFx(m.ev,m.from);else if(m.t==='skm')for(const a of m.ms)moverMsg(a,m.from);else if(m.t==='mark')onMarkMsg(m);
  else if(m.t==='bst'&&M.isHost){const b=bots.find(x=>x.id===m.id);if(b&&!b.dead)stApplyBot(b,m.e,null)}}

/* ---------- visuals ---------- */
const ringMat=new T.MeshBasicMaterial({color:0xffffff,transparent:true,opacity:.6,side:T.DoubleSide,depthWrite:false});const rings=[];
function ring(pos,r,col,cone){const g=cone?new T.RingGeometry(.9,1,24,1,0,cone[2]*2):new T.RingGeometry(.9,1,40);const m=new T.Mesh(g,ringMat.clone());m.material.color.setHex(col);m.rotation.x=-Math.PI/2;
  if(cone){m.rotation.z=Math.atan2(-cone[1],cone[0])-cone[2]}m.position.set(pos.x,(pos.y||0)+.15,pos.z);scene.add(m);rings.push({m,r,t:0,life:Math.min(1.6,.5+r/60)})}
function updateRings(dt){for(let i=rings.length-1;i>=0;i--){const g=rings[i];g.t+=dt;const k=g.t/g.life;g.m.scale.setScalar(Math.max(.01,g.r*k));g.m.material.opacity=.6*(1-k);if(k>=1){scene.remove(g.m);g.m.geometry.dispose();g.m.material.dispose();rings.splice(i,1)}}}

/* ---------- projectiles ---------- */
const projs=[];const projGeo=new T.SphereGeometry(.075,10,8),knifeGeo=new T.BoxGeometry(.03,.02,.28),arrowGeo=new T.CylinderGeometry(.012,.012,.7,6).rotateX(Math.PI/2);
const PROJ_COL={frag:0x3c4632,flash:0x8a8a8a,smoke:0x557a5a,fire:0xff6a2a,gas:0x9ab83a,acid:0xc8e04a,cryo:0x9fe8ff,shock:0x5ad1ff,pulse:0xffffff,dart:0x72c8f5,knife:0xd8d8d8,arrow:0x8fb6ff,wire:0x777777,jam:0xc38bff,trap:0x7fb8d8,cluster:0x4a4a40,heal:0x72f5a8,stim:0x5fe0a0};
const projMats={};for(const k in PROJ_COL)projMats[k]=new T.MeshStandardMaterial({color:PROJ_COL[k],roughness:.5,emissive:['fire','cryo','shock','pulse','dart','arrow','jam','stim'].includes(k)?PROJ_COL[k]:0,emissiveIntensity:.6});
function projMesh(kind){const m=new T.Mesh(kind==='knife'?knifeGeo:kind==='arrow'||kind==='stim'?arrowGeo:projGeo,projMats[kind]||projMats.frag);m.castShadow=true;scene.add(m);return m}
function lob(kind,speed,o={}){if(!o.noAnim){P.thrT=.5;speed*=P.throwPow||1}camera.updateMatrixWorld();camFwd(_f);const p=camera.position.clone().addScaledVector(_f,.5);if(o.side)p.addScaledVector(_r.set(1,0,0).applyQuaternion(camera.quaternion),o.side);
  const v=_f.clone().multiplyScalar(speed);if(!o.flat)v.y+=o.up!==undefined?o.up:3;v.add(P.vel.clone().multiplyScalar(.5));return lobFrom(kind,p,v,o)}
function lobFrom(kind,p,v,o={}){const m=projMesh(kind);m.position.copy(p);const n={m,v:v.clone(),kind,fuse:o.fuse||2,o,stuck:false,grav:o.grav!==undefined?o.grav:20,local:true};projs.push(n);
  if(M.net&&!o.quiet)netSend({t:'proj',kind,x:+p.x.toFixed(2),y:+p.y.toFixed(2),z:+p.z.toFixed(2),vx:+v.x.toFixed(2),vy:+v.y.toFixed(2),vz:+v.z.toFixed(2),fuse:n.fuse,g:n.grav,st:o.stick?1:0,im:o.impact?1:0});return n}
function spawnRemoteProj(o){const m=projMesh(o.kind||o.type||'frag');m.position.set(o.x,o.y,o.z);projs.push({m,v:_sv(o.vx,o.vy,o.vz),kind:o.kind,fuse:o.fuse,o:{stick:!!o.st,impact:!!o.im},grav:o.g!==undefined?o.g:20,stuck:false,local:false})}
function projInside(p){const q=gridQuery(p.x-.1,p.z-.1,p.x+.1,p.z+.1);for(const b of q)if(!b.off&&b.solid&&p.x>b.minX-.07&&p.x<b.maxX+.07&&p.z>b.minZ-.07&&p.z<b.maxZ+.07&&p.y>b.minY-.07&&p.y<b.maxY+.07)return true;return false}
function projActorHit(p){let hit=null;eachHostile(p,1.2,t=>{const e=t.pos;if(p.y>e.y-.05&&p.y<e.y+1.95&&Math.hypot(p.x-e.x,p.z-e.z)<.42)hit=t},{});return hit}
function updateProjs(dt){for(let i=projs.length-1;i>=0;i--){const n=projs[i],p=n.m.position;n.fuse-=dt;let contact=false,actor=null;
  if(!n.stuck){for(let s=0;s<3;s++){const h=dt/3;n.v.y-=n.grav*h;let c=false;
      p.x+=n.v.x*h;if(projInside(p)){p.x-=n.v.x*h;c=true;n.v.x*=-.4}
      p.z+=n.v.z*h;if(projInside(p)){p.z-=n.v.z*h;c=true;n.v.z*=-.4}
      p.y+=n.v.y*h;if(projInside(p)){p.y-=n.v.y*h;c=true;n.v.y*=-.3;n.v.x*=.7;n.v.z*=.7}
      const gy=terrH(p.x,p.z)+.075;if(p.y<gy){p.y=gy;c=true;if(Math.abs(n.v.y)>2&&!n.o.impact)blip(900,.03,'triangle',.02);n.v.y*=-.3;n.v.x*=.7;n.v.z*=.7}
      if(n.local&&(n.o.impact||n.o.direct)&&!c){actor=projActorHit(p);if(actor){c=true}}
      if(c){contact=true;if(n.o.stick){n.stuck=true;n.v.set(0,0,0);if(n.o.stickFuse!==undefined)n.fuse=n.o.stickFuse;break}if(n.o.impact)break}}
    if(n.kind==='knife'||n.kind==='arrow'||n.kind==='stim'){if(n.v.lengthSq()>.01)n.m.lookAt(p.x+n.v.x,p.y+n.v.y,p.z+n.v.z)}else n.m.rotation.x+=n.v.length()*dt*2}
  if(n.local&&n.o.tick)n.o.tick(n,dt);
  const done=n.fuse<=0||(contact&&n.o.impact)||(n.stuck&&n.o.boomOnStick);
  if(done){scene.remove(n.m);projs.splice(i,1);if(n.local&&n.o.boom)n.o.boom(p.clone(),actor)}}}

/* ---------- zones & smokes ---------- */
const zones=[];
const ZONE_FX={fire:[0xff7a2a,'fire'],gas:[0x9ab83a,null],acid:[0xc8e04a,'acid'],heal:[0x9cf0b8,'heal'],nano:[0xb8ffd8,'heal'],cold:[0xd8f4ff,'ice'],shock:[0x5ad1ff,'blue'],wire:[0x777777,'spark'],jam:[0xc38bff,'violet'],sense:[0x8fb6ff,null],symb:[0xb8f0c8,'heal']};
function updateZones(dt){for(let i=zones.length-1;i>=0;i--){const z=zones[i];z.t+=dt;if(z.t>z.life){zones.splice(i,1);continue}
    const f=ZONE_FX[z.zt]||[0xcccccc,null];if(Math.random()<dt*(z.zt==='fire'?14:6)*Math.min(2,z.r/4)){const a=Math.random()*TAU,r=Math.sqrt(Math.random())*z.r;const q=_sv(z.x+Math.cos(a)*r,z.y+.2,z.z+Math.sin(a)*r);
      if(z.zt==='fire'){emit(q,2,'fire',2,.6,.12,-3);if(Math.random()<.3)puff(q,1,1.6,1.4,0x3a332c,.5,.2,1.5)}else if(f[1])emit(q,2,f[1],1.5,.8,.06,-1.5);if(z.zt==='gas'||z.zt==='acid'||z.zt==='cold'||z.zt==='nano')puff(q,1,2.2,2,f[0],.45,.4,.4)}
    if(z.zt==='wire'&&!z.mesh){z.mesh=new T.Mesh(new T.TorusGeometry(z.r*.8,.04,4,40),new T.MeshStandardMaterial({color:0x666666,metalness:.8,roughness:.4}));z.mesh.rotation.x=Math.PI/2;z.mesh.position.set(z.x,z.y+.25,z.z);scene.add(z.mesh)}
    if(z.mesh&&z.t+dt>z.life){scene.remove(z.mesh)}
    z.tick-=dt;if(z.tick>0)continue;z.tick=.25;const k=.25,pos=_sv(z.x,z.y+.5,z.z);
    const helpful=z.zt==='heal'||z.zt==='nano';
    if(helpful||z.zt==='symb'){const ally=z.local||!hostile(z.team,P.team);if(ally&&P.alive&&Math.hypot(P.pos.x-z.x,P.pos.z-z.z)<z.r){if(P.hp<100)P.hp=Math.min(100,P.hp+(z.heal||6)*k);if(z.zt==='heal'){P.st.speedT=Math.max(P.st.speedT,.5);P.st.speedK=1.2}if(P.downed)P.bleed+=k*2}}
    if(helpful)continue;
    if(z.zt==='sense'){if(z.local){if(z.pulses){if(z.t>=z.nextP){z.nextP+=2;ring(pos,z.r,0x8fb6ff);blip(1400,.1,'sine',.04);eachHostile(pos,z.r,t=>{t.b?markBot(t.b,3,true):markPup(t.p,3,true)})}}else eachHostile(pos,z.r,t=>{t.b?markBot(t.b,.6,true):markPup(t.p,.6,true)},{los:false})}continue}
    const e=zoneEff(z,k);
    if(z.local)eachHostile(pos,z.r,t=>{const o=t.b||t.p;if(z.zt==='acid'&&z.hitSet.has(o))e.shred=0;else if(z.zt==='acid'){z.hitSet.add(o);e.shred=60}
      if(t.b)effToBot(t.b,e,pos)},{flat:true});
    else if(hostile(z.team,P.team)&&P.alive&&Math.hypot(P.pos.x-z.x,P.pos.z-z.z)<z.r&&Math.abs(P.pos.y-z.y)<3){const me=Object.assign({},e);if(z.zt==='acid'){if(z.hitSet.has('me'))me.shred=0;else{z.hitSet.add('me');me.shred=60}}
      if(me.dps){me.dmg=me.dps*k*(z.zt==='fire'&&opHas('foehn')?.4:1);delete me.dps}effToMe(me,pos,z.owner)}}
  for(let i=W.smokes.length-1;i>=0;i--){const s=W.smokes[i];s.t+=dt;if(s.t<s.life&&Math.random()<dt*7)puff({x:s.x+rnd(-s.r*.6,s.r*.6),y:s.y-1.1,z:s.z+rnd(-s.r*.6,s.r*.6)},1,6,4,s.col||0xcfd2cc,.85,.5,.25);
    if(s.kind==='thermal'&&s.local&&s.t<s.life)eachHostile(_sv(s.x,1,s.z),s.r+2,t=>{if(t.b)t.b.markT=Math.max(t.b.markT,.3);else markPup(t.p,.3,false)},{flat:true});
    if(s.t>s.life+2)W.smokes.splice(i,1)}}
function zoneEff(z,k){switch(z.zt){
  case 'fire':return{dps:z.dps||20,dmg:(z.dps||20)*k,how:z.how||'燃燒',fire:true};
  case 'gas':return{dmg:(z.dps||12)*k,slow:[.6,.7],how:z.how||'毒氣'};
  case 'acid':return{dmg:(z.dps||8)*k,how:'腐蝕酸液'};
  case 'cold':return{frost:k>0?(Math.random()<k*1.1?1:0):0,slow:[.5,.85],how:'杜瓦冷罐'};
  case 'shock':return{dmg:(z.dps||10)*k,stun:Math.random()<k/1.5?.9:0,how:'電擊箭'};
  case 'wire':return{dmg:(z.dps||6)*k,slow:[.6,.6],how:'刀片刺網'};
  case 'jam':return{deaf:.6,how:'干擾裝置'};
  case 'symb':return{dmg:8*k,how:'共生煙霧'};
  }return{}}
function freezeDoors(pos,r,life){for(const d of W.doors){if(Math.hypot(d.x-pos.x,d.z-pos.z)<r&&!d.locked){if(d.open)toggleDoor(d,true);d.locked='ice';d.iceT=life;emit(_sv(d.x,d.y+1,d.z),12,'ice',2,.8,.06,-1)}}}
function updateIceDoors(dt){for(const d of W.doors)if(d.locked==='ice'){d.iceT-=dt;if(d.iceT<=0)d.locked=null}}
function burnDeployables(pos,r){for(const s of W.shields)if(Math.hypot(s.x-pos.x,s.z-pos.z)<r+1.5)s.hp=0}

/* ---------- walls (shield / cover) ---------- */
function makeWall(ev,local){const alongX=Math.abs(ev.fz)>Math.abs(ev.fx);const w=alongX?ev.w:.3,d=alongX?.3:ev.w;const x=ev.x,z=ev.z,h=ev.h;
  const mesh=ev.kind==='cover'?new T.Mesh(new T.BoxGeometry(w,h,d),new T.MeshStandardMaterial({color:0x8d8a80,roughness:.95})):new T.Mesh(new T.BoxGeometry(w,h,d),new T.MeshBasicMaterial({color:0x72c8f5,transparent:true,opacity:.45,depthWrite:false}));
  mesh.position.set(x,ev.y+h/2,z);mesh.castShadow=ev.kind==='cover';scene.add(mesh);
  if(ev.kind==='cover'){for(let i=0;i<14;i++)puff(_sv(x+rnd(-w/2,w/2),ev.y+.3,z+rnd(-d/2,d/2)),1,1.5,1.2,0xb8b4a8,.6,.2,1);noiseHit(.6,500,.25,panTo(x,z))}
  const box={minX:x-w/2,maxX:x+w/2,minZ:z-d/2,maxZ:z+d/2,minY:ev.y,maxY:ev.y+h,solid:true,shoot:true,kind:'shield'};const s={x,z,box,mesh,hp:ev.hp||400,t:ev.life||25,cover:ev.kind==='cover'};box.shield=s;W.boxes.push(box);gridAdd(box);W.shields.push(s)}
function updateWalls(dt){for(let i=W.shields.length-1;i>=0;i--){const s=W.shields[i];s.t-=dt;if(s.t<=0||s.hp<=0){s.box.off=true;scene.remove(s.mesh);W.shields.splice(i,1);if(s.hp<=0)emit(_sv(s.x,1,s.z),20,s.cover?'dust':'spark',6,.5,.05)}else if(!s.cover)s.mesh.material.opacity=.35+.2*Math.sin(M.t*6)}}

/* ---------- movers (owner simulated, broadcast to others) ---------- */
let movers=[],devices=[],moverSeq=1,moverNetT=0;const rMovers={};
const MV_MAT={dark:new T.MeshStandardMaterial({color:0x2a2c2a,roughness:.5,metalness:.5}),acc:new T.MeshBasicMaterial({color:0xffb547}),blue:new T.MeshBasicMaterial({color:0x5ad1ff}),green:new T.MeshBasicMaterial({color:0x72f5a8}),red:new T.MeshBasicMaterial({color:0xff4b3e}),fur:new T.MeshStandardMaterial({color:0x5a4430,roughness:.95}),white:new T.MeshStandardMaterial({color:0xe8e8e8,roughness:.6}),steel:new T.MeshStandardMaterial({color:0xb8c0c8,metalness:.9,roughness:.25})};
function moverMesh(kind){const g=new T.Group();const B=(w,h,d,m,x=0,y=0,z=0)=>{const q=new T.Mesh(new T.BoxGeometry(w,h,d),m);q.position.set(x,y,z);q.castShadow=true;g.add(q);return q};
  switch(kind){
  case 'drone':B(.3,.08,.3,MV_MAT.dark);for(const [x,z] of [[-.2,-.2],[.2,-.2],[-.2,.2],[.2,.2]]){B(.18,.01,.03,MV_MAT.dark,x,.06,z)}B(.06,.04,.06,MV_MAT.acc,0,-.05,.12);break;
  case 'spider':{const s=new T.Mesh(new T.SphereGeometry(.16,10,8),MV_MAT.dark);s.position.y=.18;g.add(s);for(let i=0;i<6;i++){const a=i/6*TAU;B(.3,.025,.025,MV_MAT.dark,Math.cos(a)*.18,.1,Math.sin(a)*.18).rotation.y=-a}B(.05,.05,.05,MV_MAT.blue,0,.28,.12);break}
  case 'dog':B(.24,.24,.6,MV_MAT.fur,0,.45,0);B(.18,.2,.24,MV_MAT.fur,0,.62,.36);B(.1,.08,.12,MV_MAT.dark,0,.58,.52);for(const [x,z] of [[-.08,-.22],[.08,-.22],[-.08,.2],[.08,.2]])B(.07,.34,.07,MV_MAT.fur,x,.17,z);B(.05,.05,.25,MV_MAT.fur,0,.55,-.38).rotation.x=-.6;B(.26,.06,.3,MV_MAT.dark,0,.58,0);break;
  case 'blade':{const t=new T.Mesh(new T.TorusGeometry(.18,.025,4,16),MV_MAT.steel);t.rotation.x=Math.PI/2;g.add(t);B(.42,.01,.05,MV_MAT.steel);B(.05,.01,.42,MV_MAT.steel);B(.06,.04,.06,MV_MAT.red,0,.03,0);break}
  case 'bird':B(.12,.1,.36,MV_MAT.white);B(.7,.02,.18,MV_MAT.white,0,.03,-.02);B(.04,.04,.08,MV_MAT.acc,0,0,.21);break;
  case 'missile':case 'rocket':{const c=new T.Mesh(new T.CylinderGeometry(.08,.08,.9,8).rotateX(Math.PI/2),MV_MAT.dark);g.add(c);B(.3,.02,.1,MV_MAT.dark,0,0,-.38);B(.02,.3,.1,MV_MAT.dark,0,0,-.38);B(.1,.1,.06,MV_MAT.red,0,0,.46);break}
  case 'turret':B(.5,.12,.5,MV_MAT.dark,0,.06,0);B(.08,.6,.08,MV_MAT.dark,0,.4,0);{const h=new T.Group();h.position.y=.75;g.add(h);g.userData.head=h;const a=new T.Mesh(new T.BoxGeometry(.24,.2,.4),MV_MAT.dark);h.add(a);const br=new T.Mesh(new T.CylinderGeometry(.03,.03,.5,6).rotateX(Math.PI/2),MV_MAT.dark);br.position.z=.4;h.add(br);const e=new T.Mesh(new T.BoxGeometry(.08,.05,.02),MV_MAT.green);e.position.set(0,.04,.21);h.add(e)}break;
  case 'scope':B(.06,.5,.06,MV_MAT.dark,0,.25,0);{const c=new T.Mesh(new T.CylinderGeometry(.06,.06,.22,8).rotateX(Math.PI/2),MV_MAT.dark);c.position.y=.55;g.add(c)}B(.05,.05,.02,MV_MAT.blue,0,.55,.12);break;
  case 'anchor':{const c=new T.Mesh(new T.CylinderGeometry(.12,.16,.5,10),MV_MAT.dark);c.position.y=.25;g.add(c);B(.05,.4,.05,MV_MAT.blue,0,.7,0)}break;
  case 'supply':B(.6,.32,.4,new T.MeshStandardMaterial({color:0x4f5a3a,roughness:.8}),0,.16,0);B(.62,.06,.08,MV_MAT.acc,0,.3,0);break;
  case 'trap':case 'mine':{const c=new T.Mesh(new T.CylinderGeometry(.18,.2,.07,12),MV_MAT.dark);c.position.y=.04;g.add(c);B(.05,.03,.05,kind==='mine'?MV_MAT.red:MV_MAT.blue,0,.09,0)}break;
  case 'pdrone':B(.36,.1,.36,MV_MAT.white);for(const [x,z] of [[-.24,-.24],[.24,-.24],[-.24,.24],[.24,.24]])B(.2,.01,.03,MV_MAT.dark,x,.08,z);B(.12,.04,.12,MV_MAT.green,0,-.06,0);break;
  default:B(.2,.2,.2,MV_MAT.dark)}
  scene.add(g);return g}
function addMover(kind,pos,o={}){const mv=Object.assign({id:moverSeq++,kind,m:moverMesh(kind),t:0,life:10,net:true,vel:new T.Vector3()},o);mv.m.position.copy(pos);movers.push(mv);if(o.dev){devices.push(mv);mv.hp=o.hp||200}return mv}
function endMover(mv,i){scene.remove(mv.m);if(i===undefined)i=movers.indexOf(mv);if(i>=0)movers.splice(i,1);const di=devices.indexOf(mv);if(di>=0){devices.splice(di,1);if(mv.box){mv.box.off=true}}if(M.net&&mv.net)netSend({t:'ske',ev:{type:'end',id:mv.id,x:0,y:0,z:0}})}
function devDamage(d,dmg){d.hp-=dmg;if(d.hp<=0){d.dead=true;emit(d.m.position.clone().setY(d.m.position.y+.4),16,'spark',5,.5,.05);blip(200,.2,'sawtooth',.05);if(d.onDie)d.onDie(d);d.life=0}}
function updateMovers(dt){for(let i=movers.length-1;i>=0;i--){const mv=movers[i];mv.t+=dt;let keep=mv.t<mv.life&&!mv.dead;if(keep&&mv.upd)keep=mv.upd(mv,dt)!==false;if(!keep){if(mv.onEnd&&!mv.ended){mv.ended=true;mv.onEnd(mv)}endMover(mv,i)}}
  moverNetT-=dt;if(M.net&&moverNetT<=0){moverNetT=.1;const ms=[];for(const mv of movers)if(mv.net){const p=mv.m.position;ms.push([mv.id,mv.kind,+p.x.toFixed(2),+p.y.toFixed(2),+p.z.toFixed(2),+mv.m.rotation.y.toFixed(2)])}if(ms.length)netSend({t:'skm',ms})}
  for(const k in rMovers){const r=rMovers[k];r.age+=dt;if(r.age>1.5){scene.remove(r.m);if(r.box)r.box.off=true;delete rMovers[k];continue}const a=Math.min(1,dt*10);r.m.position.lerp(r.to,a);r.m.rotation.y+=angDiff(r.ry,r.m.rotation.y)*a;spinMover(r,dt)}
  for(const mv of movers)spinMover(mv,dt)}
function spinMover(mv,dt){if(mv.kind==='blade')mv.m.rotation.y+=dt*30;if(mv.kind==='bird'){mv.m.children[1].rotation.z=Math.sin(M.t*14)*.4}}
function moverMsg(a,owner){const [id,kind,x,y,z,ry]=a;const k=owner+':'+id;let r=rMovers[k];if(!r){if(kind==='trap'||kind==='mine'){if(hostile(teamOf(owner),P.team))return}r=rMovers[k]={m:moverMesh(kind),to:_sv(x,y,z),ry,age:0,kind,id,owner};r.m.position.set(x,y,z);
    if(kind==='anchor'||kind==='turret'){const box={minX:x-.25,maxX:x+.25,minZ:z-.25,maxZ:z+.25,minY:y,maxY:y+.9,solid:false,shoot:true,kind:'skdev',skdev:{id,owner}};r.box=box;W.boxes.push(box);gridAdd(box)}}
  r.to.set(x,y,z);r.ry=ry;r.age=0}
function hitRemoteDevice(box,dmg){const d=box.skdev;if(!d)return;netSend({t:'ske',ev:{type:'devhit',id:d.id,owner:d.owner,dmg,x:0,y:0,z:0}});hitmark('body')}

/* ---------- player skill usage ---------- */
const SKILL_KEYS=['s1','s2','s3'];
function initSkills(){P.cd={s1:3,s2:8,s3:M.mode==='extract'?60:30};P.chg={};for(const k of SKILL_KEYS){const s=OPERATORS[P.op][k];if(s.charges){P.chg[k]=s.charges;P.cd[k]=0}}
  const o=OPERATORS[P.op];P.nades=o.nades?{type:o.nades.type,n:o.nades.n}:null;P.st=newSt();P.skMode=null;P.overT=0;P.suitT=0;P.fshield=null;P.anchor=null;P.missile=null;P.dash=null;P.noFireT=0;P.radarT=0;
  P.passiveSilent=P.op==='cipher'||P.op==='formless';P.skin=(PF.skin||{})[P.op]||'base';if(!SKINS[P.skin])P.skin='base'}
function skCd(k){const s=OPERATORS[P.op][k];if(s.charges)return P.chg[k]>0?0:P.cd[k];return P.cd[k]}
function useSkill(k){if(!P||!P.alive||P.downed||M.countdown>0)return;const o=OPERATORS[P.op],sk=o[k];
  if(k==='s3'&&P.op==='fleet'&&P.anchor&&!P.anchor.dead){anchorRecall();return}
  if(k==='s3'&&P.missile){P.missile.life=0;return}
  if(k==='s2'&&P.bird){P.bird.life=0;return}
  if(P.st.frozenT>0||P.st.stunT>0){note('目前無法使用技能');return}
  if(skCd(k)>0){note(`${sk.name} 冷卻中 ${Math.ceil(skCd(k))} 秒`);blip(220,.06,'square',.03);return}
  const fn=SK[P.op+'.'+k];if(!fn)return;if(fn()===false)return;
  if(sk.charges){P.chg[k]--;if(P.cd[k]<=0)P.cd[k]=sk.cd}else P.cd[k]=sk.cd;
  banner(sk.name,['','小招','二招','大招'][+k[1]],1);blip(660,.12,'triangle',.06);blip(990,.15,'triangle',.06,0,.1);
  if(P.op==='rhino'){P.st.speedT=Math.max(P.st.speedT,3);P.st.speedK=1.2}}
function tickSkillCd(dt){for(const k of SKILL_KEYS){const s=OPERATORS[P.op][k];if(P.cd[k]>0){P.cd[k]-=dt*(M.mode==='extract'?1:1.3);if(P.cd[k]<=0){P.cd[k]=0;if(s.charges&&P.chg[k]<s.charges){P.chg[k]++;if(P.chg[k]<s.charges)P.cd[k]=s.cd}}}}}
function skOnKill(){if(!P)return;P.cd.s3=Math.max(0,P.cd.s3-8);P.cd.s1=Math.max(0,P.cd.s1-3);P.cd.s2=Math.max(0,P.cd.s2-3);
  if(P.overT>0){P.hp=Math.min(100,P.hp+30);P.overT+=4;P.st.speedT=P.overT;P.cd.s2=0;note('超載：+30 生命、刷新動力猛衝')}
  if(P.op==='fleet')P.cd.s1=0}
// G: operator grenade
function throwOpNade(){if(!P||!P.alive||P.downed)return;if(!P.nades){note('手雷改由探員技能投擲，這位探員沒有手雷');return}if(P.nades.n<=0){note('手雷已用完');return}if(P.nadeCd>0)return;
  P.nades.n--;P.nadeCd=1;const t=P.nades.type;
  if(t==='frag')lob('frag',17,{fuse:2.3,boom:p=>fx({type:'boom',x:p.x,y:p.y,z:p.z,r:8,dmg:240,how:'手雷'})});
  else lob('smoke',15,{fuse:1.4,boom:p=>fx({type:'smoke',x:p.x,y:p.y,z:p.z,r:6.5,life:14})});blip(500,.06,'triangle',.05,-200)}

/* helpers */
function eyeAim(){camera.updateMatrixWorld();camFwd(_f);return{e:camera.position.clone(),f:_f.clone()}}
function aimPoint(max){const a=eyeAim();if(rayWorld(a.e,a.f,max))return a.e.clone().addScaledVector(a.f,Math.max(.5,RH.t-.3));return a.e.clone().addScaledVector(a.f,max)}
function flatFwd(){return _sv(-Math.sin(P.yaw),0,-Math.cos(P.yaw))}
function boomAt(p,r,dmg,how,e){fx({type:'boom',x:p.x,y:p.y,z:p.z,r,dmg,how,e})}
function zoneAt(p,zt,r,life,o={}){fx(Object.assign({type:'zone',zt,x:p.x,y:Math.max(0,groundAt(p.x,p.z,.2,p.y+.5)),z:p.z,r,life},o))}
function smokeAt(p,r,life,kind){fx({type:'smoke',x:p.x,y:p.y,z:p.z,r,life,kind})}
function wallAt(kind,dist,w,h,life,hp){const f=flatFwd();const x=P.pos.x+f.x*dist,z=P.pos.z+f.z*dist;if(!isFree(x,z,.2)){note('前方空間不足');return false}fx({type:'wall',kind,x,y:P.pos.y,z,fx:f.x,fz:f.z,w,h,life,hp})}
function feetFwd(d){const f=flatFwd();let x=P.pos.x+f.x*d,z=P.pos.z+f.z*d;if(!isFree(x,z,.3)){x=P.pos.x;z=P.pos.z}return _sv(x,groundAt(x,z,.3,P.pos.y+.5),z)}
function seekMove(mv,target,spd,dt,fly){const p=mv.m.position;const dx=target.x-p.x,dz=target.z-p.z,dy=(fly?target.y:p.y)-p.y,L=Math.hypot(dx,dz,dy)||1;
  if(fly){p.x+=dx/L*spd*dt;p.y+=dy/L*spd*dt;p.z+=dz/L*spd*dt}else{moveCircle(p,dx/L*spd*dt,dz/L*spd*dt,.25,p.y,p.y+.6);p.y=groundAt(p.x,p.z,.25,p.y+.6)}
  mv.m.rotation.y=Math.atan2(dx,dz);return Math.hypot(dx,dz)}
function droneFly(dist,spd,onArrive){const a=eyeAim();const start=a.e.clone().addScaledVector(a.f,.8);let end=a.e.clone().addScaledVector(a.f,dist);if(rayWorld(a.e,a.f,dist))end=a.e.clone().addScaledVector(a.f,Math.max(1,RH.t-.6));
  addMover('drone',start,{life:dist/spd+1,upd:(mv,dt)=>{const p=mv.m.position;const to=end.clone().sub(p);const L=to.length();if(L<.4){onArrive(p.clone());return false}p.addScaledVector(to,Math.min(1,spd*dt/L));mv.m.rotation.y=Math.atan2(to.x,to.z)}})}

const SK={
/* 鐵爪 */
'ironclaw.s1':()=>{for(let i=0;i<3;i++)later(i*.2,()=>{lob('frag',30,{noAnim:true,impact:true,fuse:4,grav:9,up:1.5,side:.1,boom:p=>boomAt(p,4,120,'三聯榴彈')});gunSnd(.35,300,.3,60);P.kick+=.02})},
'ironclaw.s2':()=>{dash(flatFwd(),.36,26,{});noiseHit(.4,400,.3);emit(P.pos,12,'spark',4,.4,.05)},
'ironclaw.s3':()=>{P.overT=20;P.st.speedT=20;P.st.speedK=1.25;emit(_sv(P.pos.x,P.pos.y+1,P.pos.z),30,'fire',5,.6,.06,-2)},
/* 雷犀 */
'rhino.s1':()=>{P.fshield={hp:150,t:5}},
'rhino.s2':()=>{lob('cluster',15,{fuse:1.3,boom:p=>{boomAt(p,3,60,'集束炸彈');for(let i=0;i<5;i++){const a=i/5*TAU+rnd(-.3,.3);lobFrom('cluster',_sv(p.x,p.y+.3,p.z),_sv(Math.cos(a)*rnd(3,6),rnd(4,6),Math.sin(a)*rnd(3,6)),{fuse:rnd(.6,1),boom:q=>boomAt(q,3.5,85,'集束炸彈')})}}})},
'rhino.s3':()=>{dash(flatFwd(),2.5,11,{charge:true,hit:new Set()});P.shake=1;boomSnd(.3)},
/* 焚風 */
'foehn.s1':()=>{lob('smoke',15,{fuse:1.4,boom:p=>smokeAt(p,6.5,14,'thermal')})},
'foehn.s2':()=>{dash(flatFwd(),.32,22,{trail:'fire',lastT:_sv(P.pos.x,P.pos.y,P.pos.z)})},
'foehn.s3':()=>{lob('fire',16,{impact:true,fuse:2,boom:p=>{zoneAt(p,'fire',6,10,{dps:25,burn:true,how:'高熱燃燒彈'});fireball(p,2.5)}})},
/* 堡岩 */
'bastion.s1':()=>wallAt('cover',2,2.8,1.15,40,600),
'bastion.s2':()=>{lob('fire',14,{impact:true,fuse:2,boom:p=>zoneAt(p,'fire',3.8,8,{dps:18,how:'燃燒彈'})})},
'bastion.s3':()=>{const a=eyeAim();const p=P.mslFrom?P.mslFrom.clone():a.e.clone().addScaledVector(a.f,1.2);if(P.mslFrom)a.f.set(0,1,0);const dir=a.f.clone();P.mslYaw=P.yaw;P.mslPitch=P.pitch;$('missileFx').hidden=false;
    P.missile=addMover('missile',p,{life:9,upd:(mv,dt)=>{mv.m.visible=false;const f=_sv(-Math.sin(P.yaw)*Math.cos(P.pitch),Math.sin(P.pitch),-Math.cos(P.yaw)*Math.cos(P.pitch));dir.lerp(f,Math.min(1,dt*5)).normalize();const pp=mv.m.position;const step=32*dt;
    if(rayWorld(pp,dir,step+.4)||projActorHit(pp)||pp.y<-.2){return false}pp.addScaledVector(dir,step);mv.m.lookAt(pp.x+dir.x,pp.y+dir.y,pp.z+dir.z);if(Math.random()<dt*25)puff(pp.clone().addScaledVector(dir,-1.2),1,.8,1.4,0x9a948a,.5,.1,.3);$('mslInfo').textContent=`導引飛彈 · 高度 ${Math.round(pp.y)} m · 剩 ${Math.max(0,mv.life-mv.t).toFixed(1)} 秒 · 左鍵或 V 引爆`},
    onEnd:mv=>{P.missile=null;P.yaw=P.mslYaw;P.pitch=P.mslPitch;$('missileFx').hidden=true;mv.m.visible=true;boomAt(mv.m.position.clone(),6.5,210,'導引飛彈')}});noiseHit(.8,900,.3)},
/* 鳴鐘 */
'bellwether.s1':()=>wallAt('shield',1.6,3,1.9,20,400),
'bellwether.s2':()=>{lob('trap',12,{fuse:1.4,boom:p=>{const q=_sv(p.x,groundAt(p.x,p.z,.2,p.y+.3),p.z);addMover('trap',q,{life:60,net:false,arm:1,upd:(mv,dt)=>{mv.arm-=dt;if(mv.arm>0)return;if(nearestHostile(q,4,{flat:true})){fx({type:'pulse',x:q.x,y:q.y+.5,z:q.z,r:4.5,e:{slow:[5,.55],blur:5,mark:5,nosprint:5,how:'聲波陷阱'},col:0x7fb8d8});blip(1800,.3,'sine',.08);return false}}})}})},
'bellwether.s3':()=>{const f=flatFwd();fx({type:'pulse',x:P.pos.x,y:P.pos.y+1.2,z:P.pos.z,r:25,cone:[f.x,f.z,.62],los:true,e:{slow:[8,.5],nosprint:8,blur:8,dmg:30,how:'聲波壓制'},col:0x7fb8d8});blip(120,.8,'sawtooth',.1,-60)},
/* 織巢 */
'weaver.s1':()=>{const s=addMover('spider',feetFwd(1),{life:15,tgt:null,re:0,upd:(mv,dt)=>{mv.re-=dt;if(mv.re<=0){mv.re=.5;mv.tgt=nearestHostile(mv.m.position,25,{flat:true})}
    const p=mv.m.position;if(mv.tgt){const d=seekMove(mv,mv.tgt.pos,6.5,dt);if(d<1.1){skHit(mv.tgt,{stun:2.5,dmg:25,how:'戰術巡蛛'},p);emit(_sv(p.x,p.y+.5,p.z),20,'blue',5,.4,.04);blip(2400,.2,'sawtooth',.06);return false}}
    else{const f=mv.dir||(mv.dir=flatFwd());moveCircle(p,f.x*4*dt,f.z*4*dt,.25,p.y,p.y+.5);p.y=groundAt(p.x,p.z,.25,p.y+.6);mv.m.rotation.y=Math.atan2(f.x,f.z)}}})},
'weaver.s2':()=>{const q=feetFwd(1.2);addMover('mine',q,{life:90,net:false,arm:1.2,upd:(mv,dt)=>{mv.arm-=dt;if(mv.arm>0)return;const t=nearestHostile(q,3,{flat:true});if(t){smokeAt(q,5,10);skHit(t,{mark:10},q);blip(1200,.2,'square',.05);return false}}})},
'weaver.s3':()=>{const q=feetFwd(1.5);const tr=addMover('turret',q,{life:30,dev:true,hp:300*1.3,cool:0,upd:(mv,dt)=>{mv.cool-=dt;const h=mv.m.userData.head;const eye=_sv(q.x,q.y+.8,q.z);
    const t=nearestHostile(eye,35,{los:true});if(!t)return;const aim=_sv(t.pos.x,t.pos.y+1.2,t.pos.z);mv.m.rotation.y=0;h.rotation.y=Math.atan2(aim.x-eye.x,aim.z-eye.z);
    if(mv.cool<=0){mv.cool=.2;const miss=Math.random()<.35;const end=miss?aim.clone().add(_sv(rnd(-1,1),rnd(-.5,.5),rnd(-1,1))):aim;tracer(eye,end,0xffd890,.02);worldFlash(eye);gunSnd(clamp(1-camera.position.distanceTo(eye)/120,.05,1)*.3,1100,.15,0,panTo(eye.x,eye.z));
      if(M.net&&Math.random()<.5)netSend({t:'ske',ev:{type:'tr',x:eye.x,y:eye.y,z:eye.z,bx:end.x,by:end.y,bz:end.z}});if(!miss)skHit(t,{dmg:14,how:'哨兵母巢'},eye)}}});
    tr.box={minX:q.x-.3,maxX:q.x+.3,minZ:q.z-.3,maxZ:q.z+.3,minY:q.y,maxY:q.y+.95,solid:true,shoot:true,kind:'skdev',skdevLocal:tr};W.boxes.push(tr.box);gridAdd(tr.box)},
/* 杏林 */
'apricot.s1':()=>droneFly(20,10,p=>smokeAt(p,6,14)),
'apricot.s2':()=>zoneAt(P.pos,'heal',5,8,{heal:10}),
'apricot.s3':()=>{P.skMode={kind:'stim',n:M.mode==='extract'?3:6,t:15};note('激素槍：左鍵射擊隊友（沒有瞄準隊友時治療自己）')},
/* 蠍尾 */
'scorpion.s1':()=>{lob('acid',15,{impact:true,fuse:2,boom:p=>zoneAt(p,'acid',4,5,{dps:8})})},
'scorpion.s2':()=>{fx({type:'pulse',ally:true,x:P.pos.x,y:P.pos.y+1,z:P.pos.z,r:15,e:{ally:true,speed:[10,1.15],stamina:10},col:0xb6d64a})},
'scorpion.s3':()=>{lob('gas',14,{fuse:1.6,boom:p=>zoneAt(p,'gas',7,14,{dps:12,how:'毒氣彈'})})},
/* 荒原 */
'wayfarer.s1':()=>{lob('smoke',15,{fuse:1.4,boom:p=>{smokeAt(p,6,12,'symb');zoneAt(p,'symb',6,12,{heal:6})}})},
'wayfarer.s2':()=>{const q=feetFwd(1);const used=new Set();addMover('supply',q,{life:60,upd:(mv,dt)=>{if(!used.has('me')&&P.alive&&Math.hypot(P.pos.x-q.x,P.pos.z-q.z)<2){used.add('me');effToMe({refill:1,ally:true},q,null)}
    for(const k in netPuppets){const p=netPuppets[k];if(used.has(k)||!p.alive||hostile(P.team,p.team))continue;if(Math.hypot(p.pos.x-q.x,p.pos.z-q.z)<2){used.add(k);netSend({t:'ske',ev:{type:'hit',to:k,x:q.x,y:q.y,z:q.z,e:{refill:1,ally:true}}})}}}})},
'wayfarer.s3':()=>{const dir=flatFwd();let bit=false;addMover('dog',feetFwd(.8),{life:8,mk:0,ran:0,upd:(mv,dt)=>{const p=mv.m.position;mv.mk-=dt;if(mv.mk<=0){mv.mk=.4;eachHostile(p,12,t=>{t.b?markBot(t.b,4,true):markPup(t.p,4,true)},{flat:true})}
    const t=nearestHostile(p,6,{flat:true});if(t&&!bit){const d=seekMove(mv,t.pos,10,dt);if(d<1.3){bit=true;skHit(t,{dmg:40,slow:[3,.5],how:'軍犬'},p);noiseHit(.2,800,.25,panTo(p.x,p.z));return false}return}
    if(mv.ran>40)return false;const ox=p.x,oz=p.z;moveCircle(p,dir.x*9*dt,dir.z*9*dt,.3,p.y,p.y+.7);p.y=groundAt(p.x,p.z,.3,p.y+.7);mv.ran+=Math.hypot(p.x-ox,p.z-oz);mv.m.rotation.y=Math.atan2(dir.x,dir.z);
    if(Math.hypot(p.x-ox,p.z-oz)<dt*2){const s=pick([-1,1]);const nx=-dir.z*s,nz=dir.x*s;dir.x=dir.x*.5+nx*.5;dir.z=dir.z*.5+nz*.5;dir.normalize()}}});blip(500,.15,'sawtooth',.05);blip(420,.15,'sawtooth',.05,0,.18)},
/* 翎羽 */
'plume.s1':()=>{lob('smoke',15,{stick:true,fuse:4,stickFuse:.8,boom:p=>smokeAt(p,6,20)})},
'plume.s2':()=>zoneAt(aimPoint(12),'nano',6,12,{heal:6}),
'plume.s3':()=>{addMover('pdrone',_sv(P.pos.x,P.pos.y+2.4,P.pos.z),{life:25,sh:0,rv:0,upd:(mv,dt)=>{const p=mv.m.position;p.lerp(_sv(P.pos.x+Math.sin(M.t)*.8,P.pos.y+2.4,P.pos.z+Math.cos(M.t)*.8),Math.min(1,dt*3));
    mv.sh-=dt;if(mv.sh<=0){mv.sh=8;fx({type:'pulse',ally:true,x:p.x,y:p.y,z:p.z,r:20,e:{ally:true,shield:50},col:0xff9ad5})}
    mv.rv-=dt;if(mv.rv<=0){mv.rv=1;if(P.downed)revivePlayer();for(const k in netPuppets){const q=netPuppets[k];if(q.downed&&q.alive&&!hostile(P.team,q.team)&&q.pos.distanceTo(p)<25){netSend({t:'ske',ev:{type:'hit',to:k,x:p.x,y:p.y,z:p.z,e:{revive:1,ally:true}}});tracer(p,_sv(q.pos.x,q.pos.y+.6,q.pos.z),0x72f5a8,.04)}}}}})},
/* 弦月 */
'crescent.s1':()=>{const q=feetFwd(.8);const f=flatFwd();addMover('scope',q,{life:20,mk:0,upd:(mv,dt)=>{mv.m.rotation.y=Math.atan2(f.x,f.z);mv.mk-=dt;if(mv.mk<=0){mv.mk=.5;eachHostile(_sv(q.x,q.y+.6,q.z),90,t=>{t.b?markBot(t.b,1.2,true):markPup(t.p,1.2,true)},{cone:[f.x,f.z,.52],los:true,flat:true})}}})},
'crescent.s2':()=>{lob('arrow',48,{stick:true,impact:true,grav:6,fuse:4,up:.6,boom:(p,act)=>{if(act)skHit(act,{dmg:35,how:'電擊箭'},p);zoneAt(p,'shock',4,5,{dps:10})}})},
'crescent.s3':()=>{lob('arrow',48,{stick:true,impact:true,grav:6,fuse:4,up:.6,boom:p=>{fx({type:'zone',zt:'sense',x:p.x,y:p.y,z:p.z,r:30,life:6,pulses:true,nextP:0})}})},
/* 暗碼 */
'cipher.s1':()=>droneFly(15,11,p=>fx({type:'flash',x:p.x,y:p.y,z:p.z,r:10})),
'cipher.s2':()=>{P.st.invisT=10;note('光學迷彩啟動：開火會解除')},
'cipher.s3':()=>{P.radarT=15;ring(P.pos,60,0x62f0e0)},
/* 共鳴 */
'resonance.s1':()=>{lob('flash',16,{stick:true,fuse:3,stickFuse:1.5,boom:p=>fx({type:'flash',x:p.x,y:p.y,z:p.z,r:9})})},
'resonance.s2':()=>{lob('jam',14,{fuse:1.2,boom:p=>zoneAt(p,'jam',8,12)})},
'resonance.s3':()=>{const f=flatFwd();fx({type:'pulse',x:P.pos.x,y:P.pos.y+1,z:P.pos.z,r:150,cone:[f.x,f.z,1.047],e:{mark:6},col:0xc38bff});blip(900,.6,'sine',.06,600)},
/* 蒼鷹 */
'goshawk.s1':()=>fireChip(),
'goshawk.s2':()=>{const st=_sv(P.pos.x,P.pos.y+P.eyeH()+4,P.pos.z);P.fpvYaw=P.yaw;P.fpvPitch=P.pitch;P.pitch=0;P.birdChips=3;P.birdCd=0;$('missileFx').hidden=false;$('missileFx').classList.add('bird');
    P.bird=addMover('bird',st,{life:15,mk:0,upd:(mv,dt)=>{mv.m.visible=false;const p=mv.m.position;P.pitch=clamp(P.pitch,-.9,.45);const f=_sv(-Math.sin(P.yaw)*Math.cos(P.pitch),Math.sin(P.pitch),-Math.cos(P.yaw)*Math.cos(P.pitch));
      const sp=keys.KeyW?18:keys.KeyS?7:12;const step=sp*dt;if(rayWorld(p,f,step+.6)){f.y=Math.max(f.y,.6);f.normalize()}p.addScaledVector(f,step);const gy=groundAt(p.x,p.z,.3,p.y+.5);if(p.y<gy+2)p.y=gy+2;if(p.y>70)p.y=70;
      p.x=clamp(p.x,-W.half+3,W.half-3);p.z=clamp(p.z,-W.half+3,W.half-3);mv.m.rotation.y=Math.atan2(f.x,f.z);if(P.birdCd>0)P.birdCd-=dt;
      mv.mk-=dt;if(mv.mk<=0){mv.mk=.3;eachHostile(p,18,t=>{t.b?markBot(t.b,2,true):markPup(t.p,2,true)},{flat:true});scanPrints(p,32)}
      {let hitE=null;eachHostile(p,2,t=>{if(Math.abs(p.y-(t.pos.y+1))<1.6)hitE=t},{});if(hitE){mv.kami=1;return false}}
      $('mslInfo').textContent=`偵察鳥 · 高度 ${Math.round(p.y-gy)} m · 剩 ${Math.max(0,mv.life-mv.t).toFixed(1)} 秒 · 左鍵植入晶片（剩 ${P.birdChips}）· 撞向敵人會爆炸 · W 加速 S 減速 · B 收回`},
      onEnd:mv=>{if(mv.kami){const q=mv.m.position.clone();fx({type:'boom',x:q.x,y:q.y,z:q.z,r:3.2,dmg:55,how:'飛鳥俯衝',selfSafe:true});note('偵察鳥俯衝爆炸')}P.bird=null;P.yaw=P.fpvYaw;P.pitch=P.fpvPitch;$('missileFx').hidden=true;$('missileFx').classList.remove('bird');mv.m.visible=true}});blip(1600,.1,'sine',.04);blip(2100,.1,'sine',.04,0,.12)},
'goshawk.s3':()=>{lob('pulse',16,{fuse:1.5,boom:p=>{fx({type:'pulse',x:p.x,y:p.y,z:p.z,r:10,e:{mark:10,slow:[4,.6],how:'脈衝手雷'},col:0xffffff});lightFlash(p,4,14)}})},
/* 無相 */
'formless.s1':()=>{lob('knife',40,{impact:true,grav:5,fuse:3,up:.4,boom:(p,act)=>{if(act){const head=p.y-act.pos.y>1.5;skHit(act,{dmg:head?150:70,head,how:'飛刀'},p);hitmark(head?'head':'body')}else emit(p,4,'spark',2,.2,.03)}})},
'formless.s2':()=>{lob('flash',16,{stick:true,fuse:3,stickFuse:.6,boom:p=>fx({type:'flash',x:p.x,y:p.y,z:p.z,r:9})})},
'formless.s3':()=>{const a=eyeAim();const done=new Set();let hits=0;addMover('blade',a.e.clone().addScaledVector(a.f,.8),{life:10,tgt:null,upd:(mv,dt)=>{const p=mv.m.position;
    if(!mv.tgt||(mv.tgt.b&&mv.tgt.b.dead)||(mv.tgt.p&&!mv.tgt.p.alive))mv.tgt=nearestHostile(p,30,{skip:done,los:true});
    if(!mv.tgt){p.addScaledVector(a.f,10*dt);return}const tp=mv.tgt.pos;const o=mv.tgt.b||mv.tgt.p;const behind=Math.cos((o.yaw||0))*(p.z-tp.z)+Math.sin(o.yaw||0)*(p.x-tp.x)<0;
    const d=seekMove(mv,_sv(tp.x,tp.y+1.2,tp.z),behind?20:14,dt,true);if(d<.7){hits++;done.add(o);skHit(mv.tgt,{dmg:45,dot:[4,6],slow:[3,.6],how:'旋刃飛行器'},p);emit(p,10,'blood',3,.4,.05);blip(2600,.08,'sawtooth',.05);mv.tgt=null;if(hits>=3)return false}},
    onEnd:mv=>boomAt(mv.m.position.clone(),3,60,'旋刃飛行器')})},
/* 霜鑄 */
'frostforge.s1':()=>{lob('cryo',14,{fuse:1.4,boom:p=>zoneAt(p,'cold',5,10)})},
'frostforge.s2':()=>{const a=eyeAim();const end=a.e.clone().addScaledVector(a.f,20);addMover('drone',a.e.clone().addScaledVector(a.f,.8),{life:8,upd:(mv,dt)=>{const p=mv.m.position;const t=nearestHostile(p,20,{los:true});const goal=t?_sv(t.pos.x,t.pos.y+1.3,t.pos.z):end;
    const d=seekMove(mv,goal,9,dt,true);if((t&&d<1.5)||(!t&&p.distanceTo(end)<.6)){fx({type:'pulse',x:p.x,y:p.y,z:p.z,r:4,los:true,e:{stun:2.5,how:'溫感追蹤震撼彈'},col:0x7fe7ff});emit(p,24,'white',8,.3,.05,0);lightFlash(p,6,14);blip(2000,.3,'sine',.1);return false}}})},
'frostforge.s3':()=>{P.skMode={kind:'cryo',n:6,t:12};note('冷凝榴彈發射器：左鍵發射（剩 6 發）')},
/* 流影 */
'fleet.s1':()=>{let fi=(keys.KeyW?1:0)-(keys.KeyS?1:0),si=(keys.KeyD?1:0)-(keys.KeyA?1:0);if(touchS.stickId!==null){fi=-touchS.jy;si=touchS.jx}const sy=Math.sin(P.yaw),cy=Math.cos(P.yaw);let mx=-sy*fi+cy*si,mz=-cy*fi-sy*si;const l=Math.hypot(mx,mz);
    const d=l>.1?_sv(mx/l,0,mz/l):flatFwd();dash(d,.38,11,{roll:true});P.noFireT=1.38;P.crouchOn=true;noiseHit(.3,500,.15)},
'fleet.s2':()=>{const a=eyeAim();const f=a.f;tracer(a.e.clone().addScaledVector(f,.6),a.e.clone().addScaledVector(f,30),0x5ad1ff,.05);emit(a.e.clone().addScaledVector(f,3),10,'blue',6,.3,.04);blip(1800,.15,'sawtooth',.06,-900);
    let hit=0;const test=(pos,t)=>{const v=_sv(pos.x-a.e.x,pos.y+1.1-a.e.y,pos.z-a.e.z);const along=v.dot(f);if(along<0||along>30)return;const perp=v.addScaledVector(f,-along).length();if(perp<1.3){skHit(t,{dmg:20,slow:[3,.45],disarm:3,how:'鑽牆電刺'},a.e);hit++}};
    for(const b of bots)if(!b.dead&&hostile(P.team,b.team))test(b.pos,{b,pos:b.pos});for(const k in netPuppets){const p=netPuppets[k];if(p.alive&&hostile(P.team,p.team))test(p.pos,{p,pos:p.pos})}if(hit)hitmark('body')},
'fleet.s3':()=>{const q=_sv(P.pos.x,P.pos.y,P.pos.z);P.anchor=addMover('anchor',q,{life:20,dev:true,hp:150,upd:mv=>{emit(_sv(q.x,q.y+.8,q.z),1,'blue',1,.5,.04,-1)},onEnd:()=>{P.anchor=null}});
    const box={minX:q.x-.25,maxX:q.x+.25,minZ:q.z-.25,maxZ:q.z+.25,minY:q.y,maxY:q.y+.9,solid:false,shoot:true,kind:'skdev',skdevLocal:P.anchor};P.anchor.box=box;W.boxes.push(box);gridAdd(box);note('定位錨已放置：再按 V 可手動傳回')},
/* 深淵 */
'abyss.s1':()=>{lob('wire',14,{fuse:1.4,boom:p=>zoneAt(p,'wire',4,8,{dps:6})})},
'abyss.s2':()=>{const a=eyeAim();const h=rayActors(a.e,a.f,25,M.ff?null:P.team);const wall=rayWorld(a.e,a.f,25)?RH.t:25;const end=a.e.clone().addScaledVector(a.f,Math.min(wall,h?h.t:25));tracer(a.e.clone().addScaledVector(a.f,.5),end,0x888888,.04);noiseHit(.3,1200,.2);
    if(!h||h.t>wall){note('鉤爪沒有命中');return}const f=flatFwd();const tx=P.pos.x+f.x*1.8,tz=P.pos.z+f.z*1.8;const t=h.isBot?{b:h.ent,pos:h.ent.pos}:{p:h.ent,pos:h.ent.pos};skHit(t,{pull:[tx,tz],stun:1,dmg:10,how:'鉤爪槍'},P.pos);hitmark('body')},
'abyss.s3':()=>{P.suitT=15;const ki=P.slots.findIndex(s=>s&&s.knife);if(ki>=0)switchTo(ki);note('防爆套裝：正面免疫，只能近戰')},
/* 夜鴞 */
'owl.s1':()=>{P.buff.heartT=6},
'owl.s2':()=>{lob('dart',22,{stick:true,fuse:4,stickFuse:0,boom:p=>fx({type:'zone',zt:'sense',x:p.x,y:p.y,z:p.z,r:25,life:12})})},
'owl.s3':()=>{P.buff.scanT=8},
/* 壁壘 */
'bulwark.s1':()=>{if(P.armor.tier===0)P.armor={id:'temp',tier:2,dur:50,max:50};else P.armor.dur=Math.min(P.armor.max,P.armor.dur+50)},
'bulwark.s2':()=>wallAt('shield',1.6,3,1.9,25,400),
'bulwark.s3':()=>{const t=aimPoint(200);emit(_sv(t.x,.3,t.z),20,'red',3,1.5,.1,-2);for(let i=0;i<6;i++){const tx=t.x+rnd(-5,5),tz=t.z+rnd(-5,5);later(1+i*.33,()=>{const start=_sv(tx+rnd(-20,20),60,tz+rnd(-20,20));const goal=_sv(tx,groundAt(tx,tz,.2,60),tz);
    addMover('rocket',start,{life:4,upd:(mv,dt)=>{const p=mv.m.position;const to=goal.clone().sub(p);const L=to.length();mv.m.lookAt(goal);if(L<1)return false;p.addScaledVector(to,Math.min(1,70*dt/L));emit(p,1,'fire',2,.4,.15,-1)},onEnd:()=>boomAt(goal,6.5,150,'火箭齊射')})})}},
};

function fireChip(from){const a=eyeAim();if(from)a.e.copy(from);const h=rayActors(a.e,a.f,from?90:80,M.ff?null:P.team);const wall=rayWorld(a.e,a.f,90)?RH.t:90;const end=a.e.clone().addScaledVector(a.f,Math.min(wall,h?h.t:90));tracer(a.e.clone().addScaledVector(a.f,.6),end,0xe0e0e0,.02);blip(2400,.05,'square',.04);
  if(h&&h.t<wall){if(h.isBot)effToBot(h.ent,{mark:30,chip:30},a.e);else skHit({p:h.ent},{mark:30,chip:30},a.e);hitmark('body');note('晶片已植入：目標位置對全隊暴露 30 秒');return true}note('晶片沒有命中');return true}
function birdClick(){if(!P.bird||P.birdCd>0)return;if(P.birdChips<=0){note('偵察鳥的晶片用完了');return}P.birdChips--;P.birdCd=.6;fireChip(P.bird.m.position)}
function scanPrints(p,r){const c=new T.Color();let n=0;for(let i=0;i<FPN;i++){const f=fps_[i];if(f.t<0||f.x===undefined)continue;if(Math.hypot(f.x-p.x,f.z-p.z)<r){f.t=Math.min(f.t,.5);f.scan=1;n++}}
  // reveal fresh tracks of hostiles near the bird even if they were outside your own 40 m range
  for(const b of bots)if(!b.dead&&hostile(P.team,b.team)&&Math.hypot(b.pos.x-p.x,b.pos.z-p.z)<r){b._fs2=(b._fs2||0)+1;if(b._fs2%2===0)addPrint(b.pos.x,b.pos.y,b.pos.z,b.yaw,b._fs2%4?1:-1,true)}
  for(const k in netPuppets){const q=netPuppets[k];if(q.alive&&hostile(P.team,q.team)&&q.op!=='formless'&&!q.silent&&Math.hypot(q.pos.x-p.x,q.pos.z-p.z)<r)addPrint(q.pos.x,q.pos.y,q.pos.z,q.yaw+Math.PI,1,true)}}
/* ---------- dash / roll / charge ---------- */
function dash(dir,t,v,o){P.dash=Object.assign({dir:dir.clone().setY(0).normalize(),t,v},o)}
function updateDash(dt){const d=P.dash;if(!d)return false;d.t-=dt;if(d.t<=0||!P.alive||P.downed){P.dash=null;return false}
  P.vel.x=d.dir.x*d.v;P.vel.z=d.dir.z*d.v;
  if(d.charge){P.shake=Math.max(P.shake,.3);eachHostile(_sv(P.pos.x+d.dir.x*.8,P.pos.y+1,P.pos.z+d.dir.z*.8),1.8,t=>{const o=t.b||t.p;if(d.hit.has(o))return;d.hit.add(o);skHit(t,{dmg:60,stun:2,knock:1,how:'動能衝撞'},P.pos);boomSnd(.25);P.shake=1.2},{flat:true})}
  if(d.trail){if(P.pos.distanceTo(d.lastT)>1.2){d.lastT.copy(P.pos);zoneAt(P.pos,'fire',1.6,6,{dps:15,how:'火焰路徑'})}}
  return true}

/* ---------- special fire modes ---------- */
function skModeFire(){const m=P.skMode;if(!m)return false;if(P.fireT>0)return true;
  if(m.kind==='stim'){P.fireT=.5;const a=eyeAim();let best=null,bs=.14;for(const k in netPuppets){const p=netPuppets[k];if(!p.alive||hostile(P.team,p.team))continue;const v=_sv(p.pos.x-a.e.x,p.pos.y+1.2-a.e.y,p.pos.z-a.e.z);const L=v.length();if(L>40)continue;const ang=Math.acos(clamp(v.dot(a.f)/L,-1,1));if(ang<bs&&los(a.e,_sv(p.pos.x,p.pos.y+1.2,p.pos.z))){bs=ang;best=p}}
    if(best){tracer(a.e.clone().addScaledVector(a.f,.6),_sv(best.pos.x,best.pos.y+1.2,best.pos.z),0x5fe0a0,.03);netSend({t:'ske',ev:{type:'hit',to:best.id,x:a.e.x,y:a.e.y,z:a.e.z,e:{heal:40,over:true,ally:true}}});note('治療針命中 '+best.nick)}else effToMe({heal:40,over:true,ally:true},P.pos,null);
    blip(1300,.06,'sine',.05);m.n--}
  else if(m.kind==='cryo'){P.fireT=.55;lob('cryo',34,{noAnim:true,impact:true,grav:6,up:.5,fuse:4,boom:p=>{fx({type:'pulse',x:p.x,y:p.y,z:p.z,r:2.6,e:{frost:3,dmg:20,how:'冷凝榴彈'},col:0x9fe8ff});emit(p,20,'ice',5,.6,.06,2)}});gunSnd(.35,260,.3,40);P.kick+=.03;m.n--;note('冷凝榴彈 剩 '+m.n+' 發')}
  mouse.lPressed=false;if(m.n<=0)P.skMode=null;return true}

/* ---------- lethal hooks ---------- */
function anchorRecall(){const a=P.anchor;if(!a)return false;P.pos.copy(a.m.position);P.vel.set(0,0,0);P.vy=0;emit(_sv(P.pos.x,P.pos.y+1,P.pos.z),30,'blue',6,.6,.05);blip(400,.4,'sine',.08,800);a.dead=true;P.anchor=null;return true}
function skPreventDeath(){if(P.anchor&&!P.anchor.dead){anchorRecall();P.hp=50;P.downed=false;P.buff.godT=Math.max(P.buff.godT,1);P.st.dots=[];banner('緊急迴避','已傳回定位錨',1.6);return true}return false}
function skDamageMod(dmg,src,info){
  if(P.car&&!info.dot&&!info.fall){if(P.car.kind){carDamage(P.car,info.explosion?dmg:dmg*.25);return 0}dmg*=.6}
  if(info.explosion){if(P.op==='rhino')dmg*=.7;if(P.op==='bellwether')dmg*=.75}
  if(info.fire&&P.op==='foehn')dmg*=.4;
  if(P.st.frozenT>0)dmg*=1.15;
  if(src&&!info.fall&&!info.dot&&!info.gas){
    if(P.suitT>0&&frontOf(src)){emit(_sv(P.pos.x,P.pos.y+1.2,P.pos.z),4,'spark',3,.2,.03);return 0}
    if(P.fshield&&P.fshield.hp>0&&frontOf(src)){const a=Math.min(dmg,P.fshield.hp);P.fshield.hp-=a;dmg-=a;emit(_sv(P.pos.x,P.pos.y+1.2,P.pos.z),3,'blue',3,.2,.03)}
    if(P.op==='abyss'&&!info.explosion&&!frontOf(src)){const dx=src.x-P.pos.x,dz=src.z-P.pos.z,l=Math.hypot(dx,dz)||1;if((-Math.sin(P.yaw)*dx-Math.cos(P.yaw)*dz)/l<-.3)dmg*=.5}}
  if(P.st.shield>0){const a=Math.min(dmg,P.st.shield);P.st.shield-=a;dmg-=a}
  if(P.op==='fleet'&&dmg>0)P.st.hitBoostT=3;
  return dmg}

/* ---------- footprints (蒼鷹 passive) ---------- */
const FPN=260;const fpGeo=new T.PlaneGeometry(.12,.26).rotateX(-Math.PI/2);const fpMesh=new T.InstancedMesh(fpGeo,new T.MeshBasicMaterial({transparent:true,opacity:.85,depthWrite:false}),FPN);fpMesh.frustumCulled=false;fpMesh.renderOrder=2;
const fps_=[];for(let i=0;i<FPN;i++){fps_.push({t:-1});fpMesh.setMatrixAt(i,new T.Matrix4().makeScale(0,0,0));fpMesh.setColorAt(i,new T.Color(1,0,0))}scene.add(fpMesh);let fpIdx=0,fpT=0;
function addPrint(x,y,z,yaw,side,scan){const j=fpIdx=(fpIdx+1)%FPN;fps_[j]={t:0,x,z,scan:scan?1:0};const m=new T.Matrix4().makeRotationY(yaw);m.setPosition(x+Math.cos(yaw)*.1*side,y+.03,z-Math.sin(yaw)*.1*side);fpMesh.setMatrixAt(j,m);fpMesh.instanceMatrix.needsUpdate=true}
function updatePrints(dt){if(!P)return;const on=P.op==='goshawk';if(on&&P.bird&&M.frame%2===0)fpT=0;fpMesh.visible=on;if(!on)return;
  const track=(o,x,y,z,yaw)=>{if(o._fx===undefined){o._fx=x;o._fz=z;o._fs=1}const d=Math.hypot(x-o._fx,z-o._fz);if(d>.85){o._fx=x;o._fz=z;o._fs=-o._fs;if(Math.hypot(x-P.pos.x,z-P.pos.z)<40)addPrint(x,y,z,yaw,o._fs)}};
  for(const b of bots)if(!b.dead&&hostile(P.team,b.team)&&!b.static)track(b,b.pos.x,b.pos.y,b.pos.z,b.yaw);
  for(const k in netPuppets){const p=netPuppets[k];if(p.alive&&hostile(P.team,p.team)&&!p.silent&&p.op!=='formless')track(p,p.pos.x,p.pos.y,p.pos.z,p.yaw+Math.PI)}
  fpT-=dt;if(fpT>0)return;fpT=.25;const c=new T.Color();for(let i=0;i<FPN;i++){const f=fps_[i];if(f.t<0)continue;f.t+=.25;if(f.t>14){f.t=-1;fpMesh.setMatrixAt(i,new T.Matrix4().makeScale(0,0,0));fpMesh.instanceMatrix.needsUpdate=true;continue}
    const k=f.t/14;if(f.scan)c.setRGB(1,.05+.15*Math.sin(M.t*8),.05);else c.setRGB(1,f.t<4?.15:.85,f.t<4?.1:.2).multiplyScalar(1-k*.6);fpMesh.setColorAt(i,c)}if(fpMesh.instanceColor)fpMesh.instanceColor.needsUpdate=true}

/* ---------- reveal helpers (minimap) ---------- */
function hearR(){return P.op==='wayfarer'?25:P.op==='resonance'?28:0}
function skRevealBot(b){if(P.radarT>0)return true;const r=hearR();if(r&&!b.static&&b.pos.distanceTo(P.pos)<r&&(b.state==='combat'||b.wp))return true;return false}
function skRevealPup(p){if(P.radarT>0)return true;if(p.markT>0)return true;const r=hearR();return!!(r&&!p.silent&&p.op!=='formless'&&p.speed>1.5&&p.pos.distanceTo(P.pos)<r)}

/* ---------- scheduled callbacks ---------- */
let laters=[];function later(t,fn){laters.push({t,fn})}
function updateLaters(dt){for(let i=laters.length-1;i>=0;i--){const l=laters[i];l.t-=dt;if(l.t<=0){laters.splice(i,1);try{l.fn()}catch(e){console.error(e)}}}}

/* ---------- per-frame ---------- */
function updateSkills(dt){if(!P)return;tickSkillCd(dt);updateLaters(dt);updateZones(dt);updateMovers(dt);updateWalls(dt);updateRings(dt);updatePrints(dt);updateIceDoors(dt);
  stTick(P.st,dt,null);if(P.overT>0)P.overT-=dt;if(P.suitT>0)P.suitT-=dt;if(P.radarT>0)P.radarT-=dt;if(P.noFireT>0)P.noFireT-=dt;
  if(P.fshield){P.fshield.t-=dt;if(P.fshield.t<=0||P.fshield.hp<=0)P.fshield=null}
  if(P.skMode){P.skMode.t-=dt;if(P.skMode.t<=0)P.skMode=null}
  if(P.thrT>0)P.thrT-=dt;
  if(P.st.shield>0)P.st.shield=Math.max(0,P.st.shield-dt*2);if(P.hp>100)P.hp=Math.max(100,P.hp-dt*2);
  if(P.buff.heartT>0||P.buff.scanT>0)for(const k in netPuppets){const p=netPuppets[k];if(p.alive&&hostile(P.team,p.team)&&(P.buff.scanT>0||p.pos.distanceTo(P.pos)<35))markPup(p,.3,false)}
  if(P.op==='crescent'||markQ.b.length||markQ.p.length){if((M.frame%6)===0)flushMarks()}
  // screen effects
  const blur=P.st.blurT>0?Math.min(1,P.st.blurT)*4:0;const fz=P.st.frozenT>0;const cv=renderer.domElement;const filt=(blur?`blur(${blur.toFixed(1)}px) `:'')+(fz?'saturate(.4) hue-rotate(170deg) brightness(1.15)':P.st.frost>0?`saturate(${1-P.st.frost*.12})`:'')+(P.st.invisT>0?' contrast(1.1) hue-rotate(30deg)':'');if(cv._f!==filt){cv._f=filt;cv.style.filter=filt}
  if(master){const want=PF.settings.vol*(P.st.deafT>0?.15:1);if(Math.abs(master.gain.value-want)>.01)master.gain.value=want}}
function resetSkills(){if(P&&(P.missile||P.bird)){P.missile=null;P.bird=null;$('missileFx').hidden=true;$('missileFx').classList.remove('bird')}for(const p of projs)scene.remove(p.m);projs.length=0;for(const mv of movers)scene.remove(mv.m);movers=[];devices=[];for(const k in rMovers){scene.remove(rMovers[k].m);delete rMovers[k]}for(const s of W.shields||[])scene.remove(s.mesh);
  zones.length=0;for(const r of rings)scene.remove(r.m);rings.length=0;laters=[];markQ={b:[],p:[],d:0};for(const f of fps_)f.t=-1;for(let i=0;i<FPN;i++)fpMesh.setMatrixAt(i,new T.Matrix4().makeScale(0,0,0));fpMesh.instanceMatrix.needsUpdate=true;
  const cv=renderer.domElement;cv.style.filter='';cv._f='';if(master)master.gain.value=PF.settings.vol}

/* ---------- hold-to-charge throws ---------- */
function isThrowSkill(k){const f=SK[P.op+'.'+k];return!!f&&/\blob\(/.test(f.toString())&&!(P.op==='ironclaw'&&k==='s1')}
function chargeStart(kind){if(!P||!P.alive||P.downed||P.charging)return false;if(kind==='nade'&&(!P.nades||P.nades.n<=0)){throwOpNade();return false}
  if(kind!=='nade'&&(skCd(kind)>0||P.st.frozenT>0||P.st.stunT>0)){useSkill(kind);return false}P.charging=kind;P.charge=0;$('chargeBar').hidden=false;return true}
function chargeRelease(kind){if(P.charging!==kind)return;const pow=.45+P.charge*.85;P.charging=false;P.charge=0;$('chargeBar').hidden=true;P.throwPow=pow;try{if(kind==='nade')throwOpNade();else useSkill(kind)}finally{P.throwPow=1}}
/* 按技能鍵 = 拿出技能道具；左鍵 = 使用（投擲類按住左鍵蓄力、放開丟出）；右鍵或再按一次 = 收起 */
function readyName(k){return k==='nade'?({frag:'手雷',smoke:'煙霧彈'}[P.nades&&P.nades.type]||'手雷'):OPERATORS[P.op][k].name}
function readyCheck(k){if(!P||!P.alive||P.downed||M.countdown>0)return false;
  if(k==='nade'){if(!P.nades){note('這位探員沒有手雷');return false}if(P.nades.n<=0){note('手雷已用完');return false}if(P.nadeCd>0)return false;return true}
  if(P.st.frozenT>0||P.st.stunT>0){note('目前無法使用技能');return false}
  if(skCd(k)>0){const sk=OPERATORS[P.op][k];note(`${sk.name} 冷卻中 ${Math.ceil(skCd(k))} 秒`);blip(220,.06,'square',.03);return false}return true}
function skillKeyDown(k){if(!P||!P.alive)return;
  // 進行中的技能：再按一次 = 回收／引爆（不用拿出）
  if((k==='s3'&&P.op==='fleet'&&P.anchor&&!P.anchor.dead)||(k==='s3'&&P.missile)||(k==='s2'&&P.bird)){cancelReady(true);useSkill(k);return}
  if(P.skMode){useSkill(k);return}
  if(P.ready===k){cancelReady();return}
  if(P.charging)return;if(!readyCheck(k))return;
  P.ready=k;P.ads=false;P.readyT=0;mouse.lPressed=false;blip(520,.05,'square',.04);blip(740,.05,'square',.04,0,.06);
  $('readyHint').hidden=false;$('readyHint').textContent=`${readyName(k)} · 左鍵${(k==='nade'||isThrowSkill(k))?'（按住蓄力）':''}使用 · 右鍵收起`}
function cancelReady(silent){if(!P)return;if(P.charging){P.charging=false;P.charge=0;$('chargeBar').hidden=true}if(P.ready&&!silent)blip(380,.04,'square',.03);P.ready=null;$('readyHint').hidden=true}
function readyFireDown(){const k=P.ready;if(!k)return false;mouse.lPressed=false;
  if(k==='nade'||isThrowSkill(k)){if(!chargeStart(k))cancelReady(true);return true}
  P.ready=null;P.holdLock=true;$('readyHint').hidden=true;useSkill(k);return true}
function readyFireUp(){if(!P||!P.charging)return;const k=P.charging;chargeRelease(k);P.ready=null;$('readyHint').hidden=true}
let readyG=null;
function updateReadyProp(dt){const on=!!(P&&P.alive&&!P.downed&&(P.ready||P.charging)&&!P.car&&!P.mg&&!P.missile&&!P.bird);
  if(!readyG){if(!on)return;readyG=new T.Group();const nade=new T.Mesh(new T.SphereGeometry(.045,10,8),new T.MeshLambertMaterial({color:0x4a5a36}));const pin=new T.Mesh(new T.TorusGeometry(.016,.004,6,10),new T.MeshLambertMaterial({color:0xb0b0a8}));pin.position.set(.02,.045,0);nade.add(pin);
    const dev=new T.Group();const body=new T.Mesh(new T.BoxGeometry(.09,.055,.13),new T.MeshLambertMaterial({color:0x2a2e2a}));const scr=new T.Mesh(new T.PlaneGeometry(.07,.04),new T.MeshBasicMaterial({color:0x50ffb0}));scr.rotation.x=-Math.PI/2;scr.position.y=.029;dev.add(body,scr);
    const hand=new T.Mesh(new T.BoxGeometry(.07,.05,.11),new T.MeshLambertMaterial({color:0x6a5440}));hand.position.set(.01,-.045,.03);readyG.add(nade,dev,hand);readyG.userData={nade,dev,scr};camera.add(readyG)}
  readyG.visible=on;if(!on)return;const k=P.charging||P.ready;const thr=k==='nade'||isThrowSkill(k);readyG.userData.nade.visible=thr;readyG.userData.dev.visible=!thr;
  if(!thr)readyG.userData.scr.material.color.setStyle(OPERATORS[P.op].color||'#50ffb0');
  P.readyT=(P.readyT||0)+dt;const up=Math.min(1,P.readyT/.18);const c=P.charging?P.charge:0;
  readyG.scale.setScalar(.72);readyG.position.set(.2+c*.05,-.3+.12*up-c*.02,-.4+c*.12);readyG.rotation.set(-.2-c*.9,-.25,c*.3)}

/* 追蹤晶片：被植入者位置持續暴露 */
function tickChip(dt){if(!P)return;
  for(const b of bots){if(b.chipT>0){b.chipT-=dt;if(!b.dead)b.markT=Math.max(b.markT,.4)}}
  if(!(P.chipT>0))return;P.chipT-=dt;if(!P.alive){P.chipT=0;return}
  P.chipPing=(P.chipPing||0)-dt;if(P.chipPing>0)return;P.chipPing=1;
  for(const b of bots){if(b.dead||b.puppet||!hostile(b.team,P.team)||b.kind==='civ')continue;const d=b.pos.distanceTo(P.pos);if(d>120)continue;
    b.lastSeen.copy(P.pos);b.alertT=Math.max(b.alertT,4);if(b.state!=='combat'){b.state='combat';b.seeT=0}}}
