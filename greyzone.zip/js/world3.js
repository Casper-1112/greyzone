'use strict';
/* ================= phase 3: detail props · water · clock & weather · new maps ================= */
/* ---------- decorative (non-colliding) merged geometry ---------- */
let DECO=null,DECOM=null;
function decoBegin(){DECO=gbNew();DECOM=gbNew()}
function decoEnd(){for(const [B,met] of [[DECO,0],[DECOM,.55]]){if(!B||!B.p.length)continue;const g=gbGeo(B);const m=new T.Mesh(g,new T.MeshStandardMaterial({vertexColors:true,roughness:met?.5:.88,metalness:met}));m.castShadow=true;m.receiveShadow=true;scene.add(m);W.meshes.push(m)}DECO=DECOM=null}
const dB=(col,x,y,z,w,h,d,rx,ry,rz,metal)=>gBox(metal?DECOM:DECO,col,x,y,z,w,h,d,rx,ry,rz);
const dC=(col,x,y,z,rt,rb,h,rx,ry,rz,seg,metal)=>gCyl(metal?DECOM:DECO,col,x,y,z,rt,rb,h,rx,ry,rz,seg||12);
const dS=(col,x,y,z,r,sx,sy,sz,half,metal)=>gSph(metal?DECOM:DECO,col,x,y,z,r,sx,sy,sz,half);
function dGeo(geo,col,x,y,z,rx,ry,rz,sx,sy,sz,metal){gbAdd(metal?DECOM:DECO,geo,col,x,y,z,rx||0,ry||0,rz||0,sx||1,sy||1,sz||1)}
// pipe between two horizontal points
function dPipe(col,x0,y0,z0,x1,y1,z1,r){const dx=x1-x0,dy=y1-y0,dz=z1-z0,L=Math.hypot(dx,dy,dz);const v=new T.Vector3(dx,dy,dz).normalize();const q=new T.Quaternion().setFromUnitVectors(new T.Vector3(0,1,0),v);const e=new T.Euler().setFromQuaternion(q);
  gCyl(DECOM,col,(x0+x1)/2,(y0+y1)/2,(z0+z1)/2,r,r,L,e.x,e.y,e.z,8)}

/* ---------- landmarks ---------- */
function landmark(name,x,z,r=18){(W.landmarks||(W.landmarks=[])).push({name,x,z,r});if(W.pave&&r>=10&&r<=30){const m=new T.Mesh(new T.PlaneGeometry(r*1.7,r*1.7),MAT.road);m.rotation.x=-Math.PI/2;m.position.set(x,.012,z);m.receiveShadow=true;addObj(m)}}
function propScatter(n,kinds){const h=W.half;for(let i=0;i<n;i++){const x=srnd(-h+12,h-12),z=srnd(-h+12,h-12);if(!isFree(x,z,2.5)||waterAt(x,z))continue;const k=spick(kinds||['car','barrels','crates','sand','fence','lamp','container']);
  if(k==='car')wreckCar(x,z,SR()<.5);else if(k==='barrels'){for(let j=0;j<4;j++)barrel(x+srnd(-1.5,1.5),z+srnd(-1.5,1.5),SR()<.2)}else if(k==='crates'){woodCrate(x,z);if(SR()<.5)woodCrate(x,z,1.2,1);if(SR()<.5)woodCrate(x+1.3,z)}
  else if(k==='sand')sandbag(x,z,srnd(3,6),SR()<.5);else if(k==='fence'){const L=srnd(8,16),ax=SR()<.5;fence(x,z,x+(ax?L:0),z+(ax?0:L))}else if(k==='lamp')lamp(x,z);else if(k==='container')container(x,z,SR()<.5);else if(k==='tent')tent(x,z);else if(k==='log')logPile(x,z);else if(k==='palm')palm(x,z);else if(k==='rock')rock(x,z,srnd(3,7),srnd(3,7),srnd(1,4));else if(k==='tank')tank(x,z,srnd(2,3),srnd(3,5))}}
function gable(cx,cz,w,d,y0,col,alongX=true,pitch=.45){const run=(alongX?d:w)/2;const L=run/Math.cos(pitch);const rise=run*Math.tan(pitch);
  if(alongX){dB(col,cx,y0+rise/2,cz-run/2,w+.6,.14,L+.3,pitch,0,0);dB(col,cx,y0+rise/2,cz+run/2,w+.6,.14,L+.3,-pitch,0,0);dB(0x3a3530,cx,y0+rise,cz,w+.7,.12,.3)}
  else{dB(col,cx-run/2,y0+rise/2,cz,L+.3,.14,d+.6,0,0,pitch);dB(col,cx+run/2,y0+rise/2,cz,L+.3,.14,d+.6,0,0,-pitch);dB(0x3a3530,cx,y0+rise,cz,.3,.12,d+.7)}}
function house(cx,cz,w,d,o={}){const b=building(cx,cz,w,d,o);if(!o.flat&&b.h<6.5)gable(cx,cz,w,d,b.h+.3,o.roofCol||spick([0x6a3a2a,0x4a4a48,0x5a4630,0x3c4a52]),w>d);
  // window frames + AC units for detail
  if(SR()<.5)dB(0x9a9a92,cx+w/2+.3,b.h*.6,cz+srnd(-d/4,d/4),.5,.6,.9,0,0,0,true);
  dB(0x4a443a,cx,.12,cz+d/2+.6,2.4,.24,1.2);return b}
function silo(x,z,r,h,col=0xb8b4a8){if(!isFree(x,z,r))return;dC(col,x,h/2,z,r,r,h,0,0,0,18);dS(col,x,h,z,r,1,.5,1,true);sbox(x,z,r*1.6,r*1.6,h,null,0);
  for(let i=1;i<h/3;i++)dC(0x6a6a62,x,i*3,z,r+.04,r+.04,.12,0,0,0,18,true)}
function tank(x,z,r,h,col=0xd8d4c8){if(!isFree(x,z,r))return;dC(col,x,h/2,z,r,r,h,0,0,0,24);dC(0x6a6a62,x,h+.05,z,r*.95,r,.1,0,0,0,24,true);sbox(x,z,r*1.7,r*1.7,h,null,0);ladder(x+r,z,'x+',h)}
function lattice(x,z,w,h,col=0x8a2a20){const s=w/2;for(const [a,b] of [[-s,-s],[s,-s],[-s,s],[s,s]])dB(col,x+a,h/2,z+b,.22,h,.22,0,0,0,true);
  for(let y=2;y<h;y+=3){dB(col,x,y,z-s,w,.12,.12,0,0,0,true);dB(col,x,y,z+s,w,.12,.12,0,0,0,true);dB(col,x-s,y,z,.12,.12,w,0,0,0,true);dB(col,x+s,y,z,.12,.12,w,0,0,0,true)}
  sbox(x,z,w+.3,w+.3,h,null,0,{shoot:false})}
function radarDish(x,z,y0=0){dC(0x9a9a92,x,y0+2,z,.3,.5,4,0,0,0,10,true);const g=new T.SphereGeometry(3,18,8,0,TAU,0,1.1);dGeo(g,0xe8e8e0,x,y0+5.5,z,-1.9,SR()*TAU,0,1,1,1,true);sbox(x,z,1.2,1.2,4.5,null,y0)}
function coolingTower(x,z,r=13,h=34){const pts=[];for(let i=0;i<=10;i++){const t=i/10;pts.push(new T.Vector2(r*(1-.38*Math.sin(t*Math.PI*.85)),t*h))}const g=new T.LatheGeometry(pts,28);g.computeVertexNormals();
  const m=new T.Mesh(g,new T.MeshStandardMaterial({color:0xb8b6ae,roughness:.95,side:T.DoubleSide}));m.position.set(x,0,z);m.castShadow=true;m.receiveShadow=true;scene.add(m);W.meshes.push(m);
  // collision ring with a gap (walk-in at +x side)
  for(let i=0;i<16;i++){const a=i/16*TAU;if(Math.abs(Math.cos(a)-1)<.05)continue;const cx=x+Math.cos(a)*r,cz=z+Math.sin(a)*r;sbox(cx,cz,r*.42,r*.42,h*.6,null,0)}}
function reactorDome(x,z,r=11){dC(0xc8c4b8,x,4,z,r,r,8,0,0,0,28);dS(0xd8d4c8,x,8,z,r,1,.75,1,true);sbox(x,z,r*1.6,r*1.6,14,null,0)}
function rocket(x,z,h=46){dC(0xeeeeea,x,h/2+4,z,2.2,2.2,h,0,0,0,20);gbAdd(DECO,new T.ConeGeometry(2.2,7,20),0xd8d8d0,x,h+7.5,z,0,0,0,1,1,1);
  for(const a of [0,1,2,3]){const ax=Math.cos(a*Math.PI/2),az=Math.sin(a*Math.PI/2);dB(0x2a2a30,x+ax*2.6,6,z+az*2.6,az?.2:2,5,ax?.2:2);dC(0xeeeeea,x+ax*3,h/3,z+az*3,.9,.9,h*.6,0,0,0,12)}
  dB(0xb02020,x,h*.75,z+2.21,1.6,3,.05);sbox(x,z,6,6,h,null,0);lattice(x+7,z,4,h+4)}
function wreckCar(x,z,rot){if(!isFree(x,z,2))return;const c=spick([0x6a2a20,0x2a3a4a,0x4a4a40,0x8a8070]);const r=rot?Math.PI/2:0;
  dB(c,x,.75,z,rot?4.2:1.9,.9,rot?1.9:4.2,0,0,0,true);dB(0x1a1a1a,x,1.45,z,rot?2.2:1.7,.55,rot?1.7:2.2);for(const s of [-1,1])for(const t of [-1,1])dC(0x111111,x+(rot?t*1.4:s*.95),.35,z+(rot?s*.95:t*1.4),.35,.35,.25,0,0,Math.PI/2,10);
  sbox(x,z,rot?4.2:1.9,rot?1.9:4.2,1.3,null,0)}
function tent(x,z,w=4,d=5,col=0x56603f){if(!isFree(x,z,Math.max(w,d)/2))return;gable(x,z,w,d,0,col,false,.95);sbox(x,z,w*.7,d,1.6,null,0,{shoot:false});lootBox(x,z+d*.25,spick(['crate','med','weapon']))}
function palm(x,z){if(!isFree(x,z,.5))return;const h=srnd(5,8);for(let i=0;i<5;i++)dC(0x7a6040,x+i*.08,h*i/5+h/10,z,.18,.22,h/5,0,0,.05,8);for(let i=0;i<7;i++){const a=i/7*TAU;dB(0x3f6a2a,x+Math.cos(a)*1.3,h+.1,z+Math.sin(a)*1.3,2.6,.06,.6,0,-a,.35*(Math.cos(a)>0?-1:1))}sbox(x,z,.4,.4,h,null,0)}
function logPile(x,z){if(!isFree(x,z,2))return;for(let i=0;i<3;i++)for(let j=0;j<3-i;j++)dC(0x7a5838,x,.35+i*.6,z-1+j*.65+i*.32,.32,.32,4,Math.PI/2,0,Math.PI/2,8);sbox(x,z,4,2.2,1.6,null,0)}
function derrick(x,z){lattice(x,z,3,16,0x5a5a52);dB(0x2a2a28,x,16.4,z,3.6,.6,.8,0,0,0,true);dB(0x3a3a34,x+3,1,z,3,2,2,0,0,0,true);sbox(x+3,z,3,2,2,null,0)}
function fence(x0,z0,x1,z1){const L=Math.hypot(x1-x0,z1-z0),n=Math.ceil(L/3);for(let i=0;i<=n;i++){const t=i/n;dB(0x5a5a52,x0+(x1-x0)*t,1.1,z0+(z1-z0)*t,.08,2.2,.08,0,0,0,true)}
  const a=Math.atan2(z1-z0,x1-x0);dB(0x7a7a72,(x0+x1)/2,1.1,(z0+z1)/2,L,1.9,.02,0,-a,0,true);const alongX=Math.abs(x1-x0)>Math.abs(z1-z0);sbox((x0+x1)/2,(z0+z1)/2,alongX?L:.15,alongX?.15:L,2.2,null,0,{shoot:false})}
function pillarRuin(x,z,n=6,r=6){for(let i=0;i<n;i++){const a=i/n*TAU;const h=srnd(2,6);const px=x+Math.cos(a)*r,pz=z+Math.sin(a)*r;dC(0xc8bca0,px,h/2,pz,.55,.6,h,0,0,0,10);sbox(px,pz,1,1,h,null,0)}dB(0xb8ac90,x,.15,z,r*2.2,.3,r*2.2)}
function market(x,z){for(let i=0;i<6;i++){const sx=x+(i%3-1)*5,sz=z+(i<3?-3:3);if(!isFree(sx,sz,1.5))continue;const c=spick([0xb03a2a,0x2a6ab0,0xd8b030,0x3a8a4a]);dB(0x6a5038,sx,.5,sz,3,1,1.4);dB(c,sx,2.4,sz,3.4,.1,2.2,.2,0,0);for(const s of [-1,1])dB(0x5a4a38,sx+s*1.6,1.2,sz-.9,.1,2.4,.1);sbox(sx,sz,3,1.4,1,null,0);if(SR()<.4)lootBox(sx,sz+1.2,'crate')}}
function trainCar(x,z,len=14,col=0x3a4a5a){dB(col,x,2.1,z,3,2.8,len,0,0,0,true);dB(0x1a1a1a,x,3.2,z,3.05,.5,len-1);dB(0x2a2a2a,x,.5,z,2.4,.8,len-2,0,0,0,true);sbox(x,z,3,len,3.4,null,0)}
function rails(x,z0,z1){dB(0x5a5048,x,.05,(z0+z1)/2,3.4,.1,Math.abs(z1-z0));for(const s of [-.72,.72])dB(0x8a8a88,x+s,.15,(z0+z1)/2,.1,.12,Math.abs(z1-z0),0,0,0,true)}
function waterfall(x,z,w,h){const m=new T.Mesh(new T.PlaneGeometry(w,h),new T.MeshBasicMaterial({color:0xa8d8e8,transparent:true,opacity:.55,depthWrite:false,side:T.DoubleSide}));m.position.set(x,h/2,z);addObj(m);(W.falls||(W.falls=[])).push(m)}
function bars(x,z,w,alongX){for(let i=0;i<w/.3;i++){const o=-w/2+i*.3;dC(0x6a6a6a,x+(alongX?o:0),1.3,z+(alongX?0:o),.03,.03,2.6,0,0,0,6,true)}sbox(x,z,alongX?w:.12,alongX?.12:w,2.6,null,0,{shoot:false})}
function canopy(x,z,w,d,h){for(const [a,b] of [[-w/2+.4,-d/2+.4],[w/2-.4,-d/2+.4],[-w/2+.4,d/2-.4],[w/2-.4,d/2-.4]])sbox(x+a,z+b,.4,.4,h,'metal',0,{uv:1});sbox(x,z,w,d,.4,'yellow',h);dB(0xd8d0c0,x,h-.05,z,w-.2,.06,d-.2)}

/* ---------- water (swimmable basin) ---------- */
function waterBasin(x0,z0,x1,z1,bed=-9){(W.water||(W.water=[])).push({minX:x0,maxX:x1,minZ:z0,maxZ:z1,surf:-.35,bed});
  sbox((x0+x1)/2,(z0+z1)/2,x1-x0,z1-z0,.6,'rock',bed-.6);
  const m=new T.Mesh(new T.PlaneGeometry(x1-x0,z1-z0),new T.MeshStandardMaterial({color:THEME.water||0x2c5866,transparent:true,opacity:.72,roughness:.15,metalness:.2,depthWrite:false}));m.rotation.x=-Math.PI/2;m.position.set((x0+x1)/2,-.35,(z0+z1)/2);m.renderOrder=3;addObj(m);
  // walls of the basin so the void isn't visible
  dB(0x3a4a48,(x0+x1)/2,bed/2,z0,x1-x0,-bed,.3);dB(0x3a4a48,(x0+x1)/2,bed/2,z1,x1-x0,-bed,.3);dB(0x3a4a48,x0,bed/2,(z0+z1)/2,.3,-bed,z1-z0);dB(0x3a4a48,x1,bed/2,(z0+z1)/2,.3,-bed,z1-z0)}
function waterAt(x,z){if(!W||!W.water)return null;for(const w of W.water)if(x>w.minX&&x<w.maxX&&z>w.minZ&&z<w.maxZ)return w;return null}
function groundPlanes(h){const g=MAT.ground,S=h*2+260;if(!W.water||!W.water.length){const m=new T.Mesh(new T.PlaneGeometry(S,S),g);m.rotation.x=-Math.PI/2;m.receiveShadow=true;scene.add(m);W.meshes.push(m);return}
  const w=W.water[0],E=S/2;const rects=[[-E,-E,E,w.minZ],[-E,w.maxZ,E,E],[-E,w.minZ,w.minX,w.maxZ],[w.maxX,w.minZ,E,w.maxZ]];
  for(const [a,b,c,d] of rects){if(c-a<=0||d-b<=0)continue;const m=new T.Mesh(new T.PlaneGeometry(c-a,d-b),g);m.rotation.x=-Math.PI/2;m.position.set((a+c)/2,0,(b+d)/2);m.receiveShadow=true;scene.add(m);W.meshes.push(m)}}

/* ---------- clock (2 game-minutes per real second) & weather ---------- */
const TOD_START={day:9,dusk:17,night:21.5,cycle:7};
const WEATHERS={clear:{name:'晴朗',fog:1,sun:1},cloudy:{name:'多雲',fog:.8,sun:.6},rain:{name:'下雨',fog:.6,sun:.4,rain:1},storm:{name:'雷雨',fog:.45,sun:.25,rain:2,thunder:1},fog:{name:'濃霧',fog:.3,sun:.5},snow:{name:'下雪',fog:.55,sun:.6,snow:1},sand:{name:'沙塵暴',fog:.32,sun:.55,sand:1}};
function dailyWeather(mapId){const d=new Date();const key=d.getFullYear()*10000+(d.getMonth()+1)*100+d.getDate();let s=key;for(const c of mapId)s=(s*31+c.charCodeAt(0))>>>0;const r=mulberry(s)();
  if(mapId==='frost')return r<.6?'snow':r<.85?'cloudy':'clear';if(mapId==='desert')return r<.35?'sand':r<.85?'clear':'cloudy';if(mapId==='forest')return r<.4?'fog':r<.6?'rain':r<.85?'clear':'cloudy';
  return r<.45?'clear':r<.65?'cloudy':r<.8?'rain':r<.9?'fog':'storm'}
const _c1=new T.Color(),_c2=new T.Color(),_c3=new T.Color();
function todParams(hr){const th=THEME;// weights for night / dusk / day
  const h=((hr%24)+24)%24;let day=0,dusk=0;
  if(h>=7&&h<17)day=1;else if(h>=5&&h<7){const t=(h-5)/2;dusk=Math.sin(t*Math.PI)*1;day=Math.max(0,t*2-1)}else if(h>=17&&h<20){const t=(h-17)/3;day=Math.max(0,1-t*2);dusk=Math.sin(t*Math.PI)}
  const night=Math.max(0,1-day-dusk);return{day,dusk,night,h}}
function applyClock(hr){const th=THEME,wk=todParams(hr),wx=WEATHERS[W.weather||'clear'];
  const mix=(a,b,c)=>{_c1.setHex(a).multiplyScalar(wk.night);_c2.setHex(b).multiplyScalar(wk.dusk);_c3.setHex(c).multiplyScalar(wk.day);return _c1.add(_c2).add(_c3)};
  const sky=mix(th.sky.night,th.sky.dusk,th.sky.day);if(wx.rain||wx.fog<.5)sky.lerp(_c2.setHex(wk.night>.5?0x0c1016:0x8a9298),.45);if(wx.sand)sky.lerp(_c2.setHex(0xc89a5a),.6);
  scene.background.copy(sky);scene.fog.color.copy(sky);
  const fn=8*wk.night+25*wk.dusk+40*wk.day,ff=(85*wk.night+170*wk.dusk+280*wk.day)*wx.fog;scene.fog.near=fn*Math.min(1,wx.fog*1.4);scene.fog.far=Math.max(40,ff);
  hemi.color.copy(mix(0x4a5a88,0xf0b080,th.snowy?0xe6eef8:0xe6d6b8));hemi.groundColor.copy(mix(0x0a0a10,0x3a2a2a,th.snowy?0x8a96a6:0x4a3d2e));
  const hi=.34*wk.night+.55*wk.dusk+.8*wk.day;if(!hemi.userData.nv)hemi.intensity=hi;else hemi.userData.nv=hi;
  sun.color.copy(mix(0x8aa4ff,0xff8a4a,th.snowy?0xfff4e8:0xffd6a3));sun.intensity=(.3*wk.night+1.45*wk.dusk+1.75*wk.day)*wx.sun*(W.flashT>0?3:1);
  const a=((wk.h-6)/12)*Math.PI;const el=Math.sin(a);sunDir.set(Math.cos(a)*90,Math.max(.25,el)*95+5,40).normalize();if(wk.night>.6)sunDir.set(-50,90,60).normalize();
  renderer.toneMappingExposure=1.15*wk.night+1*wk.dusk+(th.snowy?.95:1.05)*wk.day;
  if(stars)stars.visible=wk.night>.5&&!wx.rain&&wx.fog>.5;
  const lamp=wk.night>.4?1:wk.dusk>.5?.5:0;if(W.lampOn!==lamp){W.lampOn=lamp;W.glows.forEach(g=>g.visible=lamp>0);if(W.bulbMat)W.bulbMat.color.setHex(lamp?0xffe2b0:0x6b6458)}
  W.tod=wk.night>.5?'night':wk.dusk>.4?'dusk':'day'}
function initClock(tod){M.clock=TOD_START[tod]||9;M.clockRun=M.mode==='extract'&&PF.settings.cycle!==false;W.weather=M.cfg&&M.cfg.weather||dailyWeather(W.id);if(M.event==='fog')W.weather='fog';
  if(!stars)applyTOD('night');applyClock(M.clock);initWeatherFX()}
function clockStr(){const h=Math.floor(M.clock%24),m=Math.floor((M.clock%1)*60);return String(h).padStart(2,'0')+':'+String(m).padStart(2,'0')}
function updateClock(dt){if(M.clockRun){M.clock+=dt*2/60;}if(M.frame%10===0||W.flashT>0)applyClock(M.clock);if(W.flashT>0)W.flashT-=dt;updateWeatherFX(dt)}
// precipitation
let wxPts=null,wxSnd=null;
function initWeatherFX(){if(wxPts){scene.remove(wxPts);wxPts.geometry.dispose();wxPts=null}if(wxSnd){try{wxSnd.stop()}catch(e){}wxSnd=null}
  const wx=WEATHERS[W.weather];if(!wx.rain&&!wx.snow&&!wx.sand)return;const n=wx.rain?2600*wx.rain:wx.snow?2200:1800;const a=new Float32Array(n*3);for(let i=0;i<n*3;i++)a[i]=rnd(-30,30);
  const g=new T.BufferGeometry();g.setAttribute('position',new T.BufferAttribute(a,3));
  wxPts=new T.Points(g,new T.PointsMaterial({color:wx.rain?0x9ab0c0:wx.snow?0xffffff:0xd8a868,size:wx.rain?.06:wx.snow?.12:.09,transparent:true,opacity:wx.rain?.55:.85,depthWrite:false}));wxPts.frustumCulled=false;scene.add(wxPts);wxPts.userData.kind=wx.rain?'rain':wx.snow?'snow':'sand';
  if(ac&&(wx.rain||wx.sand)){const b=ac.createBuffer(1,ac.sampleRate*2,ac.sampleRate),d=b.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;const s=ac.createBufferSource();s.buffer=b;s.loop=true;const f=ac.createBiquadFilter();f.type=wx.rain?'highpass':'bandpass';f.frequency.value=wx.rain?1800:500;const gn=ac.createGain();gn.gain.value=.05*(wx.rain||1);s.connect(f).connect(gn).connect(master);s.start();wxSnd=s}}
function updateWeatherFX(dt){if(!wxPts)return;const p=wxPts.geometry.attributes.position,a=p.array,k=wxPts.userData.kind,c=camera.position;const vy=k==='rain'?-26:k==='snow'?-2.2:-.6,vx=k==='sand'?14:k==='snow'?.6:1.5;
  for(let i=0;i<a.length;i+=3){a[i]+=vx*dt;a[i+1]+=vy*dt;if(k==='snow'){a[i]+=Math.sin(M.t+i)*.01}
    if(a[i+1]<-2||a[i]>30){a[i]=rnd(-30,30);a[i+1]=rnd(5,28);a[i+2]=rnd(-30,30)}}
  p.needsUpdate=true;wxPts.position.set(c.x,c.y-6,c.z);if(waterAt(c.x,c.z)&&c.y<-.35)wxPts.visible=false;else wxPts.visible=true;
  const wx=WEATHERS[W.weather];if(wx.thunder&&Math.random()<dt*.06){W.flashT=.15;later(rnd(.5,2.5),()=>boomSnd(.5))}}

/* ---------- swim / breath ---------- */
function updateSwim(dt){const w=waterAt(P.pos.x,P.pos.z);const inW=w&&P.pos.y<w.surf-.5;P.swim=!!inW;const eye=P.pos.y+P.eyeH();const under=w&&eye<w.surf;
  if(P.breath===undefined)P.breath=30;if(under){P.breath-=dt;if(P.breath<=0){P.breath=0;P.drownT=(P.drownT||0)-dt;if(P.drownT<=0){P.drownT=1;damagePlayer(10,null,{gas:true,how:'溺水'})}}}else P.breath=Math.min(30,P.breath+dt*6);
  const fogUnder=!!under;if(fogUnder!==P._fogU){P._fogU=fogUnder;$('underwater').hidden=!fogUnder}
  if(fogUnder){scene.fog.color.setHex(0x1a4a5a);scene.background.setHex(0x1a4a5a);scene.fog.near=1;scene.fog.far=28}
  return inW}

/* ================= NEW MAPS ================= */
function stdExtracts(h,list){for(const [t,x,z,n] of list)extractPoint(t,x,z,n)}
function filler(h,n,keep){for(let i=0;i<n;i++){const x=srnd(-h+16,h-16),z=srnd(-h+16,h-16);if(keep&&keep.some(k=>Math.hypot(k[0]-x,k[1]-z)<k[2]))continue;if(!isFree(x,z,9))continue;
  const r=SR();if(r<.45)house(x,z,srnd(8,13),srnd(7,11),{h:srnd(3.6,4.6),loot:1,ladder:SR()<.25});else if(r<.7)yard(x,z);else if(r<.85)field(x,z);else rock(x,z,srnd(4,9),srnd(4,9),srnd(1.5,4))}}

/* 長風谷 valley */
function genValley(){const h=W.half;W.spawnsP=[{x:-h+12,z:-h+12},{x:h-12,z:-h+12},{x:h-12,z:h-40},{x:-h+12,z:h-40}];
  road(0,0,8,h*2-6);road(0,-40,h*2-6,8);road(-60,60,8,140);
  // beach & sea (south)
  sbox(0,h-14,h*2-6,24,.05,'sand',0,{solid:false,shoot:false,uv:4});waterBasin(-h+3,h-20,h-3,h-3,-5);
  // 飯店
  landmark('海景飯店',-80,-90,24);{const b=building(-80,-90,30,18,{floors:2,doors:['s','n','e'],loot:3,lootTypes:['safe','crate','pc','med'],mat:'wallC'});dB(0x4aa0c8,-80,.08,-74,12,.1,6);sbox(-80,-74,13,7,.4,'dark',0,{solid:false});elevator(-96.6,-84,2.4,2.4,0,b.h+.02);W.enemySpots.push({x:-80,z:-92})}
  // 加油站
  landmark('公路加油站',20,-40,16);canopy(20,-46,16,8,5);for(const s of [-4,0,4])sbox(20+s,-46,.8,.6,1.4,'yellow',0);house(20,-32,12,8,{flat:true,loot:2,lootTypes:['crate','med'],doors:['s']});
  // 莊園
  landmark('橡木莊園',100,-100,26);{building(100,-100,22,16,{floors:2,doors:['s'],loot:3,lootTypes:['safe','vault','crate'],mat:'wallB',locked:'B',vault:true});gable(100,-100,22,16,6.9,0x5a3022);for(const [a,b,c,d] of [[86,-116,114,-116],[86,-84,95,-84],[105,-84,114,-84],[86,-116,86,-84],[114,-116,114,-84]])fence(a,b,c,d);W.bossSpot={x:100,z:-98}}
  // 墜機點
  landmark('墜機點',-110,20,20);{dC(0xc8c8c0,-110,2,20,2.2,2.2,22,0,.4,Math.PI/2,16,true);dB(0xb8b8b0,-104,1,24,16,.3,4,0,.4,.1,true);dB(0xb8b8b0,-117,1.5,14,12,.3,3.6,0,.4,-.2,true);sbox(-110,20,6,20,4,null,0);for(let i=0;i<10;i++)puff({x:-110+rnd(-6,6),y:.5,z:20+rnd(-6,6)},1,3,3,0x3a3530,.6,.3,.3);
    lootBox(-104,28,'safe');lootBox(-114,12,'weapon');W.enemySpots.push({x:-104,z:24})}
  // 村莊
  landmark('溪畔村莊',-60,80,30);for(let i=0;i<7;i++){const x=-60+srnd(-24,24),z=80+srnd(-20,20);if(isFree(x,z,7))house(x,z,srnd(8,11),srnd(7,9),{h:3.8,loot:1})}
  // 雷達站
  landmark('山頂雷達站',120,40,18);radarDish(120,40);radarDish(132,30);house(112,52,12,9,{flat:true,loot:2,lootTypes:['pc','pc','safe']});lattice(128,52,3,20);searchlight(128,20,50,Math.PI);
  // 伐木場
  landmark('伐木場',-130,-40,20);{for(let i=0;i<5;i++)logPile(-136+srnd(-10,10),-40+srnd(-12,12));const b=building(-120,-46,14,10,{h:5,doors:['w'],loot:1,lootTypes:['weapon','crate'],mat:'wood'});gable(-120,-46,14,10,5.3,0x5a4630,true)}
  // 鑽井區
  landmark('鑽井區',60,40,22);derrick(52,30);derrick(70,46);tank(52,52,4,6);tank(64,26,3.5,5);for(let i=0;i<3;i++)barrel(58+i*1.2,40,true);
  // 海灘要塞
  landmark('海灘要塞',60,h-30,22);{const x=60,z=h-34;sbox(x,z,16,10,3.4,'dark',0);sbox(x,z,15,9,.3,null,3.4);for(const s of [-1,1])sandbag(x+s*10,z-4,6,true);turret(x-4,z-6);turret(x+4,z-6);lootBox(x,z-6.5,'weapon');W.enemySpots.push({x,z:z-8});ladder(x+8.2,z,'x+',3.7)}
  // 山頂遺蹟 (raised plateau with ramp stairs)
  landmark('山頂遺蹟',-120,-120,18);{sbox(-120,-120,22,22,4,'rock',0);stairs(-120,-108,'z-',3,4,'rock');pillarRuin(-120,-120,8,7);lootBox(-120,-120,'vault',4);W.enemySpots.push({x:-118,z:-118})}
  // 瀑布後軍火庫
  landmark('瀑布軍火庫',-40,-140,18);{for(let x=-62;x<=-18;x+=6)rock(x,-152,6.5,8,12);waterfall(-40,-147.6,10,12);sbox(-40,-150,10,4,.3,null,4.2);sbox(-45,-150,.4,4,4,'rock',0);sbox(-35,-150,.4,4,4,'rock',0);sbox(-40,-152,10,.4,4,'rock',0);
    lootBox(-42,-150.5,'weapon');lootBox(-38,-150.5,'weapon');W.enemySpots.push({x:-40,z:-144})}
  // 列車站 (timed extraction)
  landmark('長風列車站',150,-20,22);{rails(158,-h+8,h-30);sbox(152,-20,4,40,1,'floor',0);canopy(152,-20,4,24,4);trainCar(158,-36);trainCar(158,-8,12,0x6a3a2a);house(144,-20,8,14,{flat:true,loot:1});const e=extractPoint('task',152,-20,'列車撤離');e.task={kind:'window',from:[6,12,18],dur:1,label:'列車每 6 小時整點進站，停靠 1 小時'}}
  // forests & filler
  forest(110,-h+12,-h+12,-h/3,h-40,1);forest(70,h/3,-h+12,h-12,h/3,1);propScatter(70,['car','barrels','crates','fence','rock','log']);filler(h,70,[[-80,-90,24],[100,-100,22],[-110,20,18],[-60,80,30],[120,40,20],[-130,-40,20],[60,40,22],[-120,-120,18],[-40,-140,18],[150,-20,24]]);
  for(let i=0;i<8;i++)wreckCar(srnd(-10,10),srnd(-h+20,h-40),SR()<.5);
  stdExtracts(h,[['std',-h+6,0,'西側山道'],['std',h-6,60,'東側公路'],['std',0,-h+6,'北方隘口'],['paid',-150,100,'走私漁船'],['power',100,-h+6,'電動閘門'],['heli',-20,60,'直升機坪'],['nobag',-150,-150,'山壁裂縫']]);
  W.powerGate=dbox(100,-h+1,10,1,5,'metal',0);powerSwitch(100.6,1.3,-91.9,'z+');ammoStation(-2,-30);ammoStation(30,-46);
  scatter(140);W.flagsPos=[[0,-40,'A'],[-80,-90,'B'],[60,40,'C'],[-60,80,'D'],[120,40,'E']];W.basePos={1:{x:-h+14,z:0},2:{x:h-14,z:0}};W.relicPos={x:20,z:-40};W.holdPos={x:20,z:-40};W.duelSpots=[{x:-10,z:-60},{x:30,z:-60}]}

/* 星港發射場 space base */
function genSpace(){const h=W.half;W.pave=true;W.spawnsP=[{x:-h+14,z:h-14},{x:h-14,z:h-14},{x:-h+14,z:-60},{x:h-14,z:-60}];
  road(0,0,10,h*2-6);road(0,40,h*2-6,10);road(0,-80,h*2-6,10);
  // 碼頭 (north water)
  waterBasin(-h+3,-h+3,h-3,-h+26,-6);for(const x of [-60,0,60]){sbox(x,-h+18,6,20,.5,'wood',-.2);for(let i=0;i<4;i++)dC(0x5a4630,x+(i%2?2.6:-2.6),-2,-h+10+(i>1?10:0),.25,.25,4,0,0,0,8)}landmark('補給碼頭',0,-h+30,24);for(const x of [-30,30])container(x,-h+36,true);
  // 發射台 + 斷橋
  landmark('發射台',-90,-30,30);rocket(-90,-30);sbox(-90,-30,24,24,.4,'metal',0,{solid:false});{for(let i=0;i<6;i++)sbox(-90+10+i*6,-30,6,4,.4,'metal',9);sbox(-90+10+6*6+6,-30,4,4,.4,'metal',9);stairs(-40,-34,'x-',3,9,'metal');landmark('斷橋',-58,-30,10)}
  // 離心機室
  landmark('離心機室',70,-30,20);{const b=building(70,-30,24,18,{h:7,doors:['s','w'],loot:2,lootTypes:['pc','safe','crate'],mat:'wallA'});const g=new T.TorusGeometry(5,.6,10,28);dGeo(g,0xd8d8d0,70,3.2,-30,Math.PI/2,0,0,1,1,1,true);dC(0x8a8a88,70,3.2,-30,.8,.8,6,0,0,0,10,true);W.spin=W.spin||[]}
  // 中控室 + 密室
  landmark('中控室',0,20,22);{const b=building(0,14,26,16,{floors:2,doors:['n','s','e','w'],loot:3,lootTypes:['pc','pc','safe','crate'],mat:'dark'});building(0,28,8,6,{h:3.5,doors:['n'],locked:'R',vault:true,loot:1,lootTypes:['vault'],mat:'dark'});W.bossSpot={x:2,z:14};landmark('中控密室',0,28,6);
    const e=extractPoint('task',-40,90,'大橋撤離');e.task={kind:'hold',x:0,z:14,r:6,need:60,label:'在中控室坚守電腦 60 秒，開啟大橋撤離'}}
  // 藍室 / 黑室
  landmark('藍室',-60,60,12);building(-60,60,12,10,{h:4,doors:['e'],locked:'B',vault:true,loot:2,lootTypes:['safe','vault'],mat:'wallB'});
  landmark('黑室',60,60,12);building(60,60,12,10,{h:4,doors:['w'],locked:'R',vault:true,loot:2,lootTypes:['vault','vault'],mat:'dark',mine:true});
  // 宿舍
  landmark('宿舍區',-110,90,26);for(let i=0;i<4;i++)house(-125+i*10,90+(i%2?8:-8),8,12,{floors:i===1?2:1,h:4,loot:1,lootTypes:['crate','med','pc'],mat:'wallC',flat:true});
  // 牢房
  landmark('牢房',110,90,20);{building(110,90,22,14,{h:4.2,doors:['w'],loot:2,lootTypes:['crate','med'],mat:'dark'});for(let i=0;i<4;i++)bars(102+i*5,94,4,true)}
  // 電腦室
  landmark('電腦室',110,-90,16);house(110,-90,16,12,{flat:true,loot:3,lootTypes:['pc','pc','pc','safe'],mat:'wallA'});
  // 噴泉廣場 + 雙閘撤離
  landmark('噴泉廣場',0,120,14);{dC(0xb8b8b0,0,.4,120,4,4.3,.8,0,0,0,24);dC(0x6aa8c8,0,.82,120,3.7,3.7,.04,0,0,0,24);dC(0xb8b8b0,0,1.6,120,.4,.5,2.4,0,0,0,10);sbox(0,120,7,7,.8,null,0);
    const e=extractPoint('task',0,140,'噴泉廣場撤離');e.task={kind:'switches',n:2,wait:90,label:'拉下兩個閘門開關後等待 90 秒'};const s1=powerSwitch(-60.6,1.3,55.1,'x-');s1.task=e;const s2=powerSwitch(60.6,1.3,55.1,'x+');s2.task=e}
  for(let i=0;i<10;i++){const x=srnd(-h+20,h-20),z=srnd(-h+40,h-20);if(isFree(x,z,4))tank(x,z,srnd(2,3.5),srnd(4,7))}
  W.pave=false;propScatter(80,['car','barrels','crates','sand','container','tank','lamp']);filler(h,45,[[-90,-30,34],[70,-30,20],[0,20,24],[-60,60,12],[60,60,12],[-110,90,26],[110,90,22],[110,-90,16],[0,120,14]]);
  for(const [x,z] of [[-h+30,h-30],[h-30,h-30]])searchlight(x,8,z,0);
  stdExtracts(h,[['std',-h+6,40,'西側圍牆缺口'],['std',h-6,40,'東側貨運門'],['nobag',h-30,-50,'丟包通道'],['paid',-h+30,-50,'接駁快艇'],['heli',90,130,'星港直升機坪']]);
  W.powerGate=null;ammoStation(8,40);ammoStation(-8,-80);scatter(80);
  W.flagsPos=[[0,20,'A'],[-90,-30,'B'],[70,-30,'C'],[-110,90,'D'],[110,90,'E']];W.basePos={1:{x:-h+14,z:40},2:{x:h-14,z:40}};W.relicPos={x:0,z:40};W.holdPos={x:0,z:14};W.duelSpots=[{x:-20,z:-80},{x:20,z:-80}]}

/* 怒濤監獄 prison island */
function genPrison(){const h=W.half;W.pave=true;W.spawnsP=[{x:h-14,z:-h+14},{x:h-14,z:h-14},{x:30,z:h-14},{x:30,z:-h+14}];
  // sea + trench on the west
  waterBasin(-h+3,-h+3,-60,h-3,-12);landmark('海溝',-110,0,40);
  for(let i=0;i<31;i++){const x=srnd(-h+12,-68),z=srnd(-h+12,h-12);const c=lootBox(x,z,spick(['crate','crate','safe','pc']),-12);if(c){c.type=c.type;c.shell=true}}
  for(let i=0;i<20;i++){const x=srnd(-h+12,-68),z=srnd(-h+12,h-12);sbox(x,z,srnd(2,6),srnd(2,6),srnd(1,5),'rock',-12)}
  // outer wall
  for(const [x0,z0,x1,z1] of [[-50,-120,140,-120],[-50,120,140,120],[-50,-120,-50,120],[140,-120,140,120]]){const ax=z0===z1;if(ax)wallRun('x',z0,x0,x1,0,7,'dark',[{c:45,w:4,b:0,t:4}]);else wallRun('z',x0,z0,z1,0,7,'dark',[{c:0,w:4,b:0,t:4}])}
  for(const [x,z] of [[-50,-120],[140,-120],[-50,120],[140,120]]){lattice(x,z,4,12,0x4a4a46);searchlight(x,13,z,Math.atan2(45-x,0-z))}
  // 中央放風場
  landmark('中央放風場',45,0,24);{for(const [a,b] of [[25,-20],[65,-20],[25,20],[65,20]])sbox(a,b,1,1,4,'dark',0);fence(25,-20,65,-20);fence(25,20,65,20);fence(25,-20,25,-6);fence(25,6,25,20);fence(65,-20,65,20);lootBox(45,0,'vault');lootBox(43,2,'safe');W.bossSpot={x:45,z:-3};turret(40,-16);turret(50,16)}
  // cell blocks
  for(const z of [-70,70]){landmark(z<0?'北區牢房':'南區牢房',45,z,20);building(45,z,50,16,{floors:2,doors:['w','e'],loot:3,lootTypes:['crate','med','crate','pc'],mat:'wallA'});for(let i=0;i<8;i++)bars(24+i*6,z+(z<0?6:-6),5,true)}
  // 醫務翼 (blue card) with green decrypt computer
  landmark('醫務翼',110,-60,18);building(110,-60,22,14,{h:4.4,doors:['w'],locked:'B',loot:3,lootTypes:['med','med','safe'],mat:'wallC'});
  landmark('辦公區',110,60,18);{building(110,60,22,14,{floors:2,doors:['w'],loot:3,lootTypes:['pc','safe','crate'],mat:'wallB'})}
  // 管道閘門控制室 + decrypt computer requirement
  landmark('管道閘門控制室',-20,-90,14);{building(-20,-90,14,10,{h:4,doors:['e'],loot:1,lootTypes:['pc'],mat:'dark'});for(let i=0;i<5;i++)dPipe(0x6a6a62,-27,1+i*.5,-84,-60,1+i*.5,-84,.25);const sw=powerSwitch(-26.6,1.3,-90,'x+');sw.needDecrypt=true;
    const tm={kind:'decrypt',x:110,z:-56,need:15,label:'在醫務翼解密綠色電腦（15 秒）才能拉閘'};W.terms=W.terms||[];W.terms.push(tm);dB(0x2a8a3a,110,1,-56,.8,.6,.1);sbox(110,-56.4,1,.6,1.1,'metal',0)}
  // underground passages A/B/C (covered corridors)
  for(const [n,z] of [['A',-40],['B',40],['C',-100]]){landmark('地下通道'+n,5,z,10);sbox(5,z-2.6,30,.4,3.2,'dark',0);sbox(5,z+2.6,30,.4,3.2,'dark',0);sbox(5,z,30,5.6,.4,'dark',3.2);lamp(5,z)}
  landmark('直升機接應區',110,0,14);
  stdExtracts(h,[['std',h-6,-80,'東側碼頭'],['std',h-6,80,'補給船'],['power',-30,-112,'排水管閘門'],['heli',110,0,'直升機接應區'],['nobag',140,-140,'海蝕洞'],['paid',30,h-10,'獄警通勤船']]);
  W.powerGate=dbox(-30,-116,6,1,5,'metal',0);
  propScatter(50,['barrels','crates','sand','fence','lamp','container']);filler(h,20,[[45,0,70],[110,-60,18],[110,60,18],[-20,-90,14],[110,0,14]]);ammoStation(30,-30);ammoStation(60,30);scatter(70);
  W.flagsPos=[[45,0,'A'],[45,-70,'B'],[45,70,'C'],[110,-60,'D'],[110,60,'E']];W.basePos={1:{x:h-14,z:-140},2:{x:h-14,z:140}};W.relicPos={x:45,z:0};W.holdPos={x:45,z:0};W.duelSpots=[{x:30,z:-30},{x:60,z:30}]}

/* 餘燼核電廠 nuclear plant */
function genNuclear(){const h=W.half;W.pave=true;W.spawnsP=[{x:-h+14,z:-h+14},{x:-h+14,z:h-14},{x:h-40,z:h-14},{x:h-40,z:-h+14}];
  road(0,0,h*2-6,10);road(-40,0,10,h*2-6);
  waterBasin(h-26,-h+3,h-3,h-3,-6);landmark('卸料碼頭',h-34,0,20);for(const z of [-30,0,30])container(h-36,z,false);sbox(h-30,0,6,60,.5,'metal',0,{solid:false});
  landmark('1號反應爐',40,-50,24);reactorDome(40,-50,12);{const b=building(40,-30,24,12,{floors:2,doors:['s','w'],loot:3,lootTypes:['pc','safe','crate'],mat:'wallA'});landmark('主控室',40,-30,10);building(54,-30,6,8,{h:3.6,doors:['w'],locked:'R',vault:true,loot:1,lootTypes:['vault'],mat:'dark'});W.bossSpot={x:40,z:-28}}
  landmark('冷卻塔',-80,-80,26);coolingTower(-80,-80,13,34);coolingTower(-80,-30,11,28);lootBox(-80,-80,'vault');W.enemySpots.push({x:-68,z:-80});landmark('冷卻塔底',-80,-80,8);
  landmark('行政樓',-80,70,20);{building(-80,70,26,16,{floors:2,doors:['e','n'],loot:3,lootTypes:['pc','crate','safe'],mat:'wallB'});building(-80,88,10,8,{h:3.4,doors:['s'],locked:'B',loot:2,lootTypes:['pc','safe'],mat:'dark'});landmark('地下機房',-80,88,6)}
  landmark('污水淨化站',60,80,22);for(const [x,z] of [[50,72],[70,72],[50,92],[70,92]])tank(x,z,6,3.2);
  landmark('防火牆機房',0,60,14);house(0,60,16,12,{flat:true,loot:3,lootTypes:['pc','pc','safe'],mat:'dark'});
  landmark('廢料庫',100,-90,22);{for(let i=0;i<24;i++){const x=100+srnd(-14,14),z=-90+srnd(-14,14);barrel(x,z,SR()<.3)}fence(84,-106,116,-106);fence(84,-74,116,-74);lootBox(100,-90,'safe');W.radZones=[{x:100,z:-90,r:16,dps:6}];gasZone(100,-90,16)}
  W.radZones.push({x:40,z:-50,r:20,dps:4});for(let i=0;i<6;i++){const x=srnd(-h+20,h-40),z=srnd(-h+20,h-20);if(isFree(x,z,4))silo(x,z,3,10)}
  for(let i=0;i<14;i++)dPipe(0x8a8a82,-40+i*5,4,-h+20,-40+i*5,4,-60,.4);
  propScatter(80,['car','barrels','crates','sand','container','tank','fence','lamp']);filler(h,50,[[40,-50,30],[-80,-60,40],[-80,75,24],[60,80,22],[0,60,14],[100,-90,22],[h-34,0,20]]);
  stdExtracts(h,[['std',-h+6,0,'西側檢查哨'],['std',0,h-6,'南側停車場'],['std',0,-h+6,'北側鐵路'],['paid',h-34,-h+30,'運輸駁船'],['power',-40,h-6,'電動閘門'],['heli',-20,-110,'直升機坪'],['nobag',-h+30,-h+30,'排水涵洞']]);
  W.powerGate=dbox(-40,h-1,10,1,5,'metal',0);powerSwitch(-66.6,1.3,70,'x+');ammoStation(10,8);ammoStation(-48,-10);scatter(110);
  W.flagsPos=[[0,0,'A'],[40,-30,'B'],[-80,70,'C'],[60,80,'D'],[-80,-30,'E']];W.basePos={1:{x:-h+14,z:0},2:{x:h-40,z:0}};W.relicPos={x:0,z:0};W.holdPos={x:40,z:-30};W.duelSpots=[{x:-20,z:20},{x:20,z:20}]}

/* 霧林 forest */
function genForest(){const h=W.half;W.spawnsP=[{x:-h+12,z:-h+12},{x:h-12,z:-h+12},{x:h-12,z:h-12},{x:-h+12,z:h-12}];
  road(0,0,6,h*2-6);road(0,30,h*2-6,6);
  waterBasin(-14,-h+3,14,-20,-4);for(const z of [-60,-110])sbox(0,z,5,30,.5,'wood',-.1);landmark('林間溪流',0,-80,20);
  landmark('伐木營地',-90,-70,24);{for(let i=0;i<7;i++)logPile(-90+srnd(-14,14),-70+srnd(-14,14));house(-96,-60,14,10,{h:4.5,loot:2,lootTypes:['weapon','crate'],mat:'wood',roofCol:0x4a3a28});house(-80,-82,10,8,{h:4,loot:1,mat:'wood'})}
  landmark('獵人小屋群',90,-80,24);for(let i=0;i<5;i++){const x=90+srnd(-18,18),z=-80+srnd(-16,16);if(isFree(x,z,6))house(x,z,7,7,{h:3.4,mat:'wood',loot:1,lootTypes:['crate','med','weapon'],roofCol:0x3a3022})}
  landmark('護林塔',-40,90,12);{lattice(-40,90,4,18,0x6a5038);sbox(-40,90,6,6,.3,'wood',18);elevator(-40,86.6,2.2,2.2,0,18.3);zipline(-39,18.3,91,-90,0,120);searchlight(-38,19,92,Math.PI)}
  landmark('森林營地',60,80,22);for(let i=0;i<6;i++)tent(60+srnd(-14,14),80+srnd(-12,12));
  landmark('岩洞',-110,60,16);{for(let i=0;i<10;i++){const a=i/10*TAU;if(i===0)continue;rock(-110+Math.cos(a)*9,60+Math.sin(a)*9,6,6,7)}sbox(-110,60,18,18,.8,'rock',7);lootBox(-112,60,'vault');lootBox(-106,62,'weapon');W.bossSpot={x:-110,z:58}}
  landmark('林務局',40,0,18);{building(40,0,22,14,{floors:2,doors:['w','s'],loot:3,lootTypes:['pc','safe','crate'],mat:'wallC',ladder:true});gable(40,0,22,14,7,0x2a3a2a)}
  forest(420,-h+10,-h+10,h-10,h-10,1.15);propScatter(50,['log','rock','tent','crates','car']);filler(h,25,[[-90,-70,24],[90,-80,24],[-40,90,10],[60,80,22],[-110,60,16],[40,0,18]]);
  stdExtracts(h,[['std',-h+6,30,'西側林道'],['std',h-6,30,'東側伐木道'],['std',30,h-6,'南側獵徑'],['paid',-h+30,-h+30,'獵人卡車'],['nobag',h-30,-h+30,'獸徑'],['heli',40,30,'林務局直升機坪']]);
  ammoStation(6,20);scatter(60);
  W.flagsPos=[[40,0,'A'],[-90,-70,'B'],[90,-80,'C'],[60,80,'D'],[-110,60,'E']];W.basePos={1:{x:-h+14,z:30},2:{x:h-14,z:30}};W.relicPos={x:0,z:30};W.holdPos={x:40,z:0};W.duelSpots=[{x:-20,z:40},{x:20,z:40}]}

/* 赤沙綠洲 desert */
function genDesert(){const h=W.half;W.spawnsP=[{x:-h+12,z:-h+12},{x:h-12,z:-h+12},{x:h-12,z:h-12},{x:-h+12,z:h-12}];
  road(0,0,h*2-6,8);road(70,0,8,h*2-6);
  landmark('綠洲',-20,-20,22);{waterBasin(-30,-30,-10,-10,-3);for(let i=0;i<14;i++){const a=i/14*TAU;palm(-20+Math.cos(a)*15,-20+Math.sin(a)*15)}}
  landmark('土磚村',-80,40,30);for(let i=0;i<9;i++){const x=-80+srnd(-24,24),z=40+srnd(-22,22);if(isFree(x,z,6))building(x,z,srnd(7,10),srnd(7,10),{h:srnd(3.4,4.4),mat:'sand',loot:1,ladder:SR()<.4});market(-80,40)}
  landmark('沙海神殿',90,-100,26);{sbox(90,-100,30,24,1,'sand',0);sbox(90,-100,24,18,1,'sand',1);building(90,-100,16,12,{h:6,doors:['s'],mat:'sand',loot:2,lootTypes:['vault','safe'],locked:'R',vault:true});for(let i=0;i<6;i++){dC(0xd0b890,80+i*4,4,-112,.6,.7,8,0,0,0,10);sbox(80+i*4,-112,1.2,1.2,8,null,0)}W.bossSpot={x:90,z:-98}}
  landmark('輸油管線',0,-80,30);for(let i=0;i<6;i++){dPipe(0x8a7a62,-120+i*40,1.4,-80,-80+i*40,1.4,-80,.7);sbox(-100+i*40,-80,40,1.4,1.4,null,.7)}
  landmark('沙漠哨站',-110,-110,22);{for(const [x,z] of [[-122,-122],[-98,-122],[-122,-98],[-98,-98]])tower(x,z);building(-110,-110,14,10,{h:4,doors:['n','s'],mat:'dark',loot:2,lootTypes:['weapon','weapon','crate']});for(const s of [-1,1])sandbag(-110+s*9,-118,6,true);turret(-110,-118)}
  landmark('殘骸車隊',80,60,24);for(let i=0;i<8;i++)wreckCar(70+i*3.5,40+i*6,SR()<.5);for(let i=0;i<3;i++)lootBox(78+i*4,50+i*8,spick(['weapon','crate','safe']));
  landmark('峽谷',140,0,24);for(let z=-60;z<60;z+=8){rock(128,z,8,8,srnd(8,14));rock(152,z,8,8,srnd(8,14))}
  for(let i=0;i<40;i++){const x=srnd(-h+10,h-10),z=srnd(-h+10,h-10);dS(0xc8a46a,x,0,z,srnd(4,9),1,.18,1,true)}
  propScatter(70,['car','barrels','crates','palm','rock','tent']);filler(h,40,[[-20,-20,24],[-80,40,30],[90,-100,26],[-110,-110,22],[80,60,24],[140,0,26]]);
  stdExtracts(h,[['std',-h+6,0,'西側沙丘'],['std',h-6,-80,'東側公路'],['std',0,h-6,'南方駱駝道'],['paid',-h+30,h-30,'走私貨車'],['power',70,-h+6,'電動閘門'],['heli',-20,20,'綠洲直升機坪'],['nobag',h-30,h-30,'乾河床']]);
  W.powerGate=dbox(70,-h+1,10,1,5,'metal',0);powerSwitch(-103.4,1.3,-110,'x+');ammoStation(4,8);scatter(120);
  W.flagsPos=[[-20,-20,'A'],[-80,40,'B'],[90,-100,'C'],[80,60,'D'],[-110,-110,'E']];W.basePos={1:{x:-h+14,z:0},2:{x:h-14,z:0}};W.relicPos={x:0,z:0};W.holdPos={x:-20,z:-20};W.duelSpots=[{x:-10,z:10},{x:30,z:10}]}

/* 擎天塔 supertall city */
function genTower(){const h=W.half;W.pave=true;W.spawnsP=[{x:-h+12,z:-h+12},{x:h-12,z:-h+12},{x:h-12,z:h-12},{x:-h+12,z:h-12}];
  for(const c of [-100,-50,50,100]){road(c,0,9,h*2-6);road(0,c,h*2-6,9)}
  // the tower: podium mall + core + stacked segments + observation deck
  landmark('擎天塔',0,0,30);{const FH=4.2,NF=12,HW=9,top=FH*NF;
    // mall ring around the tower
    landmark('購物中心',0,24,12);for(const [x,z,w,d,dr] of [[0,24,30,10,['n','e','w']],[0,-24,30,10,['s','e','w']],[24,0,10,22,['e','n','s']],[-24,0,10,22,['w','n','s']]])building(x,z,w,d,{floors:2,doors:dr,loot:2,lootTypes:['crate','pc','safe','med'],mat:'wallA'});
    // core shell: walls per floor with windows, doors on ground floor
    for(let f=0;f<NF;f++){const y0=f*FH;const win=[];for(const c of [-6,-2,2,6])win.push({c,w:2.6,b:1,t:3.2});const door=f===0?[{c:0,w:3,b:0,t:3,door:1}]:[];
      wallRun('x',-HW,-HW-.18,HW+.18,y0,FH,'glass',f===0?door:win);wallRun('x',HW,-HW-.18,HW+.18,y0,FH,'glass',f===0?door:win);wallRun('z',-HW,-HW+.18,HW-.18,y0,FH,'glass',f===0?door:win);wallRun('z',HW,-HW+.18,HW-.18,y0,FH,'glass',f===0?door:win)}
    // floor slabs with stair hole (north strip x -7.6..-1.4) and elevator shaft (x 5..8, z 5..8)
    for(let f=1;f<=NF;f++){const y=f*FH-.25;sbox(0,-.7,18,11.4,.25,'floor',y);sbox(-2,7,14,4,.25,'floor',y);sbox(4.4,-7.6,9.2,2.8,.25,'floor',y);sbox(-8.3,-7.6,1.4,2.8,.25,'floor',y);
      if(f<NF){W.roofSpots.push({x:srnd(-5,5),z:srnd(-3,3),y:f*FH,indoor:true});if(SR()<.8)lootBox(srnd(-6,4),srnd(-4,3),spick(['crate','pc','safe','weapon','med']),f*FH);if(SR()<.5)woodCrate(srnd(-6,2),srnd(0,4),f*FH)}}
    // stacked straight stairs (thin steps) inside the north strip
    for(let f=0;f<NF;f++){const y0=f*FH,n=Math.ceil(FH/.34),rise=FH/n,run=6.2/n;for(let i=0;i<n;i++)sbox(-7.6+(i+.5)*run,-7.6,run,2.6,rise,'dark',y0+i*rise,{uv:1})}
    elevator(6.5,6.5,2.6,2.6,0,top);
    // observation deck on the roof
    const dk=top;sbox(0,0,26,26,.4,'metal',dk-.2);for(const [x,z,w,d] of [[0,-13,26,.2],[0,13,26,.2],[-13,0,.2,26],[13,0,.2,26]])sbox(x,z,w,d,1.1,'metal',dk+.2,{shoot:false});
    landmark('觀景台',0,0,10);W.roofSpots.push({x:-4,z:4,y:dk+.2,roof:true,tower:true});lootBox(4,-4,'vault',dk+.2);lootBox(-4,-4,'safe',dk+.2);W.bossSpot={x:3,z:3,y:dk+.2};
    zipline(12,dk+.2,12,110,0,110);zipline(-12,dk+.2,-12,-110,0,-110);
    // facade segments (visible from outside only)
    for(let i=0;i<7;i++){const y=FH+3+i*6.3;dGeo(new T.CylinderGeometry(17.4,13.6,6,4,1,true),0x5a7a80,0,y,0,0,Math.PI/4,0,1,1,1,true);dB(0xc8a040,0,y-3,0,19.4,.35,19.4,0,0,0,true)}
    dC(0x8a9a9a,0,dk+5,0,1.4,2.6,8,0,0,0,10,true);dC(0x9aaaaa,0,dk+15,0,.25,.6,14,0,0,0,8,true);for(let i=0;i<10;i++)lamp(srnd(-30,30),spick([-32,32]))}
  // city blocks of high-rises (enterable ground floor + roofs via ladders)
  for(const gx of [-125,-75,-25,25,75,125])for(const gz of [-125,-75,-25,25,75,125]){if(Math.abs(gx)<40&&Math.abs(gz)<40)continue;const cx=gx+srnd(-3,3),cz=gz+srnd(-3,3);const r=SR();
    if(r<.6){for(const o of [-1,1]){const w=srnd(12,17),d=srnd(12,17);const bx=cx+o*10,bz=cz+srnd(-6,6);if(!isFree(bx,bz,w/2))continue;const b=building(bx,bz,w,d,{floors:2,ladder:SR()<.5,loot:2,mat:spick(['wallA','wallB','wallC','dark'])});const tall=srnd(6,45);sbox(bx,bz,w*.8,d*.8,tall,spick(['glass','glass','wallA','conc']),b.h+.3);dB(0x2a2a2a,bx,b.h+.3+tall+.5,bz,w*.5,1,d*.5,0,0,0,true);if(SR()<.6)dB(0x8a8a82,bx+w*.25,b.h+.3+tall+1.6,bz,1.2,2,1.2,0,0,0,true)}}
    else if(r<.7){landmark('城市公園',cx,cz,14);for(let i=0;i<8;i++)tree(cx+srnd(-14,14),cz+srnd(-14,14));dC(0xb8b8b0,cx,.4,cz,3,3.2,.8,0,0,0,20);sbox(cx,cz,5,5,.8,null,0)}
    else if(r<.85){landmark('捷運站',cx,cz,10);canopy(cx,cz,12,8,4);dB(0x2a5aa0,cx,4.8,cz,6,1,.2,0,0,0,true);stairs(cx-3,cz-2,'z+',2.4,3,'dark');lootBox(cx+3,cz,'crate')}
    else yard(cx,cz)}
  // elevated expressway with ramps
  landmark('高架快速道路',0,75,30);sbox(0,75,h*2-40,10,.6,'road',7);for(let x=-140;x<=140;x+=20)sbox(x,75,1.6,1.6,7,'dark',0);stairs(-150,70,'x+',6,7,'dark');for(let i=0;i<6;i++)wreckCar(srnd(-120,120),75+srnd(-3,3),true);
  for(let i=0;i<10;i++)wreckCar(srnd(-h+20,h-20),spick([-100,-50,50,100])+srnd(-2,2),true);propScatter(60,['car','crates','lamp','fence','barrels']);for(const c of [-100,-50,50,100])for(const c2 of [-100,-50,50,100])if(SR()<.6)lamp(c+5,c2+5);
  stdExtracts(h,[['std',-h+6,-50,'西側隧道'],['std',h-6,50,'東側大橋'],['std',50,-h+6,'北側車站'],['paid',-50,h-6,'地下停車場'],['heli',0,-62,'擎天塔廣場直升機坪'],['power',h-6,-100,'電動閘門'],['nobag',-h+30,h-30,'下水道']]);
  W.powerGate=dbox(h-1,-100,1,10,5,'metal',0);powerSwitch(19.6,1.3,0,'x+');ammoStation(-8,24);ammoStation(8,-24);scatter(70);
  W.flagsPos=[[0,24,'A'],[-75,-75,'B'],[75,75,'C'],[75,-75,'D'],[-75,75,'E']];W.basePos={1:{x:-h+14,z:0},2:{x:h-14,z:0}};W.relicPos={x:0,z:26};W.holdPos={x:0,z:0};W.duelSpots=[{x:-25,z:-50},{x:25,z:-50}]}

/* ---------- landmark additions for the original maps ---------- */
function addOldLandmarks(id){const h=W.half;
  if(id==='town'){landmark('指揮所',0,0,16);const add=[['裝甲工廠',-102,-102],['中轉站',102,-102],['商場',-102,102],['博物館',102,102],['集市',-68,0],['污水廠',68,0]];
    for(const [n,x,z] of add){landmark(n,x,z,16);if(n==='集市')market(x,z+12);if(n==='污水廠'){tank(x-6,z+14,4,3);tank(x+6,z+14,4,3)}if(n==='博物館'){for(let i=0;i<5;i++)dC(0xd8d0c0,x-8+i*4,3,z-14,.5,.55,6,0,0,0,12)}if(n==='裝甲工廠'){silo(x+10,z+12,3,12);wreckCar(x-6,z+14,true)}}}
  if(id==='dam'){for(const [n,x,z] of [['行政樓',-60,-60],['水泥廠',60,-110],['軍營',-120,100],['遊客中心',110,110],['主變電站',120,-40],['帳篷區',-130,-120]]){landmark(n,x,z,16);
      if(n==='水泥廠'){silo(x,z,4,16);silo(x+10,z,4,16)}if(n==='帳篷區')for(let i=0;i<5;i++)tent(x+srnd(-12,12),z+srnd(-10,10));if(n==='主變電站')for(let i=0;i<4;i++){if(isFree(x+i*4-6,z+10,1.5)){dB(0x5a5a52,x+i*4-6,1.5,z+10,2,3,2,0,0,0,true);sbox(x+i*4-6,z+10,2,2,3,null,0)}}}}
  if(id==='frost'){landmark('研究站',0,0,26);landmark('毒氣實驗室',17,-17,10);landmark('雷達穹頂',56,-44,10);landmark('纜車塔',-75,50,8)}
  if(id==='tower'){}
  if(id==='harbor'){landmark('貨輪',150,0,30);landmark('貨櫃迷宮',0,0,40)}
  if(id==='warehouse'){landmark('大倉庫',0,0,20)}}

/* ---------- match events (different mechanisms each raid) ---------- */
const EVENTS={blackout:{name:'電力全斷',desc:'全區斷電：路燈熄滅、監視器與砲塔停擺，拉閘撤離無法使用'},patrol:{name:'加強巡邏',desc:'守軍人數增加 30%'},drop:{name:'空投提前',desc:'空投在 3 分鐘時落下'},vault:{name:'金庫失守',desc:'所有上鎖的門都已打開'},
  gas:{name:'毒氣外洩',desc:'地圖上多了三處毒氣區'},fog:{name:'濃霧',desc:'整場比賽能見度極低'},boss:{name:'高價目標',desc:'多一名守軍頭目，攜帶大紅'},lockdown:{name:'撤離封鎖',desc:'兩個常規撤離點被封鎖'}};
function pickEvent(seed){const k=Object.keys(EVENTS);return k[(mulberry(seed^0x5bd1e995)()*k.length)|0]}
function applyEvent(ev){if(!ev)return;switch(ev){
  case 'blackout':for(const c of W.cameras)c.hp=0;for(const t of W.turrets)t.hp=0;W.glows.forEach(g=>g.visible=false);W.lampPos.length=0;for(const e of W.extracts)if(e.type==='power')e.blocked=true;break;
  case 'vault':for(const d of W.doors)d.locked=null;break;
  case 'gas':for(let i=0;i<3;i++){const x=rnd(-W.half+30,W.half-30),z=rnd(-W.half+30,W.half-30);gasZone(x,z,9)}break;
  case 'lockdown':{let n=0;for(const e of W.extracts)if(e.type==='std'&&n<2){e.blocked=true;n++}break}
  }}
