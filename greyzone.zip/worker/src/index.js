// 灰區撤離 matchmaking + relay service (Cloudflare Workers + Durable Objects)
//   GET  /health                      -> "ok"
//   GET  /room/:code  (WebSocket)     -> relay inside a room. ?id=<client id>&host=1 to create
//   POST /match  {mode,nick,id}        -> waits up to 60 s, returns {code, host, members}
//   GET  /rooms                        -> public rooms that are waiting for players
const CORS = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET,POST,OPTIONS', 'Access-Control-Allow-Headers': 'content-type' };
const json = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { 'content-type': 'application/json', ...CORS } });

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    if (req.method === 'OPTIONS') return new Response(null, { headers: CORS });
    if (url.pathname === '/health') return new Response('ok', { headers: CORS });
    const m = url.pathname.match(/^\/room\/([A-Z0-9]{4,8})$/);
    if (m) { const stub = env.ROOMS.get(env.ROOMS.idFromName(m[1])); return stub.fetch(req); }
    if (url.pathname === '/match' && req.method === 'POST') { const body = await req.json(); const mode = String(body.mode || 'extract').slice(0, 20);
      const stub = env.QUEUE.get(env.QUEUE.idFromName('q-' + mode)); return stub.fetch(new Request('https://q/join', { method: 'POST', body: JSON.stringify(body) })); }
    if (url.pathname === '/rooms') { const stub = env.QUEUE.get(env.QUEUE.idFromName('directory')); return stub.fetch(new Request('https://q/list')); }
    return json({ error: 'not found' }, 404);
  }
};

// One Durable Object per room code. The first socket with host=1 owns the room.
export class Room {
  constructor(state) { this.state = state; this.socks = new Map(); this.host = null; }
  async fetch(req) {
    if (req.headers.get('Upgrade') !== 'websocket') return json({ error: 'expected websocket' }, 426);
    const url = new URL(req.url); const id = (url.searchParams.get('id') || crypto.randomUUID()).slice(0, 40); const wantHost = url.searchParams.get('host') === '1';
    if (wantHost && this.host && this.socks.has(this.host)) return json({ error: 'unavailable-id' }, 409);
    if (!wantHost && !(this.host && this.socks.has(this.host))) return json({ error: 'peer-unavailable' }, 404);
    const pair = new WebSocketPair(); const [client, server] = Object.values(pair); server.accept();
    this.socks.set(id, server); if (wantHost) this.host = id;
    server.send(JSON.stringify({ __welcome: id, host: this.host }));
    if (!wantHost) this.sendTo(this.host, { __join: id });
    server.addEventListener('message', ev => {
      let d; try { d = JSON.parse(ev.data); } catch (e) { return; }
      const out = JSON.stringify({ from: id, m: d.m });
      if (d.to === '*') { for (const [k, s] of this.socks) if (k !== id) try { s.send(out); } catch (e) {} }
      else { const s = this.socks.get(d.to); if (s) try { s.send(out); } catch (e) {} }
    });
    const bye = () => { if (!this.socks.has(id)) return; this.socks.delete(id);
      if (id === this.host) { for (const [, s] of this.socks) try { s.send(JSON.stringify({ __hostgone: 1 })); s.close(1000, 'host left'); } catch (e) {} this.socks.clear(); this.host = null; }
      else this.sendTo(this.host, { __leave: id }); };
    server.addEventListener('close', bye); server.addEventListener('error', bye);
    return new Response(null, { status: 101, webSocket: client });
  }
  sendTo(id, o) { const s = id && this.socks.get(id); if (s) try { s.send(JSON.stringify(o)); } catch (e) {} }
}

// One Durable Object per game mode: collects players for up to 60 s, then hands out a room.
const MAX = { extract: 18, conquest: 8, tdm: 10, rats: 9, disaster: 20, sf: 12, nuke: 10, bedwars: 8, bio: 18, zombie: 4, oitc: 8, gungame: 8, relic: 10, duel: 2 };
export class Queue {
  constructor(state) { this.state = state; this.waiting = []; this.deadline = 0; this.rooms = []; }
  async fetch(req) {
    const url = new URL(req.url);
    if (url.pathname === '/list') return json({ rooms: this.rooms.filter(r => Date.now() - r.t < 90000) });
    const body = await req.json(); const mode = String(body.mode || 'extract'); const max = MAX[mode] || 8;
    let resolve; const p = new Promise(r => resolve = r);
    this.waiting.push({ id: body.id, nick: String(body.nick || '玩家').slice(0, 16), resolve });
    if (!this.deadline) { this.deadline = Date.now() + 60000; this.state.storage.setAlarm(this.deadline); }
    if (this.waiting.length >= max) this.flush(mode);
    return p;
  }
  async alarm() { this.flush(); }
  flush(mode) {
    const group = this.waiting.splice(0); this.deadline = 0; if (!group.length) return;
    const code = Array.from({ length: 5 }, () => 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[Math.floor(Math.random() * 32)]).join('');
    const members = group.map(g => ({ id: g.id, nick: g.nick }));
    group.forEach((g, i) => g.resolve(json({ code, host: i === 0, members, aiFill: true })));
    this.rooms.push({ code, n: group.length, t: Date.now(), mode });
  }
}
