# 灰區撤離 配對伺服器（Cloudflare Workers）

提供兩件事：
1. **一分鐘公開匹配**：玩家按「公開匹配」後最多等 60 秒，湊到的人（不夠的由 AI 補滿）會被分到同一個房間。
2. **轉發連線**：透過 WebSocket 由伺服器轉送遊戲封包，公司／學校網路擋住 WebRTC 時也能連。

## 部署（免費方案即可）
1. 安裝 Node.js 18 以上。
2. 在這個資料夾執行：
   ```
   npm install -g wrangler
   wrangler login
   wrangler deploy
   ```
3. 部署完成會顯示網址，例如 `https://greyzone-match.<你的帳號>.workers.dev`。
4. 打開遊戲 → 設定 → 「配對伺服器」貼上這個網址。所有玩家都要填同一個網址（或改 `js/net.js` 裡的 `DEFAULT_SERVER`，就不用每個人自己填）。

## 測試
瀏覽器打開 `https://greyzone-match.<你的帳號>.workers.dev/health`，看到 `ok` 就代表成功。

## 用量
- 每個房間是一個 Durable Object，只在有人連線時運作。
- 免費方案每天 10 萬次請求；遊戲封包走 WebSocket 訊息，Durable Objects 免費額度足夠朋友間遊玩。人數多時請到 Cloudflare 後台查看用量。
